import { Component } from "react";
import classes from "./User.module.css";

class User extends Component{
    componentDidMount(){
        //console("User did mount")
        console.log("User did mount")
    }
    render(){
        return <div className={classes.user}>{this.props.user.name}</div>
    }
}
export default User;