import { useEffect, useState, Fragment, Component } from "react";
import classes from "./UserFinder.module.css";
import UserContext from "../Store/user-context";
import ErrorBoundary from "./ErrorBoundary";
import Users from "./Users";

// const dummy_user=[
//     { id: 'u1', name: 'Max' },
//     { id: 'u2', name: 'Manuel' },
//     { id: 'u3', name: 'Julie' },
//   ];
class UserFinder extends Component{
    static contextType = UserContext
    constructor(){
        super()
        this.state={
            searchItem:'',
            filteredUsers:[]
        }
    }
    searchHandler(event){
        this.setState({searchItem:event.target.value})    
    }
    componentDidMount(){
        this.setState({filteredUsers:this.context.users})
    }
    componentDidUpdate(prevProps, prevState){
        if(prevState.searchItem !== this.state.searchItem){
            this.setState({
                filteredUsers:this.context.users.filter((user)=>{
                    return (user.name.toLowerCase().includes(this.state.searchItem.toLowerCase()))
                })
            })
        }
    }
    render(){
        return (<Fragment>
            <div className={classes.finder}>
                <label htmlFor="searchuser">Search</label>
                <input ref={this.state.searchItem} id="searchuser" name="searchuser" type="text" 
                onChange={this.searchHandler.bind(this)}></input>
            </div>
            <div>
                <ErrorBoundary>
                    <Users users={this.state.filteredUsers}></Users>
                </ErrorBoundary>
            </div>
        </Fragment>)
    }
}
// function UserFinder(){
//     const [filteredUsers, setFilteredUsers]=useState(dummy_user)
//     const [searchItem, setSearchItem]=useState('')
//     function searchHandler(event){
//         setSearchItem(event.target.value.toLowerCase())
//     }
//     useEffect(()=>{
//         setFilteredUsers(dummy_user.filter((user)=>{return (user.name.toLowerCase().includes(searchItem))}))}, 
//         [searchItem])

//     return (<Fragment>
//         <div className={classes.finder}>
//             <label htmlFor="searchuser">Search</label>
//             <input id="searchuser" name="searchuser" type="text" onChange={searchHandler}></input>
//         </div>
//         <div>
//             <Users users={filteredUsers}></Users>
//         </div>
//     </Fragment>)
// }
export default UserFinder