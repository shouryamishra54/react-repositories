import { useState, Component } from "react";
import classes from "./Users.module.css";
import User from "./User";

class Users extends Component{
    constructor(){
        super();
        this.state={
            showUsers:false,
            test:"more"
        }
    }
    toggleHandler(){
        this.setState((curState)=>{return {showUsers:!curState.showUsers}})
    }
    render(){
        const userlist=(this.props.users.map((user)=>{return (<li><User user={user}></User></li>)}))
        return (<div className={classes.users}>
            <button disabled={this.props.users.length === 0} 
            onClick={this.toggleHandler.bind(this)}>
                {this.state.showUsers?"Hide":"Show"} Users
            </button>
            {this.state.showUsers && <ul>{userlist}</ul>}
        </div>)
    }
}
// function Users(data){
//     const [showUsers, setShowUsers] = useState(false)
//     function toggleHandler(){
//         setShowUsers((curState)=>{return !curState})
//     }
//     const userlist=(
//         data.users.map((user)=>{return (<li>{user.name}</li>)})
//     )
//     return (<div className={classes.users}>
//         <button disabled={data.users.length === 0} onClick={toggleHandler}>{showUsers?"Hide":"Show"} Users</button>
//         {showUsers && <ul>{userlist}</ul>}
//     </div>)
// }
export default Users;