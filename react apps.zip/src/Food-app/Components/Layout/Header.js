import classes from "./Header.module.css";
import { Fragment } from "react";
import mealimage from "../../Assets/meals.jpg";
import HeaderCartButton from "./HeaderCartButton.js";

function Headers(data){
    return (<Fragment>
        <header className={classes.header}>
            <a style={{"textDecoration":"none", "color":"white"}} 
            href="/"><h1>Food Ordering App</h1></a>
            <div></div><div></div>
            <HeaderCartButton onClick={data.onShow}></HeaderCartButton>
            <div></div>
        </header>
        <div className={classes['main-image']}>
            <img src={mealimage} alt="A table full of delicious food!" />
        </div>
    </Fragment>)
}
export default Headers;