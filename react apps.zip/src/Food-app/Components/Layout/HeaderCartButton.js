import classes from "./HeaderCartButton.module.css";
import CartIcon from "../Cart/CartIcon";
import CartContext from "../../Store/cart-context";
import { useContext } from "react";

function HeaderCartButton(data){
    const ctx=useContext(CartContext)
    let cnt=0;
    ctx.items.forEach((item)=>cnt=parseInt(cnt)+parseInt(item.amount))
    return(
        <button className={classes.button} onClick={data.onClick}>
            <span>Cart</span>
            <span className={classes.icon}><CartIcon></CartIcon></span>
            {(cnt>0) && <span className={classes.badge}>{cnt.toString()}</span>}
        </button>
    )
}
export default HeaderCartButton;