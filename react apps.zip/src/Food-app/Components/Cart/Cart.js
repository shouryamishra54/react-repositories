import classes from "./Cart.module.css";
import Modal from "../UI/Modal";
import Card from "../UI/Card";
import CartItem from "./CartItem/CartItem";
import CartContext from "../../Store/cart-context";
import { useContext } from "react";

const DUMMY_MEALS = [
    {
      id: 'm1',
      name: 'Sushi',
      description: 'Finest fish and veggies',
      price: 22.99,
    },
    {
      id: 'm2',
      name: 'Schnitzel',
      description: 'A german specialty!',
      price: 16.5,
    },
    {
      id: 'm3',
      name: 'Barbecue Burger',
      description: 'American, raw, meaty',
      price: 12.99,
    },
    {
      id: 'm4',
      name: 'Green Bowl',
      description: 'Healthy...and green...',
      price: 18.99,
    },
  ];
function Cart(data){
    const ctx=useContext(CartContext)
    const cartItems=ctx.items
    const cartlist=<ul className={classes['cart-items']}>{cartItems.map((item)=>{return (
        <li><CartItem item={item}></CartItem></li>)
    })}</ul>
    let total=0;
    cartItems.map((item)=>{(total+=item.amount.valueOf()*item.price.valueOf())})
    console.log(total);
    const header=<header>Cart Items</header>;
    console.log(cartlist)
    return (<Card><Modal onClose={data.onClose} header={header}>
        <main>
            <div>{cartlist}</div>
            <div className={classes.total}>
                <span>Total Amount: </span>
                <span>{total.toFixed(2)}</span>
            </div>
            <footer className={classes.actions}>
                <button className={classes['button--alt']} onClick={data.onClose}>Close</button>
                <button className={classes.button}>Order</button>
            </footer>
        </main>
    </Modal></Card>)
}
export default Cart;