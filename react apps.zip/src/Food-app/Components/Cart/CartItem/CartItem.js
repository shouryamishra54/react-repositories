import classes from "./CartItem.module.css";
import CartContext from "../../../Store/cart-context";
import CartItemForm from "./CartItemForm.js";
import { useContext } from "react";

function CartItem(data){
    const ctx=useContext(CartContext)
    function subtractToCartHandler(amount){
        ctx.removeItem(data.item.id, amount)
    }
    function removeToCartHandler(){
        ctx.removeItem(data.item.id, data.item.amount)
    }
    return (<div className={classes.meal}>
        <h3 style={{"alignSelf":"start"}}>{data.item.name}</h3>
        <h3 style={{"alignSelf":"center"}}>{data.item.amount}</h3>
        <div style={{"alignSelf":"end"}}>{data.item.price}</div>
        <CartItemForm id={data.item.id} maxamount={data.item.amount} onSubtractToCart={subtractToCartHandler} 
        onRemoveToCart={removeToCartHandler}>
        </CartItemForm>
    </div>)
}
export default CartItem