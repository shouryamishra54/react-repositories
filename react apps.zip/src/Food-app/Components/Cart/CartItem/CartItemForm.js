import { useRef, useState } from "react";
import classes from "./CartItemForm.module.css";

function CartItemForm(data){
    const [amountIsValid, setAmountIsValid]=useState(true);
    const amountRef=useRef()
    function subtractHandler(event){
        event.preventDefault();
        const enteredAmount=amountRef.current.value
        if(enteredAmount.trim().length === 0 || enteredAmount < 1 || enteredAmount > 10){
            setAmountIsValid(false)
            return
        }
        setAmountIsValid(true)
        data.onSubtractToCart(enteredAmount)
    }
    function removeHandler(event){
        event.preventDefault();
        setAmountIsValid(true);
        data.onRemoveToCart();
    }
    function submitHandler(event){
        event.preventDefault()
    }
    return (<form className={classes.form} onSubmit={submitHandler}>
        <label>Quantity: </label>
        <input id={`cartitem ${data.id}`} type="number" width="5" ref={amountRef} 
        min={1} max={10} step={1} defaultValue={1}></input>
        <button onClick={subtractHandler}>-</button>
        <button onClick={removeHandler}>Remove Item</button>
        {!amountIsValid && <div>Please Enter a value between (1-10)</div>}
    </form>)
}
export default CartItemForm