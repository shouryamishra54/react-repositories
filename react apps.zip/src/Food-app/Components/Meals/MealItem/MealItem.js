import classes from "./MealItem.module.css";
import MealItemForm from "./MealItemForm";
import CartContext from "../../../Store/cart-context";
import { useContext } from "react";

function MealItem(data){
    const ctx=useContext(CartContext)
    function addToCartHandler(amount){
        ctx.addItem({id:data.id,
        name:data.name,
        amount:amount,
        price:data.price})
        //console.log(amount);
    }
    function removeFromCartHandler(amount){
        console.log(amount)
        ctx.removeItem(data.id, amount)
    }
    return(<li className={classes.meal}>
        <div>
            <h3>{data.name}</h3>
            <div className={classes.description}>{data.description}</div>
            <div className={classes.price}>{data.price}</div>
        </div>
        <div>
            <MealItemForm id={data.id} onAddToCart={addToCartHandler} onRemoveFromCart={removeFromCartHandler}></MealItemForm>
        </div>
    </li>)
}
export default MealItem;