import classes from "./MealItemForm.module.css";
import React, {useState, useRef} from "react";
function MealItemForm(data){
    const [amountIsValid, setAmountIsValid]=useState(true);
    const amountRef=useRef();
    function addSubmitHandler(event){
        event.preventDefault();
        const enteredamount=amountRef.current.value;
        if(enteredamount.trim().length===0 || enteredamount < 1 || enteredamount > 10){
            setAmountIsValid(false);
            return;
        }
        //console.log(enteredamount)
        data.onAddToCart(enteredamount)
    }
    function subtractSubmitHandler(event){
        event.preventDefault();
        const enteredamount=amountRef.current.value;
        if(enteredamount.trim().length===0 || enteredamount < 1 || enteredamount > 10){
            setAmountIsValid(false);
            return;
        }
        //console.log(enteredamount)
        data.onRemoveFromCart(enteredamount)
    }
    function submitHandler(event){
        event.preventDefault()
    }
    return (<div>
        <form className={classes.form} onSubmit={submitHandler}>
            <label>Quantity: </label>
            <input ref={amountRef} id={`quantity_${data.id}`} 
            type="number" min={1} max={10} step={1} defaultValue={1}></input>
            <button type="submit" onClick={addSubmitHandler}>Add Item</button>
            {!(amountIsValid) && <p>Please Enter a valid number (1-10).</p>}
        </form>
    </div>)
}
export default MealItemForm;