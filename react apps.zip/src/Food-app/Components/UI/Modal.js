import classes from "./Modal.module.css";
import {Fragment} from "react";
import ReactDOM from "react-dom";
import Card from "./Card.js";

function Backdrop(data1){
    return <div className={classes.backdrop} onClick={data1.onClose}></div>
}
function ModalOverlay(data2){
    return <Card className={classes.modal}>
        <header className={classes.header}><h2>{data2.header}</h2></header>
        <section className={classes.content}>{data2.children}</section>
    </Card>
}
function Modal(data){
    return (<Fragment>
        {ReactDOM.createPortal(<Backdrop onClose={data.onClose}></Backdrop>, document.getElementById('backdrop-root'))}
        {ReactDOM.createPortal(<ModalOverlay>{data.children}</ModalOverlay>, document.getElementById('overlay-root'))}
    </Fragment>)
}
export default Modal;