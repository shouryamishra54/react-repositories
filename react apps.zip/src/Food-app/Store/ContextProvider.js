import React, { useReducer } from "react";
import CartContext from "./cart-context";

function cartReducer(state, action){
    if(action.type === 'ADD'){
        //let idfound=false;
        const stateItems=state.items;
        const findIndex=stateItems.findIndex((item)=> {return (item.id === action.item.id)})
        if(findIndex>=0){
            const updateditem={...stateItems[findIndex], amount:(parseInt(stateItems[findIndex].amount)+parseInt(action.item.amount)).toString()};
            console.log(updateditem)
            let updatedItems=[...stateItems]
            updatedItems[findIndex]=updateditem
            console.log(stateItems)
            return ({items: updatedItems})
        }else{
            return ({items: stateItems.concat(action.item)});
        }
        //console.log(state.items)
        //const updatedItems=((idfound)?(stateItems):(stateItems.concat(action.item)));
        //return ({items: updatedItems})
    }if(action.type === 'REMOVE'){
        const id=action.arg.id;
        const amt=action.arg.amount;
        console.log(id)
        console.log(amt)
        const findIndex=state.items.findIndex((item)=> {return (item.id === id)})
        if(findIndex>=0){
            const stateItems=state.items
            if(stateItems[findIndex].amount > amt){
                const updatedItem={...stateItems[findIndex], 
                    amount:(parseInt(stateItems[findIndex].amount)-parseInt(amt)).toString()}
                let updatedItems=[...stateItems]
                updatedItems[findIndex]=updatedItem
                return ({items: updatedItems})
            }if(stateItems[findIndex].amount === amt){
                const updatedItems=stateItems.filter((item)=>item.id !== id)
                return ({items: updatedItems})
            }
            return ({items: state.items})
        }else{
            return ({items: state.items})
        }
    }
    return {items:[]}
}
function CartProvider(data){
    const [cartState, dispatchCartAction]=useReducer(cartReducer, {items:[]});
    function addToCartHandler(item){
        dispatchCartAction({type:'ADD', item:item})
    }
    function removeFromCartHandler(id, amount){
        dispatchCartAction({type: 'REMOVE', arg:{id:id, amount:amount}})
    }
    console.log(cartState);
    const cartContext={items:cartState.items, addItem:addToCartHandler, removeItem:removeFromCartHandler}
    return (<CartContext.Provider value={cartContext}>
        {data.children}
    </CartContext.Provider>)
}
export default CartProvider;
