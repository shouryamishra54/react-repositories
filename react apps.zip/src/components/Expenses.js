import "./Expenses.css";
import ItemHeader from "./ItemHeader.js";
import Card from "./Card.js";
import ExpenseFilter from "./ExpenseFilter.js";
import {useState} from "react";
import ExpenseList from "./ExpensesList";
import ExpenseChart from "./ExpenseChart";
//import Card from "./Card.js";
function Expenses(data){
    const [filteredYear, setFilteredYear]=useState("2021")
    let expenses=data.items;
    console.log(filteredYear)
    //const [filteredexpenses, setFilteredExpenses]=useState(expenses)
    function handleChangeFilter(selectedyear){
        setFilteredYear(selectedyear)
    }
    expenses=expenses.filter((item)=>{return item.date.getFullYear().toString() === filteredYear})
    console.log(expenses);
    //let expenses=data.items;
      return (<Card className="expenses">
          <ExpenseChart expenses={expenses}></ExpenseChart>
          <ExpenseFilter selected={filteredYear} onChangeFilter={handleChangeFilter}>
          </ExpenseFilter>
          <div className="expenses">
          <div><ItemHeader></ItemHeader></div>
          <ExpenseList ExpenseList={expenses}></ExpenseList>
          </div></Card>)
  }
export default Expenses;