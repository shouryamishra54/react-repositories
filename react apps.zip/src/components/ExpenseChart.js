import Chart from "./Charts/Chart.js";
function ExpenseChart(data){
    let chartelements=[
        {label:"January", value:0},
        {label:"February", value:0},
        {label:"March", value:0},
        {label:"April", value:0},
        {label:"May", value:0},
        {label:"June", value:0},
        {label:"July", value:0},
        {label:"August", value:0},
        {label:"September", value:0},
        {label:"October", value:0},
        {label:"November", value:0},
        {label:"December", value:0}
    ]
    data.expenses.map((item)=>{chartelements[item.date.getMonth()].value+=item.amount})
    console.log(chartelements);
    return <div><Chart chart={chartelements}></Chart></div>
}
export default ExpenseChart;