import "./ExpenseItem.css"
import "./ExpenseDate.css"
function ItemHeader(){
    return (<div>
        <header>
            <div className="expense-item">
                <div className="expense-item__description">
                    <h2>S. NO.</h2>
                    <h2 className="expense-item__description">Item</h2>
                </div>
                <h2 className="expense-item__price">Price</h2>
                <h2 className="expense-item">Date</h2>
            </div>
        </header>
    </div>)
}
export default ItemHeader;