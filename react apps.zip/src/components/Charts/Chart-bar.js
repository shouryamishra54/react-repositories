import "./Chart-bar.css";
function ChartBar(data){
    let barheight=0;
    if(data.value>0){
        barheight=(data.value/data.maxvalue)*100+'%';
    }
    return (
    <div className="chart-bar">
        <div className="chart-bar__inner">
            <div className="chart-bar__fill" 
            style={{height:barheight}}>
            </div>
        </div>
        <div className="chart-bar__label">{data.value}</div>
    </div>)
}
export default ChartBar;