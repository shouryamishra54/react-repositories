import "./Chart.css";
import ChartBar from "./Chart-bar.js";
function Chart(data){
    const chartvalues=data.chart.map((item)=>{return item.value})
    const maxvalue=Math.max(...chartvalues)
    return(<div className="chart">{data.chart.map((item)=>{
        return (<ChartBar key={item.label}
        label={item.label}
        maxheight={maxvalue}
        value={item.value}></ChartBar>)})}</div>)
}
export default Chart;