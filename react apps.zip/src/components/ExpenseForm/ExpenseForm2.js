import './ExpenseForm.css';
import React, {useState} from 'react';
import Button from "../UI/Button.js";
import ErrorModal from "../UI/ErrorModal.js";
import Card from "../Card.js";
import Wrapper from "../UI/Wrapper.js";
function ExpenseForm(data){
    const [isvalid1, setIsValid1]=useState(true);
    const [isvalid2, setIsValid2]=useState(true);
    const [isvalid3, setIsValid3]=useState(true);
    const [enteredTitle, setTitle]=useState('')
    const [enteredAmount, setAmount]=useState('')
    const [enteredDate, setDate]=useState('')
    const [error, setError]=useState()
    const warning=<div><ErrorModal error={error} onClose={handleError}></ErrorModal></div>
    function titleChangeHandler(event){
        if(event.target.value.trim().length===0){
            setTitle(null);
            setIsValid1(false);
            return
        }else{
        setTitle(event.target.value)
        setIsValid1(true);
        return
        }
        //console.log(enteredTitle)
    }
    function amountChangeHandler(event){
        if(event.target.value.trim().length===0){
            setAmount(null);
            setIsValid2(false);
            return
        }else{
        setAmount(event.target.value)
        setIsValid2(true);
        return
        }
        //console.log(enteredAmount)
    }
    function dateChangeHandler(event){
        if(event.target.value.trim().length===0){
            setDate(null);
            setIsValid3(false);
            return
        }else{
        setDate(event.target.value)
        setIsValid3(true);
        return
        }
        //console.log(enteredDate)
    }
    function formSubmission(event){
        event.preventDefault()
        if(enteredTitle.trim().length===0){
            //alert("Please enter the Title")
            setError({title:'Invalid Title', errormessage:'Enter the Title'})
            return
        }if(enteredAmount.trim().length===0){
            //alert("Please enter the Amount")
            setError({title:'Invalid Amount', errormessage:'Enter the Amount'})
            return
        }if(enteredDate.trim().length===0){
            //alert("Please enter the Date")
            setError({title:'Invalid Date', errormessage:'Enter the Date'})
            return
        }
        console.log(error)
        const ExpenseData={title:enteredTitle, amount:enteredAmount, date:new Date(enteredDate)}
        data.onSaveExpenseItem(ExpenseData);
        setTitle('')
        setAmount('')
        setDate('')
        setError(null)
    }
    function handleError(){
        setError(null)
    }
    return (<Wrapper><div>{error && warning}<Card><form onSubmit={formSubmission}>
        <div className='new-expense__controls'>
            <div className={`new-expense__control ${isvalid1?"":"invalid"}`}>
                <label>Enter the Title: </label>
                <input type="text" onChange={titleChangeHandler} value={enteredTitle}
                ></input>
            </div>
            <div className={`new-expense__control ${isvalid2?"":"invalid"}`}>
                <label>Enter the Amount: </label>
                <input type="number" min={0.01} step={0.01}
                    onChange={amountChangeHandler} value={enteredAmount}></input>
            </div>
            <div className={`new-expense__control ${isvalid3?"":"invalid"}`}>
                <label>Enter the Date: </label>
                <input type="date" min={'2019-01-01'} max={'2022-12-31'}
                    onChange={dateChangeHandler} value={enteredDate}></input>
            </div>
        </div>
        <div className='new-expense__actions'>
            <Button type="submit">Add Expense</Button>
        </div>
    </form></Card></div></Wrapper>)
}
export default ExpenseForm;