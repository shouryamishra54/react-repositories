import './ExpenseForm.css';
import React, {useState, useRef} from 'react';
import Button from "../UI/Button.js";
import ErrorModal from "../UI/ErrorModal.js";
import Card from "../Card.js";
import Wrapper from "../UI/Wrapper.js";
function ExpenseForm(data){
    const titleref=useRef();
    const amountref=useRef();
    const dateref=useRef();
    const [error, setError]=useState()
    const warning=<div><ErrorModal error={error} onClose={handleError}></ErrorModal></div>
    function titleChangeHandler(event){
        if(event.target.value.trim().length===0){
           // setTitle(null);
            //setIsValid1(false);
            return
        }else{
        //setTitle(event.target.value)
        //setIsValid1(true);
        return
        }
        //console.log(enteredTitle)
    }
    function amountChangeHandler(event){
        if(event.target.value.trim().length===0){
        //    setAmount(null);
        //    setIsValid2(false);
            return
        }else{
        //setAmount(event.target.value)
        //setIsValid2(true);
        return
        }
        //console.log(enteredAmount)
    }
    function dateChangeHandler(event){
        if(event.target.value.trim().length===0){
          //  setDate(null);
          //  setIsValid3(false);
            return
        }else{
        //setDate(event.target.value)
        //setIsValid3(true);
        return
        }
        //console.log(enteredDate)
    }
    function formSubmission(event){
        event.preventDefault()
        if(titleref.current.value.trim().length===0){
            //alert("Please enter the Title")
            setError({title:'Invalid Title', errormessage:'Enter the Title'})
            return
        }if(amountref.current.value.trim().length===0){
            //alert("Please enter the Amount")
            setError({title:'Invalid Amount', errormessage:'Enter the Amount'})
            return
        }if(dateref.current.value.trim().length===0){
            //alert("Please enter the Date")
            setError({title:'Invalid Date', errormessage:'Enter the Date'})
            return
        }
        console.log(error)
        //const ExpenseData={title:enteredTitle, amount:enteredAmount, date:new Date(enteredDate)}
        const ExpenseData={title: titleref.current.value.trim(),
        amount: amountref.current.value.trim(),
        date: new Date(dateref.current.value.trim())}
        data.onSaveExpenseItem(ExpenseData);
        //setTitle('')
        //setAmount('')
        //setDate('')
        titleref.current.value="";
        amountref.current.value="";
        dateref.current.value="";
        setError(null)
    }
    function handleError(){
        setError(null)
    }
    return (<Wrapper><div>{error && warning}<Card><form onSubmit={formSubmission}>
        <div className='new-expense__controls'>
            <div className={`new-expense__control`}>
                <label>Enter the Title: </label>
                <input type="text" ref={titleref}
                ></input>
            </div>
            <div className={`new-expense__control`}>
                <label>Enter the Amount: </label>
                <input type="number" min={0.01} step={0.01}
                    ref={amountref}></input>
            </div>
            <div className={`new-expense__control`}>
                <label>Enter the Date: </label>
                <input type="date" min={'2019-01-01'} max={'2022-12-31'}
                    ref={dateref}></input>
            </div>
        </div>
        <div className='new-expense__actions'>
            <Button type="submit">Add Expense</Button>
        </div>
    </form></Card></div></Wrapper>)
}
export default ExpenseForm;