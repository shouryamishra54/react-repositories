import './NewExpense.css'
import ExpenseForm from './ExpenseForm.js';
import React from 'react';
function NewExpense(data){
    function handleSaveExpense(expenseItem){
        const expense={id:Math.random().toString(), ...expenseItem}
        //console.log(expense)
        data.onAddExpense(expense)
    }
    return (<div className='new-expense'>
        <ExpenseForm onSaveExpenseItem={handleSaveExpense}></ExpenseForm>
    </div>)
}
export default NewExpense;