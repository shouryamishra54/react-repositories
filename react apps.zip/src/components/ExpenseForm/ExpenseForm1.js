import './ExpenseForm.css';
import React, {useState} from 'react';
import Button from "../UI/Button.js";
function ExpenseForm(data){
    const [isValid, setIsValid]=useState(true)
    const [enteredTitle, setTitle]=useState('')
    const [enteredAmount, setAmount]=useState('')
    const [enteredDate, setDate]=useState('')
    let warning="";
    function titleChangeHandler(event){
        if(event.target.value.trim().length===0){
            setIsValid(false)
        }
        setTitle(event.target.value)
        //console.log(enteredTitle)
    }
    function amountChangeHandler(event){
        if(event.target.value.trim().length===0){
            setIsValid(false)
        }
        setAmount(event.target.value)
        //console.log(enteredAmount)
    }
    function dateChangeHandler(event){
        if(event.target.value.trim().length===0){
            setIsValid(false)
        }
        setDate(event.target.value)
        //console.log(enteredDate)
    }
    function formSubmission(event){
        event.preventDefault()
        if(enteredTitle.trim().length===0){
            alert("Please enter the Title")
            return
        }if(enteredAmount.trim().length===0){
            alert("Please enter the Amount")
            return
        }if(enteredDate.trim().length===0){
            alert("Please enter the Date")
            return
        }
        const ExpenseData={title:enteredTitle, amount:enteredAmount, date:new Date(enteredDate)}
        data.onSaveExpenseItem(ExpenseData);
        setTitle('')
        setAmount('')
        setDate('')
    }
    return (<div>{warning}<form onSubmit={formSubmission}>
        <div className='new-expense__controls'>
            <div className='new-expense__control'>
                <label style={{color:isValid?"black":"red"}}>Enter the Title: </label>
                <input style={{borderColor:isValid?"white":"red",
                backgroundColor:isValid?"white":"salmon"}}
                type="text" onChange={titleChangeHandler} value={enteredTitle}
                ></input>
            </div>
            <div className='new-expense__control'>
                <label>Enter the Amount: </label>
                <input type="number" min={0.01} step={0.01}
                    onChange={amountChangeHandler} value={enteredAmount}></input>
            </div>
            <div className='new-expense__control'>
                <label>Enter the Date: </label>
                <input type="date" min={'2019-01-01'} max={'2022-12-31'}
                    onChange={dateChangeHandler} value={enteredDate}></input>
            </div>
        </div>
        <div className='new-expense__actions'>
            <Button type="submit">Add Expense</Button>
        </div>
    </form></div>)
}
export default ExpenseForm;