import "./ExpenseList.css";
import ExpenseItem from "./ExpenseItem.js";
function ExpenseList(data){
    const ExpenseList=data.ExpenseList;
    return (<div className="expenses-list expenses-list__fallback">{ExpenseList.map((item)=>{return (<div>
        <ExpenseItem 
        key={item.id}
        title={item.title}
        amt={item.amount}
        date={item.date}></ExpenseItem>
        </div>)})}</div>)
}
export default ExpenseList