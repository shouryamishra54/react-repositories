import Button from "./Button.js";
import classes from "./ErrorModal.module.css";
import Card from "../Card.js";

function ErrorModal(data){
    return (<div>
        <div className={classes.backdrop} onClick={data.onClose}></div>
        <Card className={classes.modal}>
            <header className={classes.header}>
                <h2>{data.error.title}</h2>
            </header>
            <div className={classes.content}>
                <h2>{data.error.errormessage}</h2>
            </div>
            <footer className={classes.actions} onClick={data.onClose}>
                <Button>Okay</Button>
            </footer>
        </Card>
    </div>)
}
export default ErrorModal;