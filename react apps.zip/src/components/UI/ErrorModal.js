import React, { Fragment } from "react";
import ReactDOM from "react-dom";
import Button from "./Button.js";
import classes from "./ErrorModal.module.css";
import Card from "../Card.js";

function ErrorModal(data){
    function Backdrop(data){
        return <div className={classes.backdrop} onClick={data.onConfirm}></div>
    }
    function Overlay(data){
        return <Card className={classes.modal}>
        <header className={classes.header}>
            <h2>{data.title}</h2>
        </header>
        <div className={classes.content}>
            <h2>{data.message}</h2>
        </div>
        <footer className={classes.actions} onClick={data.onConfirm}>
            <Button>Okay</Button>
        </footer>
        </Card>
    }
    return (<Fragment>
        {ReactDOM.createPortal(<Backdrop onConfirm={data.onClose}></Backdrop>, document.getElementById("backdrop-root"))}
        {ReactDOM.createPortal(<Overlay title={data.error.title} message={data.error.errormessage} onConfirm={data.onClose}></Overlay>, document.getElementById("overlay-root"))}
    </Fragment>)
}
export default ErrorModal;