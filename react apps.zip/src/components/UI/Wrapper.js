function Wrapper(data){
    return (<div>{data.children}</div>)
}
export default Wrapper