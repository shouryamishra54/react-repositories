import "./Button.css";
function Button(data){
    return (<button className="button" type={data.type} onClick={data.onClick}>{data.children}</button>)
}
export default Button;