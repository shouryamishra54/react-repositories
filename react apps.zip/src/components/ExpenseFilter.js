import "./ExpenseFilter.css";

function ExpenseFilter(data){
    function dropDownChangeHandler(event){
        data.onChangeFilter(event.target.value)
    }
    return(<div className="expenses-filter">
        <div className="expenses-filter__control">
        <label>Filter by Year </label>
        <select value={data.selected} onChange={dropDownChangeHandler}>
            <option value={new Date('2019').getFullYear()}>{new Date('2019').getFullYear()}</option>
            <option value={new Date('2020').getFullYear()}>{new Date('2020').getFullYear()}</option>
            <option value={new Date('2021').getFullYear()}>{new Date('2021').getFullYear()}</option>
            <option value={new Date('2022').getFullYear()}>{new Date('2022').getFullYear()}</option>
            <option value={new Date('2023').getFullYear()}>{new Date('2023').getFullYear()}</option>
        </select>
        </div>
    </div>)
}
export default ExpenseFilter