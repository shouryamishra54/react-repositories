import './ExpenseItem.css';
import './ExpenseDate.css';
import {useState} from 'react';
function ExpenseItems(data){
    const [title, setTitle]=useState(data.title);
    console.log(data.title)
    const earliertitle=data.title;
    const buttonid="change "+data.key;
    function clickHandlerUpdate(){
        if(title === earliertitle){
            setTitle("Updated!")
            document.getElementById(buttonid).innerHTML="Click to Revert"
            console.log(title)
        }else{
            setTitle(earliertitle)
            document.getElementById(buttonid).innerHTML="Click to Change"
            console.log(title)
        }
    }
    return(
    <div className="expense-item">
        <div className='expense-item__description'>
        <h2>{data.key}</h2>
        <h2 className="expense-item__description">
        {title}
        </h2>
        <div>
            <button id={buttonid} onClick={clickHandlerUpdate}>Click to Change</button>
        </div>
        </div>
        <h2 className="expense-item__price">
            {data.amt}
        </h2>
        <h2 className='expense-item'>
            {data.date.toDateString()}{"  "}
            {data.date.toLocaleTimeString()}
        </h2>
    </div>)
}
export default ExpenseItems;