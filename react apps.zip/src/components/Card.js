import "./Card.css";
function Card(data){
    let classes="Card "+data.className;
    return (<div className={classes}>{data.children}</div>)
}
export default Card;