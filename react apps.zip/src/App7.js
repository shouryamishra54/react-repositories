import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import SimpleInput from "./PracticeForm/components/Form/SimpleInput"
import defautclasses from "./APIFetcher/styles/default.module.css";
//Styling Form Inputs
function App(){
    return (<div className="App">
        <div className="page-header">
            <h1>Explaination of Advanced Styled Forms</h1>
        </div>
        <body>
            <React.Fragment>
                <div className="panel-heading">
                    <h2>User Form</h2>
                </div>
                <div className={`panel-body container panel ${defautclasses['form']}`}>
                    <SimpleInput></SimpleInput>
                </div>
            </React.Fragment>
        </body>
    </div>)
}
export default App;