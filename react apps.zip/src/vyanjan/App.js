import React, { useState, useEffect, useContext } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
//import Counter from "./use-of-redux/components/Counter"
//import Auth from "./use-of-redux/components/Auth"
//import Header from "./use-of-redux/components/Header"
//import UserProfile from "./use-of-redux/components/UserProfile"
import defautclasses from "./APIFetcher/styles/default.module.css";
import image from "./vyanjan/Assets/meals.jpg";
import Card from "./vyanjan/Simple/components/UI/Card";
import Header from "./vyanjan/Simple/components/Layout/Header";
import Cart from "./vyanjan/Simple/components/Cart/Cart";
import Products from "./vyanjan/Simple/components/Shop/Products";
import { fetchCartData, replaceCart, sendCartData } from "./vyanjan/Simple/store/cart-action";
import { useDispatch, useSelector } from "react-redux";
import { Prompt, Redirect, Route, Switch } from "react-router-dom";
import Layout from "./vyanjan/Simple/components/Layout/Layout";
import Auth from "./vyanjan/Simple/components/auth/auth";
import { AuthContext } from "./vyanjan/Simple/context/auth-context";
import UserProfile from "./vyanjan/Simple/pages/UserProfile";
import MyCart from "./vyanjan/Simple/pages/MyCart";
import UseHttp from "./vyanjan/Simple/hooks/use-http";
import { getCartData, updateCart } from "./vyanjan/Simple/libs/api";
//import { useSelector } from "react-redux";
//import store from "./use-of-redux/store/index";

//Use of Redux State Management
function App(){
    //const loggedin=useSelector(state=>state.authentication.login)
    const [cartIsClicked, setCartIsClicked]=useState(false)
    const cartLocal=localStorage.getItem("items")?JSON.parse(localStorage.getItem("items")).items:null
    const cartItems=useSelector(state=>state?state.items:null)
    const changed=useSelector(state=>state?state.changed:null)
    const authctx=useContext(AuthContext)
    const {isLoading:cartLoading, error:cartError, data:cartData, sendRequest:getCartRequest}=UseHttp(getCartData)
    const {isLoading:cartUpdated, error:cartUpdateError, data:updatedCartData, sendRequest:updateCartRequest}=UseHttp(updateCart)
    const dispatch=useDispatch();    
    useEffect(() => {
        /*window.onbeforeunload=function(){
            if(authctx.userId !== undefined && authctx.userId !== null){
                localStorage.setItem("items", JSON.stringify(cartItems))
                localStorage.setItem("changed",changed)
            }
        }
        window.onunload=function(){
            const cartChanged=localStorage.getItem("changed");
            console.log(cartChanged)
            if(authctx.userId !== undefined && authctx.userId !== null && (cartChanged===true || changed)){
                console.log("Hello")
                setTimeout(async()=>{
                    await updateCartRequest({
                        userId:authctx.userId,
                        items:JSON.parselocalStorage.getItem("items")
                    })
                }, 500)
            }
        }*/
        window.addEventListener("beforeunload", handleBeforeUnload)
        // window.addEventListener("unload", handleEndConcert)
        if(performance.navigation.type === 1){
            const cartChanged=localStorage.getItem("changed");
            console.log(cartChanged)
            if(authctx.userId !== undefined && authctx.userId !== null && cartLocal && cartChanged){
                console.log("Hello")
                setTimeout(async()=>{
                    await updateCartRequest({
                        userId:authctx.userId,
                        cart:cartLocal
                    })
                    localStorage.removeItem("changed")
                    dispatch(replaceCart(cartLocal))
                }, 500)
            }
        }
        /*return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload)
            window.removeEventListener('unload', handleEndConcert)
            handleEndConcert()
          }*/
    }, []);
    function handleBeforeUnload(e){
        e.preventDefault();
        if(authctx.userId !== undefined && authctx.userId !== null && cartItems){
            // localStorage.setItem("items", JSON.stringify(cartItems))
            // localStorage.setItem("changed",changed)
        }
        e.returnValue="Do you want to reload this page? You will lose your saved data."
    }
    async function handleEndConcert(){
        const cartChanged=localStorage.getItem("changed");
        console.log(cartChanged)
        if(authctx.userId !== undefined && authctx.userId !== null && 
            (cartChanged===true || changed)){
            console.log("Hello")
            setTimeout(async()=>{
                await updateCartRequest({
                    userId:authctx.userId,
                    items:JSON.parselocalStorage.getItem("items")
                })
            }, 500)
        } 
    }
    useEffect(()=>{
        setTimeout(async()=>{
            if(authctx.userId !== undefined && authctx !== null){
            // await getCartRequest(authctx.userId)
            dispatch(fetchCartData(authctx.userId))
            }
        }, 500)
    }, [authctx.isLoggedIn, authctx.userId])
    useEffect(()=>{
        if(changed){
            // sendCartData(cartItems.items)
            // localStorage.setItem("items", JSON.stringify(cartItems))
            // localStorage.setItem("changed", changed)
        }if(cartData && cartData.cartItems && cartData.cartItems.length > 0){
            // dispatch({type:"replaceCart",items:cartData.cartItems})
            dispatch(replaceCart(cartData.cartItems))
            // localStorage.setItem("items", JSON.stringify(cartData.cartItems))
        }
    }, [cartData, cartItems])
    function closeCartHandler(){
        setCartIsClicked(false)
    }
    function openCartHandler(){
        setCartIsClicked(true)
    }
    return (<div className="App">
        <div className="page-header">
            <h1>Explaination of Redux State Management</h1>
        </div>
        <body>
            <div  
            className={`panel-body container ${defautclasses['form']}`}>
                <h1>Hello</h1>
            </div>
            <Layout>
                <div className="panel-heading">
                    <Header onShow={openCartHandler}></Header>
                </div>
                <div className="panel-body">
                    {cartIsClicked && <Cart onClose={closeCartHandler}></Cart>}
                </div>
                <Switch>
                    <Route path="/" exact>
                        <Redirect to="/home"></Redirect>
                    </Route>
                    <Route path="/home" exact>
                        <div className="panel-body container">
                            <Products></Products>
                        </div>  
                    </Route>
                    {!authctx.isLoggedIn && <Route path="/auth" exact>
                        <Auth />
                    </Route>}
                    {authctx.isLoggedIn && <Route path="/user-profile" exact>
                        <UserProfile />
                    </Route>}
                    {authctx.isLoggedIn && <Route path="/myCart" exact>
                        <MyCart />    
                    </Route>}
                    <Route path="*">
                        <h3>Page not found</h3>
                    </Route>
                </Switch>
            </Layout>
        </body>
    </div>)
}
export default App;