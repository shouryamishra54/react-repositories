import { useContext, useEffect } from "react";
import { useDispatch } from "react-redux";
import UseHttp from "../../Simple/components/hooks/use-http";
import { AuthContext } from "../context/auth-context";
import { getCartData } from "../libs/api";
const MEAL_URL="https://meals-75828-default-rtdb.firebaseio.com/"

export const REPLACE_CART="replaceCart";
export const ADD_TO_CART="addToCart";
export const REMOVE_FROM_CART="removeFromCart";

export const fetchCartData=(userId)=>{
    return async (dispatch)=>{
        let data=null;
        try{
            data=await getCartData(userId)
            // console.log(data)
            if(data.cartItems){
                dispatch ({type:REPLACE_CART, items: data.cartItems})
            }
            // console.log(data)
        }catch(e){
            console.log(e.message)
        }
        // data=await getCartData(userId)
        // dispatch ({type:"replaceCart", items: data.cartItems})
        // console.log(data)
    }
    /*async function FetchCartData(){
        let data=null;
        //console.log("Hello")
        // const authctx=useContext(AuthContext)
        //const {isLoading, error, data: cartData, sendRequest:getCartRequest}=UseHttp(getCartData);
        await sendCartData({
            url:`${MEAL_URL}/cart.json`
        },
        (data1)=>{
                data=data1
                console.log("Hello")
            })
        useEffect(()=>{
            setTimeout(async()=>{
                // const userId=authctx.userId
                data=await getCartData(userId)
            }, 500)
        }, [])
        console.log(data)
        const dispatch = useDispatch()
        dispatch ({type:"replaceCart", items: data.cartItems})
    }
    FetchCartData()*/
}
export const sendCartData=(cart)=>{
    async function SendCartData(cart){
        //const {isLoading, error, sendRequest:sendCartData}=UseHttp();
        console.log("Hello")
        const response=await fetch(`${MEAL_URL}/cart.json`,{
            method: "post",
            body: JSON.stringify(cart),
            headers: {"Content-Type":"application/json"}})
        /*await sendCartData({
            url:`${MEAL_URL}/meals.json`,
            method:"post",
            body:cart,
            header:{
                "Content-Type":"application/json"
            }
        },
        (data1)=>{for(let key in data1){
                    console.log(data1[key])
                }
            })*/
        if(response.status !== 200 && response.status!== 201){
            throw new Error("Request Failed")
        }
        const data=await response.json();
        console.log(data)
    }
    SendCartData(cart)
}
export const replaceCart = items =>{
    return ({type: REPLACE_CART, items: items})
}
export const addtoCart = item =>{
    return ({type: ADD_TO_CART, item: item})
}
export const removefromCart = item =>{
    return ({type: REMOVE_FROM_CART, item: item})
}
//export default FetchCartData;