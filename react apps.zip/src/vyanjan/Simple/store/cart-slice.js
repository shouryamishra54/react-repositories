import { useContext } from "react";
import { applyMiddleware, createStore } from "redux";
import { AuthContext } from "../context/auth-context";
import thunk from "redux-thunk";
import { ADD_TO_CART, REMOVE_FROM_CART, REPLACE_CART } from "./cart-action";

const initialCart={items:[], changed: false}
const CartSlice=(state=initialCart, action)=>{
    if(action.type === REPLACE_CART){
        // localStorage.setItem("items", JSON.stringify({items: action.items}))
        // localStorage.removeItem("changed")
        return ({items: action.items})
    }
    if(action.type === ADD_TO_CART){
        const newItem=action.item;
        console.log(newItem)
        const indexOfItem=state.items.findIndex((item)=>item.id === newItem.id)
        if(indexOfItem >= 0){
            const items=state.items;
            const updatedItem={...items[indexOfItem],
            quantity: parseInt(items[indexOfItem].quantity)+parseInt(newItem.quantity)}
            const updatedItems=[...items]
            updatedItems[indexOfItem]=updatedItem
            localStorage.setItem("items", JSON.stringify({items: updatedItems}))
            localStorage.setItem("changed", true)
            return ({items: updatedItems, changed: true})
        }else{
            const updatedItems=state.items.concat(newItem);
            localStorage.setItem("items", JSON.stringify({items: updatedItems}))
            localStorage.setItem("changed", true)
            return ({items: updatedItems, changed: true})
        }
    }if(action.type === REMOVE_FROM_CART){
        const itemToDelete=action.item;
        const indexOfItem=state.items.findIndex((item)=>item.id === itemToDelete.id)
        console.log(itemToDelete)
        console.log(indexOfItem)
        console.log(state.items[indexOfItem].quantity)
        console.log(itemToDelete.quantity)
        if(indexOfItem >= 0 && (state.items[indexOfItem].quantity > itemToDelete.quantity)){
            const items=state.items;
            if(itemToDelete.quantity >= items[indexOfItem].quantity){
                throw new Error("Items cannot be deleted")
            }else{
                const updatedItem={...items[indexOfItem], 
                quantity: parseInt(items[indexOfItem].quantity) - parseInt(itemToDelete.quantity)}
                const updatedItems=[...items]
                updatedItems[indexOfItem]=updatedItem
                localStorage.setItem("items", JSON.stringify({items: updatedItems}))
                localStorage.setItem("changed", true)
                return ({items:updatedItems, changed: true})
            }
        }else{
            if(indexOfItem >= 0 && (state.items[indexOfItem].quantity == itemToDelete.quantity)){
                const updatedItems=state.items.filter((item)=>item.id !== itemToDelete.id)
                localStorage.setItem("items", JSON.stringify({items: updatedItems}))
                localStorage.setItem("changed", true)
                return ({items: updatedItems, changed: true})
            }else{
                throw new Error("Items cannot be deleted")
            }
        }
    }
}
const cartItems=createStore(CartSlice, applyMiddleware(thunk))

export default cartItems;
