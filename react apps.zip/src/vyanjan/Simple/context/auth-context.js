import React, { useContext, useState } from "react";

export const AuthContext=React.createContext({
    token:"",
    userId:"",
    isLoggedIn:false,
    login:(data)=>{},
    logout:()=>{}
})

export function AuthContextProvider(props){
    const [token, setToken]=useState(localStorage.getItem("token"));
    const userIsLoggedIn=!!token;
    const [userId, setUserId]=useState(localStorage.getItem("userId"));
    function loginHandler(data){
        if(localStorage.getItem("token")!==data.loginInfo.idToken){
            setToken(data.loginInfo.idToken);
            setUserId(data.loginInfo.localId)
            localStorage.setItem("token", data.loginInfo.idToken)
            localStorage.setItem("userId", data.loginInfo.localId)
        }
    }
    function logoutHandler(){
        if(localStorage.getItem("token") && localStorage.getItem("token") === token){
            setToken(null)
            setUserId(null)
            localStorage.removeItem("token")
            localStorage.removeItem("userId")
        }
    }
    return (<AuthContext.Provider value={{
        token:token,
        isLoggedIn:userIsLoggedIn,
        userId:userId,
        login:loginHandler,
        logout:logoutHandler
    }}>
        {props.children}
    </AuthContext.Provider>)
}