import { useContext, useEffect, useState } from "react"
import { AuthContext } from "../context/auth-context"
import UseHttp from "../hooks/use-http"
import { getUserData } from "../libs/api"

function UserProfile(){
    const authctx=useContext(AuthContext)
    const [loading, setLoading]=useState(true)
    const {isLoading, error, data: user, sendRequest:getUserRequest}=UseHttp(getUserData)
    useEffect(()=>{
        setTimeout(async()=>{
            await getUserRequest(authctx.token)
            setLoading(false)
        }, 500)
    }, [])
    let processedOutput
    function processOutput(){
        console.log(user)
        // let name,email,username
        // user.map((ele)=>{name=ele.firstname+" "+ele.lastname;username=ele.username;email=ele.email})
        if(user!=undefined){
            processedOutput=(<div>
                <h2>Welcome {user.firstname+" "+user.lastname} to Vyanjan Bolo</h2>
                <p>Username: {user.username}</p>
                <p>Email: {user.email}</p>
            </div>);
        }else{
            if(loading){
                processedOutput=(<h3>Loading...</h3>)
            }else{
                processedOutput=(<h3>No Data Found</h3>)
            }
        }
    }
    processOutput()
    return (
        <div>
            <ul>
                <li>
                    {user!==undefined && <p>{processedOutput}</p>}
                    {loading && user===undefined && <h3>Loading...</h3>}
                    {!loading && user===undefined && <h3>No Data Found</h3>}
                </li>
            </ul>
        </div>
    )
}
export default UserProfile