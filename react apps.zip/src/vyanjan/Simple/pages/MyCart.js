import React, { useContext, useEffect } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import CartItem from "../components/Cart/CartItem";
import { AuthContext } from "../context/auth-context";
import UseHttp from "../hooks/use-http";
import { addToCart, getCartData, getUserData, updateCart } from "../libs/api";

function MyCart(){
    const history=useHistory();
    const cartItems=useSelector(state=>state?state.items:null)
    const changed=useSelector(state=>state?state.changed:false)
    const authctx=useContext(AuthContext)
    const {isLoading:userLoading, error:userError, data:userData, sendRequest:getUserRequest}=UseHttp(getUserData)
    const {isLoading:cartLoading, error:cartError, data:cartData, sendRequest:getCartRequest}=UseHttp(getCartData)
    const {isLoading:cartUpdateLoading, error:cartUpdateError, data:updateCartData, sendRequest:updateCartRequest}=UseHttp(updateCart)
    const {isLoading:addToCartLoading, error:addToCartError, data:addToCartData, sendRequest:addToCartRequest}=UseHttp(addToCart)
    const default_items=[{
        item_name:"Dosa", 
        item_desc:"Total Vegetarian with panner and cheese stuff", 
        quantity: 2, 
        price:90.00}, 
        {
        item_id:1, 
        item_name:"Idli", 
        item_desc:"Total Vegetarian with panner and cheese stuff", 
        quantity: 2, 
        price:30.00}
    ]
    let total=0;
    if(cartItems){
        cartItems.map((item)=>{total+=item.price*item.quantity})
    }
    function closeCartHandler(){
        history.push("/")
    }
    useEffect(()=>{
        setTimeout(async()=>{
            await getUserRequest(authctx.token)
        }, 500)
    }, [])
    useEffect(()=>{
        if(userData !== undefined && userData !== null && 
            (cartItems === undefined || cartItems === null || cartItems.length<1)){
            console.log(cartItems)
            setTimeout(async()=>{
                await getCartRequest(userData.userId)
            }, 500)
        }
    }, [userData])
    console.log(changed)
    useEffect(()=>{
        if(userData !== undefined && userData !== null){
            // if(cartItems && cartItems.length > 0){
            if(changed){
                console.log(cartItems)
                console.log("Hello2")
                setTimeout(async()=>{
                    await addToCartRequest({userId:userData.userId, cart:cartItems})
                }, 500)
            }
        }
    }, [userData, cartData, cartItems])
    return (<React.Fragment>
        <main>
            <section className="modal-body">
                <ul style={{"listStyle":"none"}}>
                    {cartItems && cartItems.map((item)=>{return (
                        <CartItem item={item}></CartItem>)
                    })}
                    {!cartItems && <div className="panel"><h2>Cart is Empty!</h2></div>}
                </ul> 
                <div className="panel-footer" style={{"textAlign":"right"}}><h4><strong>Total: {total}</strong></h4></div>   
            </section>
            <footer className="modal-footer">
                <button onClick={closeCartHandler}>Close</button>
                <button>Proceed</button>
            </footer>
        </main>
    </React.Fragment>)
}
export default MyCart