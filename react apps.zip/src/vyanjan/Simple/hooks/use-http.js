import { useCallback, useState } from "react";

function UseHttp(requestFunction){
    const [isLoading, setIsLoading]=useState(false);
    const [error, setError]=useState();
    const [data, setData]=useState();
    const sendRequest=useCallback(async(requestData)=>{
        try{
            setIsLoading(true);
            const response=await requestFunction(requestData);
            setData(response);
            setIsLoading(false)
        }catch(e){
            setError(e.message)
            setIsLoading(false)
        }
    })
    return {isLoading, error, data, sendRequest}
}
export default UseHttp;