import { useContext } from "react"
import { NavLink } from "react-router-dom"
import { AuthContext } from "../../context/auth-context"
import CartButton from "../Cart/CartButton"
function Header(data){
    const authctx=useContext(AuthContext);
    const userLoggedIn=authctx.isLoggedIn;
    function logoutHandler(){
        authctx.logout()
        localStorage.clear();
    }
    return (<div className="navbar-nav panel-heading panel-body panel ">
        <div className="navbar-header">
        <NavLink style={{"textDecoration":"none"}} to="">
            <div className="container">
                <strong><h1>VYANJAN BOLO</h1></strong>
                <div className="navbar-right">
                    <ul style={{"alignItems":"flex-end", "textAlign":"right", "listStyle":"none", "display":"flex"}}>
                        <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
                            {userLoggedIn && <NavLink to="/user-profile">User Profile</NavLink>}
                        </li>
                    </ul>
                </div>
            </div>
        </NavLink>
        </div>
        <ul className="nav navbar navbar-nav">
            <li><NavLink to="/home">Home<span className="glyphicon-home"></span></NavLink></li>
            <li><NavLink to="/categories">Catgories</NavLink></li>
        </ul>
        <div className="navbar-right">
            <ul style={{"alignItems":"center", "textAlign":"right", "listStyle":"none", "display":"flex"}}>
                <li style={{"alignItems":"flex-end", "fontSize":"large"}}>
                    {userLoggedIn && <CartButton onShow={data.onShow}></CartButton>}   
                    {userLoggedIn && <NavLink to="/myCart">Show Cart</NavLink>} 
                </li>
                <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
                    {!userLoggedIn && <NavLink to="/auth">Login</NavLink>}
                    {userLoggedIn && <button onClick={logoutHandler}>Logout</button>}
                </li>
            </ul>
        </div>        
    </div>)
}
export default Header