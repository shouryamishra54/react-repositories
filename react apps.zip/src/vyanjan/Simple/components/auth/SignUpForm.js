import { useContext, useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
import LoginForm from "./LoginForm";
import classes from "../../Styles/Form.module.css";
import UseHttp from "../../hooks/use-http";
import {signUp} from "../../libs/api";
import { AuthContext } from "../../context/auth-context";
import { useDispatch } from "react-redux";

function SignUpForm(){
    const authctx=useContext(AuthContext)
    const firstnameInputRef=useRef();
    const lastnameInputRef=useRef();
    const usernameInputRef=useRef();
    const emailInputRef=useRef();
    const passwordInputRef=useRef();
    const confirmPasswordInputRef=useRef();
    const history=useHistory();
    const dispatch=useDispatch();
    const {isLoading, error, data: newUser, sendRequest:signUpRequest}=UseHttp(signUp)
    const [isLogin, setIsLogin]=useState(false);
    //const [isLoading, setIsLoading]=useState(false);
    const [passwordError, setPasswordError]=useState(false);
    function switchAuthModeHandler(){
        setIsLogin(true)   
    }
    function validatePassword(){
        return passwordInputRef.current.value === confirmPasswordInputRef.current.value
    }
    function reset(){
        firstnameInputRef.current.value="";
        lastnameInputRef.current.value="";
        usernameInputRef.current.value="";
        emailInputRef.current.value="";
        passwordInputRef.current.value="";
        confirmPasswordInputRef.current.value="";
    }
    function submitSignUpHandler(e){
        e.preventDefault();
        if(!validatePassword()){
            setPasswordError(true)
            return
        }
        if(usernameInputRef.current.value.trim().length<=0){
            return
        }
        if(emailInputRef.current.value.trim().length<=0){
            return
        }if(!isLogin){
            signUpRequest({
                firstname: firstnameInputRef.current.value,
                lastname: lastnameInputRef.current.value,
                username: usernameInputRef.current.value,
                email: emailInputRef.current.value,
                password: passwordInputRef.current.value
            })
            reset();
        }
    }
    useEffect(()=>{
        setTimeout(()=>{
            if(newUser && newUser.signUpInfo){
                authctx.login(newUser)
                console.log(newUser)
                dispatch({type:"logoutUser"})
                history.push("/")
            }
        }, 500)
    }, [newUser])
    return (
        <div>
            {!isLogin && <section className={classes.auth}>
                <h2>{isLogin ? "Login":"Sign Up"}</h2>
                <form onSubmit={submitSignUpHandler}>
                <div className={classes.control}>
                        <label htmlFor="firstname">First Name: </label>
                        <input type="text" id="firstname" name="firstname" ref={firstnameInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="lastname">Last Name: </label>
                        <input type="text" id="lastname" name="lastname" ref={lastnameInputRef}></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="username">User Name: </label>
                        <input type="text" id="username" name="username" ref={usernameInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="email">Email ID: </label>
                        <input type="email" id="email" name="email" ref={emailInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="password">Password: </label>
                        <input type="password" id="password" name="password" ref={passwordInputRef} 
                        required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="confirmpassword">Confirm Password: </label>
                        <input type="password" id="confirmpassword" name="confirmpassword" 
                        ref={confirmPasswordInputRef} required></input>
                    </div>
                    {passwordError && <p>Confirm Password is not equal to the earlier one.</p>}                    
                    <div className={classes.actions}>
                    {!isLoading && (
                        <button>Sign Up</button>
                    )}
                    {isLoading && <p>Sending request...</p>}
                    <button type='button' className={classes.toggle} onClick={switchAuthModeHandler}>
                        Login with an Existing Account
                    </button>
                    </div>
                </form>    
            </section>}
            {isLogin && <LoginForm></LoginForm>}
        </div>)
}
export default SignUpForm