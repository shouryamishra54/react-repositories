import { useContext, useEffect, useRef, useState } from "react"
import SignUpForm from "./SignUpForm";
import classes from "../../Styles/Form.module.css";
import UseHttp from "../../hooks/use-http";
import { signIn } from "../../libs/api";
import { AuthContext } from "../../context/auth-context";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";

function LoginForm(){
    const authctx=useContext(AuthContext)
    const emailInputRef=useRef()
    const passwordInputRef=useRef()
    const dispatch=useDispatch()
    const {isLoading, error, data: loggedInUser, sendRequest:signInRequest}=UseHttp(signIn)
    //const [isLoading, setIsLoading]=useState()
    const history=useHistory();
    const [isLogin, setIsLogin]=useState(true);
    function switchAuthModeHandler(){
        setIsLogin(false)
    }
    function submitLoginHandler(e){
        e.preventDefault();
        if(emailInputRef.current.value.trim().length>0 && passwordInputRef.current.value.trim().length>0){
            signInRequest({
                email:emailInputRef.current.value.trim(),
                password:passwordInputRef.current.value.trim()
            })
        }
    }
    useEffect(()=>{
        setTimeout(()=>{
            if(loggedInUser && loggedInUser.loginInfo && loggedInUser.loginInfo.idToken!=null){
                authctx.login(loggedInUser)
                console.log(loggedInUser)
                dispatch({type:"loginUser", action:authctx.userId})
                history.push("/")
            }
        }, 500)
    }, [loggedInUser])
    return (
        <div>
            {isLogin && <section className={classes.auth}>
                <h2>{isLogin ? "Login":"Sign Up"}</h2>
                <form onSubmit={submitLoginHandler}>
                    <div className={classes.control}>
                        <label htmlFor="email">Your Email: </label>
                        <input type="email" id="email" name="email" ref={emailInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="password">Password: </label>
                        <input type="password" id="password" name="password" ref={passwordInputRef} required></input>
                    </div>
                    <div className={classes.actions}>
                    {!isLoading && (
                        <button>Login</button>
                    )}
                    {isLoading && <p>Sending request...</p>}
                    <button type='button' className={classes.toggle} onClick={switchAuthModeHandler}>
                        Create new account
                    </button>
                    </div>
                </form>    
            </section>}
            {!isLogin && <SignUpForm></SignUpForm>}
        </div>
    )
}
export default LoginForm