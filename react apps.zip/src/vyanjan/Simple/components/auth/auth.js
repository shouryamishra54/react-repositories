import LoginForm from "./LoginForm"

function Auth(){
    return (
        <div>
            <h2>Authentication</h2>
            <LoginForm></LoginForm>
        </div>
    )
}
export default Auth