import { useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { addtoCart, removefromCart } from "../../store/cart-action";
import classes from "./CartItem.module.css";

function CartItem(data){
    const [quantity, setQuantity]=useState(1);
    const dispatch=useDispatch()
    function incrementCartHandler(){
        console.log(quantity)
        console.log(item.available_quant)
        console.log(parseInt(item.quantity)+parseInt(quantity))
        if(parseInt(item.quantity)+parseInt(quantity) <= item.available_quant){
        // dispatch({type:"addToCart", item:{...item, quantity:quantity}})
        dispatch(addtoCart({...item, quantity:quantity}))
        }
    }
    function decrementCartHandler(){
        //console.log("Hello")
        console.log(quantity)
        console.log(item.quantity)
        console.log(item.available_quant)
        // dispatch({type:"removeFromCart", item:{...item, quantity:quantity}})
        dispatch(removefromCart({...item, quantity:quantity}))
    }
    const item=data.item
    return (<div className={`list-group-item ${classes.item}`}>
        <header className="list-group-item-header">
            <h3 class>{item.name}</h3>
            <div className={classes.itemprice}><span><h6>{item.price.toFixed(2)}</h6></span></div>
            <div className={classes.price}><span>{item.price.toFixed(2)*item.quantity}</span></div>
        </header>
        <div className={classes.details}>
            <div className={classes.quantity}> 
                x <span>{item.quantity}</span>
            </div>
            <div className={` form-horizontal form-inline ${classes.actions}`}>
                <button onClick={decrementCartHandler}>-</button>
                <p>Quantity: 
                    <input type="number" min={1} max={item.available_quant} value={quantity}
                    onChange={(e)=>{setQuantity(e.target.value)}}></input>
                </p>
                <button onClick={incrementCartHandler}>+</button> 
            </div>
        </div>
    </div>)
}
export default CartItem;