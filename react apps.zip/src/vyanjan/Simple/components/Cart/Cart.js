import React, { useContext, useEffect } from "react";
import { useSelector } from "react-redux";
import { AuthContext } from "../../context/auth-context";
import Modal from "../UI/Modal";
import CartItem from "./CartItem";
function Cart(data){
    const cartItems=useSelector(state=>state?state.items:null)
    const default_items=[{
        item_name:"Dosa", 
        item_desc:"Total Vegetarian with panner and cheese stuff", 
        quantity: 2, 
        price:90.00}, 
        {
        item_id:1, 
        item_name:"Idli", 
        item_desc:"Total Vegetarian with panner and cheese stuff", 
        quantity: 2, 
        price:30.00}
    ]
    let total=0;
    if(cartItems){
        cartItems.map((item)=>{total+=item.price*item.quantity})
    }
    return (<React.Fragment>
        <Modal header={<div className="modal-header">Cart Items</div>} onClose={data.onClose}>
            <main>
                <section className="modal-body">
                    <ul style={{"listStyle":"none"}}>
                        {cartItems && cartItems.map((item)=>{return (
                            <CartItem item={item}></CartItem>)
                        })}
                        {!cartItems && <div className="panel"><h2>Cart is Empty!</h2></div>}
                    </ul> 
                    <div className="panel-footer" style={{"textAlign":"right"}}><h4><strong>Total: {total}</strong></h4></div>   
                </section>
                <footer className="modal-footer">
                    <button onClick={data.onClose}>Close</button>
                    <button>Proceed</button>
                </footer>
            </main>
        </Modal>
    </React.Fragment>)
}

export default Cart;