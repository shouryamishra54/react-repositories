import { useState } from "react";
import { useSelector } from "react-redux";

function CartButton(data){
    const quantity=useSelector(state=>state?state.items:null)
    let noofitems=0;
    if(quantity){
        quantity.map((item)=>{noofitems+=parseInt(item.quantity)})
    }
    return(<button onClick={data.onShow}>
        <span>My Cart</span>
        <span className="glyphicon-shopping-cart"></span>
        <span className="badge">{noofitems}</span>
    </button>)
}
export default CartButton;