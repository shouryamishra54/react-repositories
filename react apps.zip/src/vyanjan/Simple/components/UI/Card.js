import classes from "./Card.module.css";

function Card(data){
    return (<div style={data.style || null} className={classes.card+` ${data.className}`}>{data.children}</div>)
}
export default Card;