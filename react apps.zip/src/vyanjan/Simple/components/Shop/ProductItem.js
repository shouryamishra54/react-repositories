import classes from "./ProductItem.module.css";
import Card from "../UI/Card";
import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { addtoCart } from "../../store/cart-action";
import UseHttp from "../hooks/use-http";

function ProductItem(data){
    const [quantity, setQuantity]=useState(1);
    const [maxquant, setMaxquant]=useState(1);
    const dispatch=useDispatch();
    const [err, setErr]=useState();
    const {isLoading, error, sendRequest:sendMealRequest}=UseHttp();
    useEffect(()=>{fetchAvailableQuanity()}, []);
    async function fetchAvailableQuanity(){
        let quant=maxquant;
        await sendMealRequest({url:"https://meals-75828-default-rtdb.firebaseio.com/meals.json"},
        (data1)=>{for(let key in data1){
                    if(key === data.item.id){
                        quant=data1[key].quantity
                        setMaxquant(data1[key].quantity)
                        break;
                    }
                }
            })
        return quant;
    }
    async function addToCart(){
        const quant=await fetchAvailableQuanity()
        console.log(quant)
        if(quant >= quantity){
            setErr(null);
            // dispatch({type: "addToCart", item:{...data.item, quantity:quantity}})
            dispatch(addtoCart({...data.item, quantity:quantity}))
            console.log(data.item)
        }else{
            setErr("You are trying to add quantity of item which is not available.")
        }
        //setMaxquant(fetchAvailableQuanity())
        //setMaxquant(quant)
    }
    return (
    <Card className="panel-body panel">
        <div className={classes.item}>
            <header><a style={{"textDecoration":"none"}} href="#"><h3>{data.item.name}</h3></a>
            <div className={classes.price}>{data.item.price}</div></header>
            <div className={classes.details}>{data.item.desc}</div>
            <p>
                <label htmlFor="quant">Quantity:</label>
                <input id="quant" name="quant" type="number" step={1} min={1} max={maxquant} value={quantity} 
                onChange={(e)=>{setQuantity(e.target.value)}}></input><br></br>
            </p>
            <div className={classes.actions}>
                <button onClick={addToCart}><strong>Add to Cart</strong></button>
            </div>
            {err && <div>{err}</div>}
        </div>
    </Card>
)}
export default ProductItem;