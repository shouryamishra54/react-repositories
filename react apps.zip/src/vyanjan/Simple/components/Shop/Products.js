import { useEffect, useState } from "react"
import ProductItem from "./ProductItem";
import Card from "../UI/Card";
import image from "../../../Assets/meals.jpg";
import UseHttp from "../hooks/use-http";

function Products(){
    const [meals, setMeals]=useState(null);
//    const [error, setError]=useState(null);
//    const [loading, setLoading]=useState(false);
    const {isLoading, error, sendRequest:sendMealRequest}=UseHttp();
    async function fetchMeals(){
        /*try{setLoading(true)
            const response=await fetch("https://meals-75828-default-rtdb.firebaseio.com/meals.json");
            if(response.status === 200 || response.data === 201){
                const data=await response.json();
                let mealdata=[];
                //const mealdata={name:data.key.name, desc:data.key.description, price:data.key.price, quantity:data.key.quantity}
                for(let key in data){
                    mealdata.push({
                        id:key, 
                        name:data[key].name,
                        desc:data[key].description,
                        price:data[key].price,
                    })
                }
                console.log(mealdata)
                setMeals(mealdata)
                setLoading(false)
            }
        }catch(err){
            setError(err.message || "Something went wrong");
        }*/
        sendMealRequest({
            url:"https://meals-75828-default-rtdb.firebaseio.com/meals.json",
        }, function dothis(data){let mealdata=[];
            //const mealdata={name:data.key.name, desc:data.key.description, price:data.key.price, quantity:data.key.quantity}
            for(let key in data){
                mealdata.push({
                    id:key, 
                    name:data[key].name,
                    desc:data[key].description,
                    price:data[key].price,
                    available_quant:data[key].quantity
                })
            }
            console.log(mealdata)
            setMeals(mealdata)
            //setLoading(false)
        })
    }
    useEffect(()=>{fetchMeals()}, [])
    return (<Card style={{"background":`url(${image})`, "fill":"Background"}} >
        {isLoading && <div className="panel-body container">Loading...</div>}
        {meals && <div className="section">
            <header style={{"textTransform":"uppercase", "textAlign":"center"}}>
                <h2>Order your favourite Meal</h2>
            </header>
            {meals.map((item)=>{return (
                <ProductItem item={item}></ProductItem>
            )})}
            </div>}
        {error && <div className="panel-body">{error}</div>}
    </Card>)
}
export default Products;