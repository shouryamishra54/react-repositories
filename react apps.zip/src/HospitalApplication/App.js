import React, { Component } from "react";
import { HashRouter as Router, Route, NavLink, Redirect } from "react-router-dom";
// import SignUpForm from "./pages/SignUpForm";
// import SignInForm from "./pages/SignInForm";
// import "./App.css";
// import ViewProfile from "./pages/ViewProfile";
// import "bootstrap/dist/css/bootstrap.min.css";
// import EditAppointment from "./pages/EditAppointment";
// import AllAppointments from "./pages/AllAppointments";
// import ViewAppointment from "./pages/ViewAppointment";
// import AddPatient from "./pages/AddPatient";
// import BookAppointment from "./pages/BookAppointment";
// import AllPatients from "./pages/AllPatients";
// import ViewPatient from "./pages/ViewPatient";
// import EditPatient from "./pages/EditPatient";

import SignUpForm from "./HospitalApplication/pages/SignUp";
import SignInForm from "./HospitalApplication/pages/SignIn";
import "./HospitalApplication/App.css";
import ViewProfile from "./HospitalApplication/pages/ViewProfile";
import "./APIFetcher/styles/bootstrap.css"
import EditAppointment from "./HospitalApplication/pages/EditAppointment";
import AllAppointments from "./HospitalApplication/pages/AllAppointments";
import ViewAppointment from "./HospitalApplication/pages/ViewAppointment";
import AddPatient from "./HospitalApplication/pages/AddPatient";
import BookAppointment from "./HospitalApplication/pages/BookAppointment";
import AllPatients from "./HospitalApplication/pages/AllPatients";
import ViewPatient from "./HospitalApplication/pages/ViewPatient";
import EditPatient from "./HospitalApplication/pages/EditPatient";
import Example from "./HospitalApplication/pages/NavBar";

function App() {
    return (
      <Router basename="/hospital/">
        <div className="App">
          <div className="App__Form">
            <Route exact path="/" component={SignUpForm}></Route>
            <Route path="/sign-in" component={SignInForm}></Route>
            <Route path="/viewProfile" component={ViewProfile}></Route>
            <Route path="/editAppointment/:appId" component={EditAppointment}></Route>
            <Route path="/allAppointments" component={AllAppointments}></Route>
            <Route path="/viewAppointment/:appId" component={ViewAppointment}></Route>
            <Route path="/addPatient" component={AddPatient}></Route>
            <Route path="/allPatients" component={AllPatients}></Route>
            <Route path="/viewPatient/:id" component={ViewPatient}></Route>
            <Route path="/editPatient/:id" component={EditPatient}></Route>
            <Route path="/bookAppointment" component={BookAppointment}></Route>
          </div>
        </div>
      </Router>)
  }

export default App;