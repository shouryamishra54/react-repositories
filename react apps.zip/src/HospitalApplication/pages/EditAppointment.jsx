import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import NavBar from "./NavBar.jsx";
import {appDetailsData, patientDetailsData} from "./data.js"

import "../App.css";

class EditAppointment extends Component {
  constructor(props) {
    super(props);
    const appointment  = appDetailsData.getAppointmentDetails(props.match.params.appId) || undefined;
    this.state = {
      name: appointment.name|| "",
      disease: appointment.disease||"",
      appdate: appointment.appdate || "",
      slot: appointment.slot || "",
      description: appointment.description || "",
      appointment:appointment
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
  }
  handleSubmit(e) {
    
    // console.log("Details",this.state.appointment.appId,
         // this.state.name,
         // this.state.disease,
         // this.state.appdate,
         // this.state.slot,
         // this.state.description)
      if(true) {
      e.preventDefault();
      
      appDetailsData.edit(
         this.state.appointment.appId,
         this.state.name,
         this.state.disease,
         this.state.appdate,
         this.state.slot,
         this.state.description
        );
      this.props.history.push("/allAppointments");
    }
  }

  canBeSubmitted() {
    const { name, disease, appdate, slot, description } = this.state;
    return (
      name.length > 0 &&
      disease.length > 0 &&
      appdate.length > 0 &&
      slot.length > 0 &&
      description.length > 0
    );
  }
  handleCancel(e) {
    this.props.history.push("/allAppointments");
  }
  handleChange(e) {
    let target = e.target;
    let value = target.type === "checkbox" ? target.checked : target.value;
    let name = target.name;
    
    this.setState({
      [name]: value
    });
  }

  

  render() {
    const {appointment} = this.state;
    const names=patientDetailsData.getName()
    if(!appointment) {
    return (<h1>No appointments Found</h1>);
    }
    return (
      <div>
        <NavBar />
        <div>
          <p
            style={{
              textAlign: "center",
              paddingBottom: "10px",
              paddingTop: "30px",
              fontSize: "2em"
            }}
          >Edit Appointment
          </p>
        </div>
        <div className="FormCenter">
          <form onSubmit={this.handleSubmit} className="FormFields">
          <div className="FormField">
              <label className="FormField__Label" htmlFor="name">Name of the Patient</label>
              <select id="name" name="name" ref={(input)=> this.name = input} onChange={this.handleChange}>
                <header>Select Name</header>
                {names.map((name, index)=>(<option key={index} value={name}>
                  {name}
                </option>))}
              </select>
            </div>
            <div className="FormField">
              <label class="FormField__Label" htmlFor="disease">Disease: </label> 
              <input class="FormField__Input" id="disease" name="disease" value={this.state.disease} onChange={this.handleChange}></input>
            </div>
            <div className="FormField">
              <label class="FormField__Label" htmlFor="appdate">Date: </label> 
              <input class="FormField__Input" type="date" id="appdate" name="appdate" value={this.state.appdate} onChange={this.handleChange}></input>
            </div>
            <div className="FormField">
              <label className="FormField__Label" htmlFor="slot">
                Slots
              </label>
              <select class = "DropDowns" id="slot" name="slot" ref = {(input)=> this.slots = input} onChange={this.handleChange}>
                <header>select slots </header>
                <option value="10-11 AM">10-11 AM</option>
                <option value="1-2 PM">1-2 PM</option>
                <option value="3-4 PM">3-4 PM</option>
                <option value="6-8 PM">6-8 PM</option>
              </select>
            </div>
            <div className="FormField">
              <label class="FormField__Label" htmlFor="description">Description: </label> 
              <input class="FormField__Input" id="description" name="description" value={this.state.description} onChange={this.handleChange}></input>
            </div>
            <ul className="FormField" style={{"listStyle":"none", "columnGap":"20px", "display":"flex"}}>
              <li>
                <button className="FormField__Button" type="submit">Book Now</button>
              </li>
              <li>
                <button className="FormField__Button" type="cancel" onClick={this.handleCancel}>Cancel</button>
              </li>
            </ul>
            {/*it should have fields like name, disease, appdate, slot, description, submit and cancel buttons */}
          </form>
        </div>
      </div>
    );
  }
}

export default EditAppointment;