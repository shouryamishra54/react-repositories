import React, { useState } from "react";
import Medilogo from "../images/Medi-Logo.jpeg";
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Button
} from "reactstrap";
import { Link, useHistory } from "react-router-dom";
import { NavLink as ReactLink } from "react-router-dom";
import { adminDetailsData } from "./data";

const Example = props => {
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);
  const history=useHistory();

  function logoutHandler(){
    try{
      // console.log(adminDetailsData.currentUserId)
      if(adminDetailsData.currentUserId){
        localStorage.clear();
        history("/sign-in");
        // window.location.href="/";
      }else{
        throw new Error("User is not logged in.")
      }
    }catch(e){
      // console.log(e.message)
    }
  }
  return (
    <div className={props.className}>
        <Navbar color="light" light expand="md">
          <NavbarBrand href="/">
            <ul style={{"listStyle":"none", "columnGap":"20px", "display":"flex"}}>
              <li><img
                alt="logo"
                src={Medilogo}
                style={{
                  height: 100,
                  width: 100
                }}
              /></li>
              <li><h3><strong>HOSPITAL</strong></h3></li>
            </ul>
          </NavbarBrand>
          <div className="nav navbar-header navbar-right">
          <Collapse isOpen={isOpen} navbar>
            <Nav navbar>
              <ul style={{"alignItems":"flex-end", "textAlign":"right", "listStyle":"none", "columnGap":"20px", "display":"flex"}}>
              <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
              <NavItem>
                <ReactLink to="/addPatient">Add Patient</ReactLink>
              </NavItem>
              </li>
              <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
              <NavItem>
                <ReactLink to="/allPatients">All Patients</ReactLink>
              </NavItem>
              </li>
              <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
              <NavItem>
                <ReactLink to="/bookAppointment">Book Appointment</ReactLink>
              </NavItem>
              </li>
              <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
              <NavItem>
                <ReactLink to="/allAppointments">All Appointments</ReactLink>
              </NavItem>
              </li>
              <li style={{"alignItems":"flex-end", "fontSize":"large", "fontWeight":"bold"}}>
              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Users
                </DropdownToggle>
                <DropdownMenu end>
                  <DropdownItem>
                    <NavItem><ReactLink to="/viewProfile">View Profile</ReactLink></NavItem>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                    <button onClick={logoutHandler}>Logout</button>
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>
              </li>
              </ul>
            </Nav>
          </Collapse>
          </div>
        </Navbar>
      {/*should have a Navbar brand, toggler and the NavItem (logout) should be linked to sign-in page */}
    </div>
  );
};
export default Example;
