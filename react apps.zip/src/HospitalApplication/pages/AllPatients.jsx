import React, { Component } from "react";
import NavBar from "./NavBar.jsx";
import "../App.css";
import { patientDetailsData } from "./data.js";
import Patient from "../components/Patients/Patient.jsx";
class AllPatients extends Component {
  constructor(props) {
    super(props);
    this.state = {
      patientsList:patientDetailsData.getData()
       //Write function to get the data of patients with the name as appointmentsList:
    };
    this.handleView = this.handleView.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
  }
  handleView(id) {
    
    this.props.history.push(`/viewPatient/${id}`);
  }
  handleEdit(id) {
    
    this.props.history.push(`/editPatient/${id}`);
  }
  handleDelete(e) {
    patientDetailsData.deletePatient(e);
    this.setState({
      patientsList: patientDetailsData.getData(),
    })
  }

  render() {
    const {patientsList} = this.state;  
    return (
      <div style={{ height: "100%" }}>
          <NavBar />
        <form style={{ display: "flex", height: "100%", alignItems: "center" }}>
          {patientsList.length === 0 ? (
            <h1 style={{ textAlign: "center", flexGrow: "1" }}>
              No Patients Found
            </h1>
          ) : (<div style={{ height: "100%", width: "100%" }}>
            <div>
              <p
                style={{
                  textAlign: "center",
                  paddingBottom: "10px",
                  paddingTop: "10px",
                  fontSize: "2em",
                  color: "Slate Blue"
                }}
              >List of All Patients
              </p>
            </div>
            <table className="table table-Responsive">
              <tbody style={{"backgroundColor":"#bbbbbb"}}>
              {patientsList.map((patient)=>(<Patient index={patient.id} patient={patient}></Patient>))
              /*Write code here to create all patients details*/}
              </tbody>
            </table>
          </div>)}
        </form>
      </div>
    );
  }
}

export default AllPatients;