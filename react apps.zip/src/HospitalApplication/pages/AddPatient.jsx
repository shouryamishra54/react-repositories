import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import NavBar from "./NavBar.jsx";
import "../App.css";
import { patientDetailsData } from "./data.js";

class AddPatient extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      email: "",
      dob: "",
      location: "",
      mobile: ""
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
  }

  handleChange(e) {
    let target = e.target;
    let value = target.type === "checkbox" ? target.checked : target.value;
    let name = target.name;

    this.setState({
      [name]: value
    });
  }

  handleSubmit(e) {
    if (this.canBeSubmitted()) {
     
      alert("Patient Added successfully");
      patientDetailsData.add(
        this.state.name,
        this.state.email,
        this.state.dob,
        this.state.location,
        this.state.mobile
      );
      this.props.history.push("/allPatients");
    }
  }
  handleCancel(e) {
    e.preventDefault();
    this.props.history.push("/allPatients");
  }
  canBeSubmitted() {
    const { name, email, dob, location, mobile } = this.state;
    return (
      name.length > 0 &&
      email.length > 0 &&
      dob.length > 0 &&
      location.length > 0 &&
      mobile.length > 0
    );
  }

  render() {
    const isEnabled = this.canBeSubmitted();
    const name = this.state.name;
    const date=new Date();
    return (
      <div>
        <NavBar />
        <div>
          <h3
            style={{
              textAlign: "center",
              paddingBottom: "10px",
              paddingTop: "30px",
              fontSize: "2em"
            }}
          >Adding a Patient
          </h3>
        </div>
        <div className="FormCenter">
        <form onSubmit={this.handleSubmit} className="FormFields">
          <div className="FormField">
            <label class="FormField__Label" htmlFor="name">Name: </label> 
            <input class="FormField__Input" id="name" name="name" onChange={this.handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="email">E-mail ID: </label> 
            <input class="FormField__Input" type="email" id="email" name="email" onChange={this.handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="dob">Date of Birth: </label> 
            <input class="FormField__Input" type="date" id="dob" name="dob" onChange={this.handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="location">Location: </label> 
            <input class="FormField__Input" id="location" name="location" onChange={this.handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="mobile">Mobile No: </label> 
            <input class="FormField__Input" type="number" id="mobile" name="mobile" length="10" onChange={this.handleChange}></input>
          </div>          
          <ul className="FormField" style={{"listStyle":"none", "columnGap":"20px", "display":"flex"}}>
            <li>
              <button className="FormField__Button" type="submit">Register</button>
            </li>
            <li>
              <button className="FormField__Button" type="cancel" onClick={this.handleCancel}>Cancel</button>
            </li>
          </ul>
        </form>
        </div>
        {/* Write code here to create fields and input labels for name,email,dob,mobileno and location  */}
      </div>
    );
  }
}

export default AddPatient;