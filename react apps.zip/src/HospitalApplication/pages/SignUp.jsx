import React, { Component } from "react";
import { NavLink, useHistory } from "react-router-dom";
import DatePicker from "react-datepicker";
import {adminDetailsData} from "./data.js"

import "../App.css";
import { useState } from "react";

function SignUpForm(){
  const history=useHistory();
  const [formState, setFormState]=useState({
    uname: "",
    email: "",
    password: "",
    dob: "",
    mobileno: "",
    location: ""
  })
  function handleChange(e) {
    e.preventDefault();
    let target = e.target;
    let value = target.type === "checkbox" ? target.checked : target.value;
    let name = target.name;
    setFormState({...formState, [name]:value})
  }
  function handleSubmit(e) { 
    e.preventDefault();
    // console.log(formState)
    if (canBeSubmitted()) {
      adminDetailsData.add(
        formState.uname,
        formState.email,
        formState.password,
        formState.dob,
        formState.mobileno,
        formState.location
        );
      setFormState({name: e.target.value});
      history.push("/sign-in");
    }
  }
  function canBeSubmitted(){
    return (
      formState.uname.length > 4 &&
      formState.email.length > 4 &&
      formState.password.length > 4 &&
      formState.dob.length > 4 &&
      formState.mobileno.length > 4 &&
      formState.location.length > 4 
    );
  }
  return (
    <div>
      <div>
        <h3 style={{ textAlign: "center", paddingBottom: "10px" }}>
          Digital Medical Record Database
        </h3>
      </div>
      <div className="FormCenter">
        <div className="FormTitle">
          <NavLink to="/sign-in" className="FormTitle__Link">
            Login
          </NavLink>{" "}
          or
          <NavLink exact to="/" className="FormTitle__Link">
            Register
          </NavLink>
        </div>

        <form onSubmit={handleSubmit} className="FormFields">
      
          <div className="FormField">
            <label class="FormField__Label" htmlFor="uname">Username: </label> 
            <input class="FormField__Input" id="uname" name="uname" onChange={handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="email">E-mail ID: </label> 
            <input class="FormField__Input" type="email" id="email" name="email" onChange={handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="password">Password: </label> 
            <input class="FormField__Input" type="password" id="password" name="password" onChange={handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="dob">Date of Birth: </label> 
            <input class="FormField__Input" type="date" id="dob" name="dob" onChange={handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="mobilenono">Mobile No: </label> 
            <input class="FormField__Input" type="number" id="mobileno" name="mobileno" length="10" onChange={handleChange}></input>
          </div>
          <div className="FormField">
            <label class="FormField__Label" htmlFor="location">Location: </label> 
            <input class="FormField__Input" id="location" name="location" onChange={handleChange}></input>
          </div>
          {/*Write code here to create uname, email, dob, location, mobileno labels and inputs */}
          
          <div className="FormField">
              <button className="FormField__Button" type="submit">Register</button>
            {/* Write code here to create Register Button */}
          </div>
        </form>
      </div>
    </div>
  );
}

class SignUpForm1 extends Component {
  constructor(props) {
    super(props);

    this.state = {
      uname: "",
      email: "",
      password: "",
      dob: "",
      mobileno: "",
      location: ""
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
    let target = e.target;
    let value = target.type === "checkbox" ? target.checked : target.value;
    let name = target.name;

    this.setState({
      [name]: value
    });
  }

  handleSubmit(e) { 
    
    e.preventDefault();
    
    if (this.canBeSubmitted()) {
      adminDetailsData.add(
        this.state.uname,
        this.state.email,
        this.state.password,
        this.state.dob,
        this.state.mobileno,
        this.state.location
        );
      this.setState({name: e.target.value});
      this.props.history.push("/sign-in");
    }
  }
  canBeSubmitted() {
    const {
      uname,
      email,
      password,
      dob,
      mobileno,
      location
      
      
    } = this.state;
    return (
      uname.length > 4 &&
      email.length > 4 &&
      password.length > 4 &&
      dob.length > 4 &&
      mobileno.length > 4 &&
      location.length > 4 
      
    );
  }

  render() {
    return (
      <div>
        <div>
          <h3 style={{ textAlign: "center", paddingBottom: "10px" }}>
            Digital Medical Record Database
          </h3>
        </div>
        <div className="FormCenter">
          <div className="FormTitle">
            <NavLink to="/sign-in" className="FormTitle__Link">
              Login
            </NavLink>{" "}
            or
            <NavLink exact to="/" className="FormTitle__Link">
              Register
            </NavLink>
          </div>

          <form onSubmit={this.handleSubmit} className="FormFields">
        
            <div className="form">

            </div>
            {/*Write code here to create uname, email, dob, location, mobileno labels and inputs */}
            
            <div className="FormField">
              {/* Write code here to create Register Button */}
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default SignUpForm;