import React, { Component } from "react";
import NavBar from "./NavBar";
import {appDetailsData} from "./data.js"

class ViewAppointment extends Component {
  constructor(props) {
    super(props);
    this.state = {
     appointment : appDetailsData.getAppointmentDetails(props.match.params.appId)
    };

    this.handleClose = this.handleClose.bind(this);
  }

  handleClose(e) {
    this.props.history.push("/allAppointments");
  }

  render() {
   const {appointment} = this.state;
   if(!appointment) {
     return <h1>No appointments found</h1>
   }
    return (
      <div>
        <NavBar />
        <div>
          <div>
            <p
              style={{
                textAlign: "center",
                paddingBottom: "10px",
                paddingTop: "30px",
                fontSize: "2em"
              }}
            >
              Viewing Appointment
            </p>
          </div>
        </div>
        <div className="FormCenter">
          <form className="FormFields">
            <div className="FormField">
              <div className="FormField__Label">
                <p>{appointment.name}</p>
              </div>
            </div>
            <div className="FormField">
              <div className="FormField__Label">
                <p>{appointment.disease}</p>
              </div>
            </div>
            <div className="FormField">
              <div className="FormField__Label">
                <p>{appointment.appdate}</p>
              </div>
            </div>
            <div className="FormField">
              <div className="FormField__Label">
                <p>{appointment.slot}</p>
              </div>
            </div>
            <div className="FormField">
              <div className="FormField__Label">
                <p>{appointment.description}</p>
              </div>
            </div>
            {/* Write code here to display name, appdate, slot, description and disease */}
            <div className="FormField">
              <button className="FormField__Button" type="cancel" onClick={this.handleClose}>Close</button>
              {/*Write code here to create a close button */}
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default ViewAppointment;