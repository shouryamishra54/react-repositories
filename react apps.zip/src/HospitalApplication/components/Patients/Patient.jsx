import { useHistory } from "react-router-dom";
import { patientDetailsData } from "../../pages/data";

function Patient(data){
    const appId=data.index;
    const patient=data.patient;
    const history=useHistory();
    function handleView() {
        history.push(`/viewPatient/${appId}`);
    }
    function handleEdit() {
        history.push(`/editPatient/${appId}`);
    }
    function handleDelete(e) {
        e.preventDefault()
        patientDetailsData.deletePatient(e);
        history.push(`/allPatients`);
    }    

    return (<tr>
        <td style={{"columnGap":"20px"}}>
          {patient.name}
        </td>
        <td className="navbar-right" style={{"columnGap":"20px"}}>
          <button className="FormField__Button" onClick={handleEdit}>Edit</button>
          <button className="FormField__Button" onClick={handleView}>View</button>
        </td>
        </tr>)
}
export default Patient