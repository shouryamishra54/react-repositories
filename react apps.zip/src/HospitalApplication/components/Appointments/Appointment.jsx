import { useHistory } from "react-router-dom";
import { appDetailsData } from "../../pages/data";

function Appointment(data){
    const appId=data.index;
    const appointment=data.appointment;
    const history=useHistory();
    function handleView() {
        history.push(`/viewAppointment/${appId}`);
    }
    function handleEdit() {
        history.push(`/editAppointment/${appId}`);
    }
    function handleDelete(){
        appDetailsData.deleteAppointment(appId);
        history.push(`/allAppointments`);
    }
    return (<tr>
        <td>{appointment.name}</td>
        <td className="navbar-right" style={{"columnGap":"20px"}}>
            <button className="FormField__Button" onClick={handleView}>View</button>
            <button className="FormField__Button" onClick={handleEdit}>Edit</button>
            <button className="FormField__Button" onClick={handleDelete}>Delete</button>
        </td>
    </tr>)
}
export default Appointment