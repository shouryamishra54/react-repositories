import { Switch, Route } from "react-router-dom";
import Layout from "./Blog_Project/components/Layout/Layout";
import Home from "./Blog_Project/pages/Home/Home";
import Login from "./Blog_Project/pages/Login/Login";
import Signup from "./Blog_Project/pages/Signup/Signup";
import NewPost from "./Blog_Project/pages/Posts/NewPost";
import UserPosts from "./Blog_Project/pages/Posts/UserPosts";
import EditPost from "./Blog_Project/pages/Posts/EditPost";
import UserProfile from "./Blog_Project/pages/Users/UserProfile";
import Post from "./Blog_Project/pages/Posts/Post";
import LoggedInRoute from "./Blog_Project/LoggedInRoute";
import NotLoggedInRoute from "./Blog_Project/NotLoggedInRoute";
import NotFound from "./Blog_Project/pages/NotFound/NotFound";

function App() {
  return (
    <Layout>
      <Switch>
        <Route exact path={["/", "/home"]} component={Home} />
        <NotLoggedInRoute exact path="/login" component={Login} />
        <NotLoggedInRoute exact path="/signup" component={Signup} />
        <Route exact path="/user/posts" component={UserPosts} />
        <Route exact path="/user/profile" component={UserProfile} />
        <Route exact path="/posts/view" component={Post} />
        <LoggedInRoute exact path="/posts/new" component={NewPost} />
        <LoggedInRoute exact path="/posts/edit" component={EditPost} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

export default App;
