import classes from "./Login.module.css";
import Button from "../UI/Button/Button.js";
import Card from "../UI/Card/Card.js";
import { useEffect, useState } from "react";
//Use of useEffect and useState and udating same variable using a single function.

function Login(data){
    const [userEmail, setUserEmail]=useState('')
    const [userEmailValid, setUserEmailValid]=useState(false)
    const [password, setPassword]=useState('')
    const [passwordValid, setPasswordValid]=useState(false)
    const [formIsValid, setFormIsValid]=useState(false)
    useEffect(()=>{
        const identifier=setTimeout(()=>{
            console.log("Checking form Validity.")
            setFormIsValid(userEmail.trim().includes('@') && password.trim().length>=8);
        }, 500)
        return (()=>{
            console.log("Cleanup")
            clearTimeout(identifier)
        })
    }, [userEmail, password])
    function setEmailHandler(event){
        setUserEmail(event.target.value);
        setUserEmailValid(event.target.value.trim().includes('@'))
        //setFormIsValid(event.target.value.trim().includes('@') && password.trim().length>=8)
    }
    function setPasswordHandler(event){
        setPassword(event.target.value);
        setPasswordValid(event.target.value.trim().length>=8)
        //setFormIsValid(event.target.value.trim().length>=8 && userEmail.trim().includes('@'))
    }
    function submitHandler(event){
        event.preventDefault();
        if(userEmailValid && passwordValid){
            data.onLogin(userEmail, password)
            setUserEmail('');
            setPassword('');
        }
    }
    return (<Card className={classes['new-login']}>
        <form onSubmit={submitHandler}>
            <div className={classes.login}>
                <div className={classes.control}>
                    <label>Enter Email: </label>
                    <input type="text" id="useremail" name="useremail" 
                    value={userEmail} onChange={setEmailHandler}></input>
                    <label>Enter Password: </label>
                    <input type="password" id="userpass" name="userpass" 
                    value={password} onChange={setPasswordHandler}></input>
                    <Button className={classes.button} onClick={data.onLogin} disabled={!formIsValid}>Submit</Button>
                </div>
            </div>
        </form>
    </Card>);
}
export default Login;