import classes from "./Login.module.css";
import Button from "../UI/Button/Button.js";
import Card from "../UI/Card/Card.js";
import { useEffect, useReducer, useState } from "react";
//Use of useEffect and useState and udating same variable using a single function.
function emailReducer(state, action){
    if(action.type === 'USER_INPUT'){
        return {value:action.val, valid:action.val.trim().includes('@')}
    }if(action.type === 'INPUT_BLUR'){
        return {value:state.val, valid:state.val.trim().includes('@')}
    }
    return {value:'', valid:false}
}
function passwordReducer(state, action){
    if(action.type === 'USER_INPUT'){
        return {value:action.val, valid:action.val.trim().length>=8}
    }if(action.type === 'INPUT_BLUR'){
        return {value:state.val, valid:state.val.trim().length>=8}
    }
    return {value:'', valid:false}
}
function Login(data){
    //const [userEmail, setUserEmail]=useState('')
    //const [userEmailValid, setUserEmailValid]=useState(false)
    //const [password, setPassword]=useState('')
    //const [passwordValid, setPasswordValid]=useState(false)
    const [formIsValid, setFormIsValid]=useState(false)
    const [emailState, dispatchEmail]=useReducer(emailReducer, {value:'', valid:false})
    const [passwordState, dispatchPassword]=useReducer(passwordReducer, {value:'', valid:false})
    useEffect(()=>{
        const identifier=setTimeout(()=>{
            console.log("Checking form Validity.")
            setFormIsValid(emailState.valid && passwordState.valid);
        }, 500)
        return (()=>{
            console.log("Cleanup")
            clearTimeout(identifier)
        })
    }, [emailState, passwordState])
        function setEmailHandler(event){
        dispatchEmail({type:"USER_INPUT", val:event.target.value})
        //setUserEmailValid(event.target.value.trim().includes('@'))
        //setFormIsValid(event.target.value.trim().includes('@') && password.trim().length>=8)
    }
    function setPasswordHandler(event){
        dispatchPassword({type:"USER_INPUT", val:event.target.value})
        //setPasswordValid(event.target.value.trim().length>=8)
        //setFormIsValid(event.target.value.trim().length>=8 && userEmail.trim().includes('@'))
    }
    function submitHandler(event){
        event.preventDefault();
        if(emailState.valid && passwordState.valid){
            data.onLogin(emailState.value, passwordState.value)
            dispatchEmail()
            dispatchPassword()
        }
    }
    return (<Card className={classes['new-login']}>
        <form onSubmit={submitHandler}>
            <div className={classes.login}>
                <div className={classes.control}>
                    <label>Enter Email: </label>
                    <input type="text" id="useremail" name="useremail" 
                    value={emailState.value} onChange={setEmailHandler}></input>
                    <label>Enter Password: </label>
                    <input type="password" id="userpass" name="userpass" 
                    value={passwordState.value} onChange={setPasswordHandler}></input>
                    <Button className={classes.button} onClick={data.onLogin} disabled={!formIsValid}>Submit</Button>
                </div>
            </div>
        </form>
    </Card>);
}
export default Login;