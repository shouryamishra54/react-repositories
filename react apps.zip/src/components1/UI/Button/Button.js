import classes from "./Button.module.css";

function Button(data){
    return (<button className={`${classes.button} ${data.className}`}
        onClick={data.onClick}
        disabled={data.disabled}>
        {data.children}
        </button>);
}
export default Button;