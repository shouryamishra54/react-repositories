import classes from "./Home.module.css";
import Button from "../UI/Button/Button.js";
import Card from "../UI/Card/Card.js";

function Home(){
    return (<Card className={classes.home}>
        <h2>Welcome to the World of Gods</h2>
        <Button>Explore More...</Button>
    </Card>)
}
export default Home;