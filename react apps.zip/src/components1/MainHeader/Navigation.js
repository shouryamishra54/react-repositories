import classes from "./Navigation.js";
import Button from "../UI/Button/Button.js";
import AuthContext from "../../Store/auth-context.js";
import { useContext } from "react";
//Context API used for the first time Navigation in MainHeader
//Use of React.useContext for the first time.

function Navigation(){
    const context=useContext(AuthContext);
    return (
    <nav className={classes.nav}>
        <ul>
            {context.isLoggedIn &&
            <li>
                <a href="/">Users</a>
            </li>}
            {context.isLoggedIn &&
            <li>
                <a href="/">Admin</a>
            </li>}
            {context.isLoggedIn &&
            <li>
                <Button onClick={context.onLogout} className={classes.button}>Logout</Button>
            </li>}
        </ul>
    </nav>
    );
}
export default Navigation;