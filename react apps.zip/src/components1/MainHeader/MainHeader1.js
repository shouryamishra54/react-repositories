import classes from "./MainHeader.module.css";
//import Button from "../UI/Button/Button.js";
import Navigation from "./Navigation.js";

function MainHeader(data){
    return (<div className={classes['main-header']}>
        <a style={{"text-decoration":"none"}} href="/"><h1>A Typical Page</h1></a>
        <Navigation onLogout={data.onLogout}></Navigation>
        {data.children}
    </div>)
}
export default MainHeader;