import classes from "./Navigation.js";
import Button from "../UI/Button/Button.js";
import AuthContext from "../../Store/auth-context1.js";
//Context API used for the first time Navigation in MainHeader

function Navigation(data){
    return (<AuthContext.Consumer>
        {(data1)=>{
            return (
            <nav className={classes.nav}>
                <ul>
                    {data1.isLoggedIn &&
                    <li>
                        <a href="/">Users</a>
                    </li>}
                    {data1.isLoggedIn &&
                    <li>
                        <a href="/">Admin</a>
                    </li>}
                    {data1.isLoggedIn &&
                    <li>
                        <Button onClick={data.onLogout} className={classes.button}>Logout</Button>
                    </li>}
                </ul>
            </nav>)
        }}
    </AuthContext.Consumer>);
}
export default Navigation;