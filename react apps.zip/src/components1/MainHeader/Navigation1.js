import classes from "./Navigation.js";
import Button from "../UI/Button/Button.js";
//First Navigation.js File used for MainHeader Navigation

function Navigation(data){
    return (<nav className={classes.nav}>
        <ul>
            {data.isLoggedIn &&
            <li>
                <a href="/">Users</a>
            </li>}
            {data.isLoggedIn &&
            <li>
                <a href="/">Admin</a>
            </li>}
            {data.isLoggedIn &&
            <li>
                <Button onClick={data.onLogout} className={classes.button}>Logout</Button>
            </li>}
        </ul>
    </nav>);
}
export default Navigation;