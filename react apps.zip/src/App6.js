import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import Header from "./APIFetcher/custom/Header";
import Footer from "./APIFetcher/custom/Footer";
import ErrorBoundary from "./APIFetcher/components/ErrorBoundary";
import Tasks from "./APIFetcher/components/container/Tasks/Tasks.js";
import NewTask from "./APIFetcher/components/container/NewTask/NewTask.js";
import UseHttp from "./APIFetcher/components/hooks/use-http";

//Use of Customized Hooks for URL Fetching
function App(){
    const {isLoading, error, sendRequest:fetchTasks}=UseHttp();
    const [tasks, setTasks]=useState();
    function transformData(data){
        const loadTasks=[];
        for(let keys in data){
            loadTasks.push({id:keys,taskname:data[keys].text})
        }
        console.log(loadTasks)
        setTasks(loadTasks);
    }
    useEffect(()=>{
        fetchTasks(
            {url: "https://react-http-b2f00-default-rtdb.firebaseio.com/tasks.json"},
            transformData);
    },[fetchTasks])
    function addTaskHandler(task){
        setTasks((curState)=>curState.concat(task))
    }
    return (<div className="App">
    <div className="page-header">
        <h1>Explaination of Customized Hooks</h1>
    </div>
    <body>
        <React.Fragment>
            <div className="panel-heading">
                <Header></Header>
            </div>
            <ErrorBoundary>
                <NewTask onAddTask={addTaskHandler}></NewTask>
            </ErrorBoundary>
            <ErrorBoundary>
                <div className="panel panel-body">
                    <div>{isLoading && "Loading..."}</div>
                    <div>{tasks && <Tasks tasks={tasks}></Tasks>}</div>
                </div>
            </ErrorBoundary>
            <ErrorBoundary>
                <div className="panel">
                    {error && <div>{error}</div>}
                </div>
            </ErrorBoundary>
            <div className="panel-footer">
                <Footer></Footer>
            </div>
        </React.Fragment>
    </body>
</div>)
}
export default App;