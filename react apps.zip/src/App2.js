import React, { useContext, useEffect, useState } from "react";
import "./App.css";
import Header from "./Food-app/Components/Layout/Header.js";
import Cart from "./Food-app/Components/Cart/Cart.js";
import Card from "./Food-app/Components/UI/Card";
import Meals from "./Food-app/Components/Meals/Meals";
import CartProvider from "./Food-app/Store/ContextProvider";
//import Home from "./components1/Home/Home.js";
//import Login from "./components1/Login/Login.js";
//import MainHeader from "./components1/MainHeader/MainHeader.js";
//import AuthContext from "./Store/auth-context.js";
//import {AuthContextProvider} from "./Store/auth-context.js";
//import {AuthContextProvider} from "./Store/auth-context.js";
//Building and using a custom context provider cmp

function App(){
    /*const [isLoggedIn, setIsLoggedIn]=useState(false);
    useEffect(()=>{
        const storedUserLoggedInInformation=localStorage.getItem('isloggedin');
        if(storedUserLoggedInInformation === '1'){
            setIsLoggedIn(true)
        }
    }, [])
    function loginHandler(){
        //if(!localStorage.getItem('isloggedin')){
            setIsLoggedIn(true)
            localStorage.setItem('isloggedin', '1')
        //}
    }
    function logoutHandler(){
        //if(localStorage.getItem('isloggedin')){
            setIsLoggedIn(false)
            localStorage.removeItem('isloggedin')
        //}
    }*/
    //const context=useContext(AuthContext);
    //console.log(context.isLoggedIn)
    const [cartIsShown, setCartIsShown]=useState();
    function hideCartHandler(){
        console.log("Hide Cart")
        setCartIsShown(null)
    }
    function showCartHandler(){
        console.log("Show Cart")
        setCartIsShown(true)
    }
    return (<div className="App"><Card>
        <React.Fragment><CartProvider>
            {cartIsShown && <Cart onClose={hideCartHandler}></Cart>}
            <Header onShow={showCartHandler}></Header>
            <main>
                <Meals></Meals>
            </main></CartProvider>
        </React.Fragment></Card>
    </div>
    );
}
export default App;