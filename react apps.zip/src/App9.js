import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import { BrowserRouter, Redirect, Route, Switch, Routes } from "react-router-dom";
import Layout from "./RouterTutorial/Quotes/Components/Layout/Layout";
import Quotes from "./RouterTutorial/Quotes/Pages/Quotes";
import QuoteDetail from "./RouterTutorial/Quotes/Pages/QuoteDetail";
import NewQuote from "./RouterTutorial/Quotes/Pages/NewQuote";
//USE OF ROUTERS
//import Counter from "./use-of-redux/components/Counter"
//import Auth from "./use-of-redux/components/Auth"
//import Header from "./use-of-redux/components/Header"
//import UserProfile from "./use-of-redux/components/UserProfile"
import defautclasses from "./APIFetcher/styles/default.module.css";
import AuthPage from "./RouterTutorial/Quotes/Pages/AuthPage";
import ProfilePage from "./RouterTutorial/Quotes/Pages/ProfilePage";
import ErrorPage from "./RouterTutorial/Quotes/Pages/ErrorPage";
//import ProductDetail from "./RouterTutorial/Link/Component/Pages/ProductDetails";

//import { useSelector } from "react-redux";
//import store from "./use-of-redux/store/index";

//Use of Redux State Management
function App(){
    //const loggedin=useSelector(state=>state.authentication.login)
    return (<div className="App">
        <div className="page-header">
            <h1>Explaination of React-Router</h1>
        </div>
        <body>
            <Layout>
                <Switch>
                    <Route path="/" exact>
                        <Redirect to={"/quotes"}></Redirect>
                    </Route>
                    <Route path="/quotes" exact>
                        <Quotes />
                    </Route>
                    <Route path="/quotes/:quoteID">
                        <QuoteDetail />
                    </Route>
                    <Route path="/new-quote">
                        <NewQuote />
                    </Route>
                    <Route path="/auth">
                        <AuthPage />
                    </Route>
                    <Route path="/myprofile">
                        <ProfilePage />
                    </Route>
                    <Route path="*">
                        <ErrorPage />
                    </Route>
                </Switch>
            </Layout>
        </body>
    </div>)
}
export default App;