import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import { BrowserRouter, Redirect, Route, Switch, Routes } from "react-router-dom";
import MainHeader from "./RouterTutorial/Link/Component/Layout/MainHeader";
import Welcome from "./RouterTutorial/Link/Component/Pages/Welcome";
import Products from "./RouterTutorial/Link/Component/Pages/Products";
//USE OF ROUTERS
//import Counter from "./use-of-redux/components/Counter"
//import Auth from "./use-of-redux/components/Auth"
//import Header from "./use-of-redux/components/Header"
//import UserProfile from "./use-of-redux/components/UserProfile"
import defautclasses from "./APIFetcher/styles/default.module.css";
import ProductDetail from "./RouterTutorial/Link/Component/Pages/ProductDetails";

//import { useSelector } from "react-redux";
//import store from "./use-of-redux/store/index";

//Use of Redux State Management
function App(){
    //const loggedin=useSelector(state=>state.authentication.login)
    
    return (<div className="App">
        <div className="page-header">
            <h1>Explaination of React-Router</h1>
        </div>
        <body>
            <MainHeader />
            <div className="container">
            <React.Fragment>
                <Switch>
                    <Route path="/" exact>
                        <Redirect to={"/welcome"}></Redirect>
                    </Route>
                    <Route path="/welcome">
                        <Welcome />
                    </Route>
                    <Route path="/products" exact>
                        <Products />
                    </Route>
                    <Route path="/products/:productID">
                        <ProductDetail />
                    </Route>
                </Switch>
            </React.Fragment>
            </div>
        </body>
    </div>)
}
export default App;