import { useParams } from "react-router-dom"

function ProductDetail(){
    const param=useParams();
    return (
        <div className="section">
            <div className="container panel-body">
                <h2>Product Details:</h2>
                <p><strong>{param.productID}</strong></p>
            </div>
        </div>
    )
}
export default ProductDetail