import { NavLink, Route, useParams } from "react-router-dom";
import ProductDetail from "./ProductDetails";
function Products(){
    return(<section className="section">
        <div className="panel-body container">
        <h1><strong>Product Page</strong></h1>
            <ul style={{"listStyleType":"none"}}>
                <li>
                    <NavLink to={`/products/p1`}>Book</NavLink>
                </li>
                <li>
                    <NavLink to={`/products/p2`}>Carpet</NavLink>
                </li>
                <li>
                    <NavLink to={`/products/p3`}>Online Course</NavLink>
                </li>
            </ul>
        </div>
    </section>)
}
export default Products