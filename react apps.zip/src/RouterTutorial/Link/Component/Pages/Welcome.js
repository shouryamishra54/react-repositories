import { Link, Route, useParams } from "react-router-dom"

function Welcome(){
    return (<div className="section">
        <div className="center-block panel-body container" style={{}}>
            <h1><strong>Welcome</strong></h1>
        </div>
        </div>)
}
export default Welcome