import {NavLink, Link, Route} from "react-router-dom"
function MainHeader(){
    return (
    <div>
        <div className="panel-header container">
            <a style={{"textDecoration":"none"}} href="/welcome">
                <div className="container"><strong><h1>Introduction to Router</h1></strong></div>
            </a>
        </div>            
        <div className="navvar-nav">
            <ul className="nav navbar navbar-nav">
                <li>
                    <NavLink to="/welcome">Welcome</NavLink>
                </li>
                <li>
                    <NavLink to="/products">Products</NavLink>
                </li>
            </ul>
        </div>
    </div>)
}
export default MainHeader