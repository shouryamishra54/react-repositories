
function ProfilePage(){
    return (
        <div><h2>Profile Page...</h2></div>
    )
}
export default ProfilePage