import QuoteForm from "../Components/Quotes/QuoteForm"

function NewQuote(){
    return (
        <div className="container panel-body">
            <QuoteForm></QuoteForm>
        </div>
    )
}
export default NewQuote