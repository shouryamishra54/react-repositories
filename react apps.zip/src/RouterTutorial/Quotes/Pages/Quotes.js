import { useEffect, useState } from "react";
//import UseHttp from "../../hooks/use-http";
//import { getAllQuotes } from "../../lib/api";
import UseHttp from "../../hooks/use-http1";
import { getAllQuotes } from "../../lib/api1";
import QuoteList from "../Components/Quotes/QuoteList";
import { Quote } from "../../Quotes/Models/Model";

function Quotes(){
     
    /*const DUMMY_QUOTES = [
        { id: 'q1', author: 'Max', text: 'Learning React is fun!' },
        { id: 'q2', author: 'Maximilian', text: 'Learning React is great!' },
    ];*/
    /*const quotes=sessionStorage.getItem("quotes")?
    JSON.parse(sessionStorage.getItem("quotes")):DUMMY_QUOTES;
    if(!sessionStorage.getItem("quotes")){
        sessionStorage.setItem("quotes", JSON.stringify(quotes))
    }
    console.log(JSON.parse(sessionStorage.getItem("quotes")));
    */
    //const [quotes, setQuotes]=useState()
    //console.log(quotes)
    const {isLoading, error, data:quotes, sendRequest:sendAllQuotesRequest}=UseHttp(getAllQuotes);
    /*async function fetchAllQuotes(){
        let newQuotes=Array();
        await sendAllQuotesRequest(getAllQuotes(), (data)=>{
            let cnt=0;
            //setQuotes(Object.entries(data))
            
            const entries=Object.entries(data)
            for(let key in entries){
                newQuotes[cnt++]=({id:entries[key][0], author:entries[key][1].author, text:entries[key][1].text})
            }
            console.log(newQuotes)
            setQuotes(newQuotes)
        })
        return newQuotes;
    }*/
    useEffect(()=>{
        sendAllQuotesRequest();
        setTimeout(async()=>{
            await sendAllQuotesRequest();
        }, 500)
    }, [])
    let cnt=0;
    let newQuotes=Array();
    /*for(let key in quotes){
        newQuotes[cnt++]=({id:quotes[key][0], author:quotes[key][1].author, text:quotes[key][1].text})
    }
    setQuotes(newQuotes)
    */
    return (
        <div className="container">
            <header><h1>Quotes</h1></header>
            <ul className="list-unstyled">
                {quotes && <QuoteList quotes={quotes}></QuoteList>}
            </ul>
        </div>
    )
}
export default Quotes