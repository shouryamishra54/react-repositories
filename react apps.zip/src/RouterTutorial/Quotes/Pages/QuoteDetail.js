import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
//import UseHttp from "../../hooks/use-http";
//import { getQuote } from "../../lib/api";
import UseHttp from "../../hooks/use-http1";
import { getQuote } from "../../lib/api1";

import HighlightedQuote from "../Components/Quotes/HighlightedQuote";

function QuoteDetail(){
    const params=useParams();
    //const quotebyid=JSON.parse(sessionStorage.getItem("quotes")).find((quote)=>{return quote.id===params.quoteID})
    //const [quotebyid, setQuotebyid]=useState();
    const {isLoading, error, data:quotebyid, sendRequest:getQuoteRequest}=UseHttp(getQuote);
    /*async function fetchQuoteById(){
        let quote
        await getQuoteRequest(getQuote(params.quoteID), (data)=>{
            setQuotebyid({id:params.quoteID,...data})
        })
    }*/
    useEffect(()=>{
        getQuoteRequest(params.quoteID)
        //fetchQuoteById()
    }, [])
    console.log(quotebyid)
    return (
        <div className="container panel-body">
            <section className="section">
                <div style={{"textDecorationThickness":10, "textDecorationStyle":"solid"}}>
                    <blockquote>
                        {(quotebyid && (quotebyid.author && quotebyid.text)) && <HighlightedQuote quote={quotebyid}></HighlightedQuote>}
                        {(!quotebyid || !(quotebyid.author && quotebyid.text)) && <div>No Quote Found</div>}
                    </blockquote>
                </div>
            </section>
        </div>
    )
}
export default QuoteDetail