import AuthForm from "../Components/AuthForm/AuthForm"
import LoginForm from "../Components/AuthForm/LoginForm"

function AuthPage(){
    return (
        <div><LoginForm></LoginForm></div>
    )
}
export default AuthPage