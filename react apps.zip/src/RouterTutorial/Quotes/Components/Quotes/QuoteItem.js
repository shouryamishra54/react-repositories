import { useState } from "react"
import { NavLink } from "react-router-dom"
import CommentForm from "../Comments/CommentForm";
import Comments from "../Comments/Comments";

function QuoteItem(data){
    const [commentsLoaded, setCommentsLoaded]=useState(false);
    const [startAddingComment, setStartAddingComment]=useState(false);
    function loadCommentsHandler(){
        setCommentsLoaded(curr=>!curr)
    }
    function addCommentHandler(){
        setStartAddingComment(true)
    }
    return (
        <figure className="figure">
            <blockquote className="blockquote">
                <h4><strong>{data.quote.text}</strong></h4>
                <figcaption style={{"textAlign":"center"}}>
                    <span> - </span>{data.quote.author}
                </figcaption>
            </blockquote>
            <div className="right">
                <NavLink className="btn" to={`/quotes/${data.quote.id}`}>
                    View FullScreen
                </NavLink>
            </div>
        </figure>
    )
}
export default QuoteItem