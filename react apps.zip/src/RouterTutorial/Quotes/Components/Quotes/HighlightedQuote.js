import { useState } from "react"
import CommentForm from "../Comments/CommentForm";
import Comments from "../Comments/Comments";

function HighlightedQuote(data){
    const [commentsLoaded, setCommentsLoaded]=useState(false);
    const [startAddingComment, setStartAddingComment]=useState(false);
    function loadCommentsHandler(){
        setCommentsLoaded(curr=>!curr)
    }
    function startAddingCommentHandler(){
        setStartAddingComment(true)
        setCommentsLoaded(false)
    }
    function commentAddedHandler(){
        setStartAddingComment(false)
        setCommentsLoaded(true)
    }
    return (
        <div className="body panel-body container-fluid">
            <figure className="figure">
            <blockquote className="blockquote">
                <h2><strong>{data.quote.text}</strong></h2>
            </blockquote>
            <figcaption>
                <strong>{data.quote.author}</strong>
            </figcaption>
            <div>
                {!startAddingComment && !commentsLoaded && <div className="left btn">
                    <button onClick={loadCommentsHandler}>Load Comments</button>
                </div>}
                {!startAddingComment && commentsLoaded && <div className="left btn">
                    <button onClick={loadCommentsHandler}>Hide Comments</button>
                </div>}
                {!startAddingComment && <div className="left btn">
                    <button onClick={startAddingCommentHandler}>Add Comment</button>    
                </div>}
                {!startAddingComment && commentsLoaded && <Comments quoteID={data.quote.id}></Comments>}
                {startAddingComment && <CommentForm quoteID={data.quote.id} onAdding={commentAddedHandler}></CommentForm>}
            </div>
        </figure>
        </div>
    )
}
export default HighlightedQuote