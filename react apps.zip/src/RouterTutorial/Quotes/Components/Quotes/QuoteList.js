import QuoteItem from "./QuoteItem"
function QuoteList(data){
    return (
        <div className="container panel-body">
            {data.quotes.map((quote)=>{return <QuoteItem quote={quote}></QuoteItem>})}
        </div>
    )
}
export default QuoteList;