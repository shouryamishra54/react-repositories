import { useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
//import UseHttp from "../../../hooks/use-http";
//import { addQuote } from "../../../lib/api";
import UseHttp from "../../../hooks/use-http1";
import { addQuote } from "../../../lib/api1";
import {Quote} from "../../../Quotes/Models/Model";
//const Model=require("../../../Quotes/Models/Model")

function QuoteForm(){
    const {isLoading, error, data:addedQuote, sendRequest:addQuoteToList}=UseHttp(addQuote);
    /*class Quote{
        constructor({id, author, text, comments=[]}){
            this.id=id
            this.author=author
            this.text=text
            this.comments=comments
        }
        getComments(){
            return this.comments
        }
        setComments(comments){
            this.comments=comments
        }
        addComment(comment){
            this.comments.append(comment)
        }
    }*/
    const history=useHistory();
    const quoteTextRef=useRef();
    const quoteAuthorRef=useRef();
    async function validateAndStoreQuote(e){
        e.preventDefault();
        let quoteisvalid=false;
        let authorisvalid=false;
        if(quoteAuthorRef.current.value.trim().length>0){
            quoteisvalid=true;
        }if(quoteAuthorRef.current.value.trim().length>0){
            authorisvalid=true;
        }
        if(quoteisvalid && authorisvalid){
            /*let sessionQuotes=JSON.parse(sessionStorage.getItem("quotes"));
            const counter=sessionQuotes.length;
            let quotes=Array();
            let cnt=0;
            sessionQuotes.map((quote)=>{
                quotes[cnt]=new Quote(quote)
                cnt++;
            })
            console.log(typeof(sessionQuotes))
            quotes[counter]=new Quote({
                id:`q${counter+1}`,
                author:quoteTextRef.current.value, 
                text:quoteAuthorRef.current.value,
            })*/
            const newQuote=new Quote(quoteTextRef.current.value, quoteAuthorRef.current.value)
            console.log(newQuote);
            addQuoteToList(newQuote)
            // const response=await fetch("https://quotes-368a6-default-rtdb.firebaseio.com/quotes.json",{
            //     method:"post",
            //     body: JSON.stringify({
            //         text:quotes[counter].text,
            //         author:quotes[counter].author
            //     }),
            //     headers: {
            //         "Content-Type":"application/json"
            //     }
            // })
            // if(response.status !== 200 && response.status !== 201){
            //     throw new Error("Request Failed!")
            // }
            // const responsedata=await response.json();
            console.log(addedQuote)
            //console.log(quotes)
            //sessionStorage.setItem("quotes", JSON.stringify(quotes));
            history.push("/quotes")
        }
        else{
            return
        }
    }
    return (
        <div className="container panel-body">
            <form className="" onSubmit={validateAndStoreQuote}>
                <div className="textarea">
                    <label htmlFor="quotetext">Text: </label>
                    <textarea name="quotetext" id="quotetext" ref={quoteTextRef}></textarea>
                </div>
                <div className="input">
                    <label htmlFor="quoteauthor">Author: </label>
                    <input name="quoteauthor" id="quoteauthor" ref={quoteAuthorRef}></input>
                </div>
                <div className="btn button-form">
                    <button className="form-control" type="submit" size="10px">Submit Quote</button>
                </div>
            </form>
        </div>
    )
}
export default QuoteForm