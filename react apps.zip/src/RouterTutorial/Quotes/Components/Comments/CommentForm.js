import { useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
//import UseHttp from "../../../hooks/use-http";
//import { addComment } from "../../../lib/api";
import UseHttp from "../../../hooks/use-http1";
import { addComment } from "../../../lib/api1";
import {Comment} from "../../../Quotes/Models/Model";

function CommentForm(data){
    const commentRef=useRef();
    const authorRef=useRef();
    const history=useHistory();
    const {isLoading, error, data: newComment, sendRequest}=UseHttp(addComment);
    /*class Comment{
        constructor({id, author, text}){
            this.id=id
            this.author=author
            this.text=text
        }
        getText(){
            return this.text
        }
        setText(text){
            this.text=text
        }
        getAuthor(){
            return this.author
        }
        setAuthor(author){
            this.author=author
        }
    }*/
    async function submitHandler(){
        const commentIsValid=(commentRef.current.value.trim().length>0)
        const authorIsValid=(authorRef.current.value.trim().length>0)
        if(commentIsValid && authorIsValid){
            /*let quotes=JSON.parse(sessionStorage.getItem("quotes"))
            let quotetochange=quotes.find((quote)=>{return quote.id==data.quoteID})
            console.log(quotetochange)
            const commentcount=quotetochange.comments?quotetochange.comments.length:0
            let comments=quotetochange.comments?quotetochange.comments:Array();
            comments[commentcount]=new Comment({
                id:commentcount+1, 
                author:authorRef.current.value, 
                text:commentRef.current.value
            })
            quotetochange.comments=comments
            quotes.map((quote)=>{if(quote.id==data.quoteID){quote=quotetochange}})
            console.log(quotes)
            sessionStorage.setItem("quotes", JSON.stringify(quotes))
            console.log(commentRef.current.value);
            console.log(authorRef.current.value);
            console.log(quotes)*/
            console.log(data.quoteID)
            const newComment=new Comment(data.quoteID, commentRef.current.value, authorRef.current.value)
            //console.log(newComment);
            /*const addedComment=await addCommentToQuote(addComment(
                data.quoteID, commentRef.current.value, authorRef.current.value
                ),
            (data)=>{console.log(data)})*/
            sendRequest(newComment)
            if(error){
                console.log(error)
            }
            history.push(`/quotes/${data.quoteID}`)
            data.onAdding();
        }else{
            return;
        }
    }
    console.log(newComment)
    return (
        <div className="container panel-body">
                <div className="textarea">
                    <label htmlFor="comment">Your Comment: </label>
                    <textarea id="comment" name="comment" ref={commentRef}></textarea>
                </div>
                <div className="input-sm">
                    <label htmlFor="author">Your Name: </label>
                    <input id="author" name="author" ref={authorRef}></input>
                </div>
                <div className="btn button-form">
                    <button className="form-control" type="submit" onClick={submitHandler}>Submit</button>
                </div>
        </div>
    )
}
export default CommentForm;