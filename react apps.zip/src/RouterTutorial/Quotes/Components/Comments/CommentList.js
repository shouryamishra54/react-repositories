import CommentItem from "./CommentItem";

function CommentList(data){
    return (
        <div className="list-unstyled">
            {data.comments.map((item)=>{return (
                <CommentItem comment={item}></CommentItem>
            )})}
        </div>
    )
}
export default CommentList