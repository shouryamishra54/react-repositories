import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import UseHttp from "../../../hooks/use-http";
import { loadComments } from "../../../lib/api";
import CommentForm from "./CommentForm";
import CommentList from "./CommentList";

function Comments(data){
    const {isLoading, error, sendRequest:sendCommentsFetchRequest}=UseHttp();
    const [comments, setComments]=useState();
    const [loaded, setLoaded]=useState(false);
    async function fetchComments(){
        let fetchedcomments=Array();
        await sendCommentsFetchRequest(loadComments(data.quoteID), (data, err)=>{
            let cnt=0;
            //setQuotes(Object.entries(data))
            /*for(let key in data){
                newQuotes.append({id:key, author:data.key.author, text:data.key.text})
                console.log("Hello")
            }*/
            console.log(data)
            const entries=Object.entries(data)
            for(let key in entries){
                fetchedcomments[cnt++]=({id:entries[key][0], author:entries[key][1].author, text:entries[key][1].text})
                //fetchedcomments[cnt++]=(entries[key])
            }
            console.log(fetchedcomments)
            console.log(err)
            setComments(fetchedcomments)
        })
        if(error){
            console.log(error)
        }
        return fetchComments;
    }
    useEffect(()=>{
        console.log(isLoading)
        fetchComments()
        setTimeout(() => {
            setLoaded(true)
        }, 500);
    }, [])
    console.log(comments)
    return (
        <div className="container-fluid panel-body">
            <div className="list-group list-unstyled">
                {loaded && comments && comments.length>0 && <CommentList comments={comments}></CommentList>}
                {!loaded && <p><strong>Loading...</strong></p>}
                {loaded && (!comments || comments.length<=0) && <p><strong>No Comments Found</strong></p>}
            </div>
        </div>
    )
}
export default Comments;