import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import UseHttp from "../../../hooks/use-http1";
import { loadComments } from "../../../lib/api1";
import CommentList from "./CommentList";


function Comments(data){
    const params=useParams();
    const quoteID=params.quoteID;
    const {isLoading, error, data:comments, sendRequest}=UseHttp(loadComments);
    //const [comments, setComments]=useState();
    const [loaded, setLoaded]=useState(false);
    useEffect(()=>{
        sendRequest(quoteID)
        setTimeout(async() => {
            await sendRequest(quoteID)
            setLoaded(!isLoading)
        }, 500);
    }, [])
    console.log(comments)
    return (
        <div className="container-fluid panel-body">
            <div className="list-group list-unstyled">
                {comments && comments.length>0 && <CommentList comments={comments}></CommentList>}
                {!loaded && <p><strong>Loading...</strong></p>}
                {loaded && (!comments || comments.length<=0) && <p><strong>No Comments Found</strong></p>}
            </div>
        </div>
    )
}
export default Comments;