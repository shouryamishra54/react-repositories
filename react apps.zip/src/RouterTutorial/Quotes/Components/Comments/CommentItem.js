
function CommentItem(data){
    return (
        <div className="list-group-item">
            <div className="list-group-item-heading">
                {data.comment.author}
            </div>
            <div className="list-group-item-text">
                {data.comment.text}
            </div>
        </div>
    )
}
export default CommentItem;