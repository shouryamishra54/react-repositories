import { useContext } from "react";
import { NavLink } from "react-router-dom";
import AuthContext from "../../context/auth-context";
import classes from "./MainHeader.module.css";
function MainHeader(props){
    const authctx=useContext(AuthContext);
    const loggedin=authctx.isLoggedIn;
    function logoutHandler(){
        authctx.logout();
    }
    console.log(localStorage.getItem("token"))
    return (
    <div> 
        <header className={classes.header}>
            <nav className="navbar-right">
                <ul>
                    <li>
                        {!loggedin && <NavLink to="/auth">Login</NavLink>}
                        {loggedin && <button onClick={logoutHandler}>Logout</button>}
                    </li>
                    <li>
                        {loggedin && <NavLink to="/myprofile">Go to profile</NavLink>}
                    </li>
                </ul>
            </nav>
        </header>
        <nav className="navbar-nav">
            <ul className="nav navbar navbar-nav">
                <li>
                    <NavLink to="/quotes">Quotes</NavLink>
                </li>
                <li>
                    <NavLink to="/new-quote">New Quote</NavLink>
                </li>
            </ul>
        </nav>
        <div className="panel-header container">
            <NavLink style={{"textDecoration":"none", "alignContent":"end"}} to="/quotes">
                <div className="container"><strong><h1>Introduction to Router: Quotes</h1></strong></div>
            </NavLink>
        </div> 
        </div>
    )
}
export default MainHeader