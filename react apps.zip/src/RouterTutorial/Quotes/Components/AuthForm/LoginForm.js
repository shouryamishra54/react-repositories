import classes from "../../Styles/Form.module.css";
import { useState, useRef, useEffect, useContext } from "react";
import { signIn } from "../../../lib/api1";
import UseHttp from "../../../hooks/use-http1";
import SignUpForm from "./SignUpForm";
import AuthContext from "../../context/auth-context";
import { useHistory } from "react-router-dom";

function LoginForm(){
    const emailInputRef = useRef();
    const passwordInputRef = useRef();
    const [isLogin, setIsLogin] = useState(true);
    const authctx=useContext(AuthContext)
    const {isLoading, error, data: loggedInUser, sendRequest:signInRequest}=UseHttp(signIn);
    const history=useHistory();
    const switchAuthModeHandler = () => {
        setIsLogin((prevState) => !prevState);
    };
    function reset(){
        emailInputRef.current.value="";
        passwordInputRef.current.value="";
    }
    function submitHandler(event){
        event.preventDefault();
        const enteredEmail = emailInputRef.current.value;
        const enteredPassword = passwordInputRef.current.value;
        if (isLogin) {
            signInRequest({email:enteredEmail, password:enteredPassword})
            reset();
        }
    };
    console.log(error);
    useEffect(()=>{
        setTimeout(() => {
            console.log("All Reset")
            if(loggedInUser && loggedInUser.loginInfo && loggedInUser.loginInfo.idToken!=null){
                authctx.login(loggedInUser.loginInfo.idToken)
                console.log(loggedInUser)
                history.push("/")
            }
        }, 500);
    }, [loggedInUser])
    console.log(authctx)
    console.log(localStorage.getItem("token"))
    return (<div>
        {isLogin && <section className={classes.auth}>
            <h1>{isLogin ? "Login" : "Sign Up"}</h1>
            <form onSubmit={submitHandler}>
                <div className={classes.control}>
                    <label htmlFor="email">Your Email: </label>
                    <input type="email" id="email" name="email" ref={emailInputRef} required></input>
                </div>
                <div className={classes.control}>
                    <label htmlFor="password">Password: </label>
                    <input type="password" id="password" name="password" ref={passwordInputRef} required></input>
                </div>
                <div className={classes.actions}>
                {!isLoading && (
                    <button>Login</button>
                )}
                {isLoading && <p>Sending request...</p>}
                <button type='button' className={classes.toggle} onClick={switchAuthModeHandler}>
                    Create new account
                </button>
                </div>
            </form>
        </section>}
        {!isLogin && <SignUpForm></SignUpForm>}
    </div>  
    )
}
export default LoginForm