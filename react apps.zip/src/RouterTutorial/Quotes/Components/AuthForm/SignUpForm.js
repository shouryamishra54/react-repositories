import { useContext, useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
import UseHttp from "../../../hooks/use-http1";
import { signUp } from "../../../lib/api1";
import AuthContext from "../../context/auth-context";
import classes from "../../Styles/Form.module.css";
import LoginForm from "./LoginForm";

function SignUpForm(){
    const firstnameInputRef=useRef();
    const lastnameInputRef=useRef();
    const usernameInputRef=useRef();
    const emailInputRef=useRef();
    const passwordInputRef=useRef();
    const confirmPasswordInputRef=useRef();
    const history=useHistory();
    const [passwordError, SetPasswordError]=useState(false);
    const [isLogin, setIsLogin]=useState(false);
    const {isLoading, error, data: newUser, sendRequest:signUpRequest}=UseHttp(signUp);
    const authctx=useContext(AuthContext)
    function switchAuthModeHandler(){
        setIsLogin(true)   
    }
    function validatePassword(){
        return passwordInputRef.current.value === confirmPasswordInputRef.current.value
    }
    function reset(){
        firstnameInputRef.current.value="";
        lastnameInputRef.current.value="";
        usernameInputRef.current.value="";
        emailInputRef.current.value="";
        passwordInputRef.current.value="";
        confirmPasswordInputRef.current.value="";
    }
    function submitHandler(e){
        e.preventDefault();
        if (!validatePassword()){
            SetPasswordError(true);
            return
        }
        if(passwordError){
            SetPasswordError(false)
        }
        if(!isLogin){
            const requestData={
                firstname: firstnameInputRef.current.value,
                lastname: lastnameInputRef.current.value,
                username: usernameInputRef.current.value,
                email: emailInputRef.current.value,
                password: passwordInputRef.current.value
            }
            signUpRequest(requestData)
            reset();
        }
    }
    console.log(error)
    useEffect(()=>{
        console.log("All Reset");
        if(newUser && newUser.signUpInfo){
            authctx.login(newUser.signUpInfo.idToken)
            console.log(newUser)
            //history.push("/")
        }
    }, [newUser])
    console.log(authctx)
    return (
        <div>
            {!isLogin && 
            <section className={classes.auth}>
                <h1>{isLogin ? "Login" : "Sign Up"}
                </h1>
                <form onSubmit={submitHandler}>
                    <div className={classes.control}>
                        <label htmlFor="firstname">First Name: </label>
                        <input type="text" id="firstname" name="firstname" ref={firstnameInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="lastname">Last Name: </label>
                        <input type="text" id="lastname" name="lastname" ref={lastnameInputRef}></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="username">User Name: </label>
                        <input type="text" id="username" name="username" ref={usernameInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="email">Email ID: </label>
                        <input type="email" id="email" name="email" ref={emailInputRef} required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="password">Password: </label>
                        <input type="password" id="password" name="password" ref={passwordInputRef} 
                        required></input>
                    </div>
                    <div className={classes.control}>
                        <label htmlFor="confirmpassword">Confirm Password: </label>
                        <input type="password" id="confirmpassword" name="confirmpassword" 
                        ref={confirmPasswordInputRef} required></input>
                    </div>
                    {passwordError && <p>Confirm Password is not equal to the earlier one.</p>}                    
                    <div className={classes.actions}>
                    {!isLoading && (
                        <button>Create Account'</button>
                    )}
                    {isLoading && <p>Sending request...</p>}
                    </div>
                    <button type='button' className={classes.toggle} onClick={switchAuthModeHandler}>
                        Login with existing account
                    </button>
                </form>
            </section>}
            {isLogin && <LoginForm></LoginForm>}
        </div>
    )
}
export default SignUpForm;