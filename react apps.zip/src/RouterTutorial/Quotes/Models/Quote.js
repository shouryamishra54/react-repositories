
class Quote{
    constructor(text, author){
        this.text=text;
        this.author=author
    }
    getText(){
        return this.text
    }
    setText(modifiedText){
        this.text=modifiedText
    }
    getAuthor(){
        return this.author
    }
    setAuthor(modifiedAuthor){
        this.author=modifiedAuthor
    }
}
module.exports={Quote}