import { useCallback, useState } from "react";

function UseHttp(requestFunction){
    const [isLoading, setIsLoading]=useState(false);
    const [error, setError]=useState();
    const [data, setData]=useState();
    const sendRequest=useCallback(async (requestData)=>{
        try{
            setIsLoading(true)
            const responseData=await requestFunction(requestData)
            setData(responseData)
            setIsLoading(false)
        }catch(err){
            setError(err.message)
            setIsLoading(false)
        }
    })
    return {isLoading, error, data, sendRequest}
}
export default UseHttp;