import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Row, Col, Container, ButtonGroup, Button, ButtonToolbar, ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem, Dropdown, UncontrolledDropdown } from "reactstrap";
import { 
    ButtonToolbar as ButtonToolbar1,
    Button as Button1,
    ButtonGroup as ButtonGroup1,
    DropdownButton,
    Dropdown as Dropdown1,
    SplitButton,
    Form
 } from "react-bootstrap";
 
function App(){
    const [dropdownActive, setDropdownActive]=useState(false);
    const [subDropdownActive, setSubDropdownActive]=useState(false);
    const [dropdownDirection, setDropdownDirection]=useState();
    
    return (<div>
        <Container className="alight-selft-center container">
        <Row>
        <Col>
            <h2>ReactStrap Button Group, Toolbar and Dropdown Tutorial</h2>
            <h3>Basic ButtonGroup, Toolbar and Dropdown</h3>
            <ButtonToolbar vertical>
                <ButtonGroup vertical={false} style={{"margin":"5px"}}>
                    <Button>1</Button>
                    <Button>2</Button>
                    <Button>3</Button>
                </ButtonGroup>
                <ButtonGroup style={{"margin":"5px"}}>
                    <Button>1</Button>
                    <Button>2</Button>
                    <Button>3</Button>
                </ButtonGroup>
                <ButtonGroup style={{"margin":"5px"}}>
                    <Dropdown isOpen={dropdownActive} 
                    onMouseOver={()=>setDropdownActive(true)}
                    onMouseLeave={()=>setDropdownActive(false)}
                    onClick={()=>setDropdownActive((cur)=>!cur)}>
                        <DropdownToggle caret>Click Me</DropdownToggle>
                        <DropdownMenu>
                            <DropdownItem>Header</DropdownItem>
                            <DropdownItem disabled={subDropdownActive}>Action</DropdownItem>
                            <DropdownItem>
                                <Dropdown isOpen={subDropdownActive} direction="end"
                                onMouseOver={()=>setSubDropdownActive(true)}
                                onMouseLeave={()=>setSubDropdownActive(false)}
                                onClick={()=>{
                                    setSubDropdownActive((cur)=>!cur);
                                }}>
                                    <DropdownToggle caret color="transparent">
                                        Another Action
                                    </DropdownToggle>
                                    <DropdownMenu>
                                        <DropdownItem>Sub Header</DropdownItem>
                                        <DropdownItem>Sub Action</DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            </DropdownItem>
                            <DropdownItem divider></DropdownItem>
                            <DropdownItem>Another Action</DropdownItem>
                        </DropdownMenu>
                    </Dropdown>
                </ButtonGroup>
            </ButtonToolbar>
            <h3>ReactStrap Button Groups with Dropdown with direction</h3>
            <ButtonGroup vertical className="offset-1" color="secondary">
                {['up','start','end','down'].map((direction)=>{
                    return <Dropdown direction={direction} 
                        isOpen={dropdownDirection === direction} 
                        onMouseOver={()=>setDropdownDirection(direction)}
                        onMouseLeave={()=>setDropdownDirection()}
                        onClick={()=>{
                            if(dropdownDirection === direction){
                                setDropdownDirection()
                            }else{
                                setDropdownDirection(direction)
                            }
                        }}>
                        <DropdownToggle caret color="transparent">
                            Button {(direction === 'start')?`left`:(direction === 'end')?`right`:direction}
                        </DropdownToggle>
                        <DropdownMenu>
                            <DropdownItem>Header</DropdownItem>
                            <DropdownItem>Action</DropdownItem>
                            <DropdownItem divider></DropdownItem>
                            <DropdownItem>Another Action</DropdownItem>
                        </DropdownMenu>
                    </Dropdown>
                })}
            </ButtonGroup>
        </Col>
        <Col>
            <h2>React-Bootstrap ButtonGoups, Dropdown and ButtonToolbar</h2>
            <h3>Basic ButtonGroup, Button Toolbar and ButtonDropdowns</h3>
            <ButtonToolbar1>
                <ButtonGroup1 style={{"margin":"5px"}}>
                    <Button1>1</Button1>
                    <Button1>2</Button1>
                    <Button1>3</Button1>
                    <Button1>4</Button1>
                </ButtonGroup1>
                <ButtonGroup1 style={{"margin":"5px"}}>
                    <Button1>5</Button1>
                    <Button1>6</Button1>
                </ButtonGroup1>
                <ButtonGroup1 style={{"margin":"5px"}}>
                    <DropdownButton as={ButtonGroup1} title="Dropdown" variant="success">
                        <Dropdown1.Item>Link 1</Dropdown1.Item>
                        <Dropdown1.Item>Link 2</Dropdown1.Item>
                        <Dropdown1.Divider></Dropdown1.Divider>
                        <Dropdown1.Item>Link 3</Dropdown1.Item>
                    </DropdownButton>
                    <DropdownButton as={ButtonGroup} title="First Active" 
                    variant="success" focusFirstItemOnShow>
                        <Dropdown1.Item>Link1</Dropdown1.Item>
                        <Dropdown1.Item>Link2</Dropdown1.Item>
                        <Dropdown1.Divider></Dropdown1.Divider>
                        <Dropdown1.Item>Link3</Dropdown1.Item>
                    </DropdownButton>
                </ButtonGroup1>
                <ButtonGroup1 style={{"margin":"5px"}}>
                    <Dropdown1 as={ButtonGroup1}>
                        <Button>Split Button</Button>
                        <Dropdown1.Toggle split variant="success"></Dropdown1.Toggle>
                        <Dropdown1.Menu>
                        <Dropdown1.Item href="#/action-1">Action</Dropdown1.Item>
                        <Dropdown1.Item href="#/action-2">Another action</Dropdown1.Item>
                        <Dropdown1.Item href="#/action-3">Something else</Dropdown1.Item>
                        </Dropdown1.Menu>
                    </Dropdown1>
                </ButtonGroup1>
            </ButtonToolbar1>
            <h3>DropdownButton Direction tutorial</h3>
            <ButtonGroup1>
                {['up','start','end','down'].map((direction)=>{
                    return <DropdownButton as={ButtonGroup1} 
                    title={`Dropdown ${(direction === 'start')?`left`:(direction === 'end')?`right`:direction}`}
                    drop={direction} show={dropdownDirection === direction}
                    onMouseOver={()=>setDropdownDirection(direction)}
                    onMouseLeave={()=>setDropdownDirection()}
                    onClick={()=>{
                        if(dropdownDirection === direction){
                            setDropdownDirection()
                        }else{
                            setDropdownDirection(direction)
                        }
                    }}>
                        <Dropdown1.Header>Header 1</Dropdown1.Header>
                        <Dropdown1.Item>Link1</Dropdown1.Item>
                        <Dropdown1.Item>Link2</Dropdown1.Item>
                        <Dropdown1.Divider></Dropdown1.Divider>
                        <Dropdown1.ItemText>Text1</Dropdown1.ItemText>
                    </DropdownButton>
                })}
            </ButtonGroup1>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App;