import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";

function App(){
    const [usernameIsValid, setUsernameIsValid]=useState(true)
    const [passwordIsValid, setPasswordIsValid]=useState(true)
    function validatePassword(e){
        let spChars = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if(spChars.test(e)){
            setPasswordIsValid(false);
            return
        }if(e.indexOf(' ')>=0){
            setPasswordIsValid(false);
            return
        }if(e.length === 0){
            setPasswordIsValid(false);
            return
        }
        setPasswordIsValid(true)
    }
    console.log(passwordIsValid)

    return <Container>
        <Row>
        <Col>
        <Form>
        <Card>
            <Card.Header>
                <Card.Title>Basic ReactBootstrapForm Sample</Card.Title>
            </Card.Header>
            <Card.Body>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="plantextinput">Plant Text (Static)</Form.Label>
                    <Form.Control plaintext value={'Some plain text/ static value'}/>
                </Form.Group>
                <Form.Group className="mb-3 position-relative">
                    <Form.Label htmlFor="usernameinput">User Name</Form.Label>
                    <Form.Control type={'text'} id="usernameinput" name="username" 
                    isInvalid={!usernameIsValid} onChange={(e)=>{
                        if(e.target.value.length === 0){
                            setUsernameIsValid(false)
                        }else{
                            setUsernameIsValid(true)
                        }
                    }}/>
                    <Form.Control.Feedback tooltip type={'invalid'}>
                        Username cannot be empty
                    </Form.Control.Feedback>
                    <Form.Text>Username cannot be duplicate</Form.Text>
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="emailaddr">Email address</Form.Label>
                    <Form.Control type={'email'} id="emailaddr" name="email"/>
                </Form.Group>
                <Form.Group className="mb-3 position-relative">
                    <Form.Label htmlFor="password">Password</Form.Label>
                    <Form.Control type={'password'} id="password" name="password" isInvalid={!passwordIsValid} 
                    onChange={(e)=>validatePassword(e.target.value)}/>
                    <Form.Control.Feedback tooltip type={'invalid'}>Password is invalid</Form.Control.Feedback>
                    <Form.Text>
                        Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
                    </Form.Text>
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="disabledinput">Disabled Input</Form.Label>
                    <Form.Control id="disabledinput" name="disabledinput" disabled/>
                    <Form.Text>We'll never share your email with anyone else.</Form.Text>
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="selectinput">Select Input</Form.Label>
                    <Form.Select id="selectinput">
                        <option>Option 1</option>
                        <option>Option 2</option>
                        <option>Option 3</option>
                        <option>Option 4</option>
                        <option>Option 5</option>
                        <option>Option 6</option>
                        <option>Option 7</option>
                    </Form.Select>
                    <Form.Text>
                        Only one option can be selected
                    </Form.Text>
                </Form.Group>
                <Form.Group className="mb-3">
                    <Form.Label htmlFor="selectmult">Select Multiple Option</Form.Label>
                    <Form.Select multiple id="selectmult">
                        <option>Option 1</option>
                        <option>Option 2</option>
                        <option>Option 3</option>
                        <option>Option 4</option>
                        <option>Option 5</option>
                        <option>Option 6</option>
                        <option>Option 7</option>
                    </Form.Select>
                    <Form.Text>
                        More than one option can be selected
                    </Form.Text>
                </Form.Group>
                <fieldset disabled>
                    <Form.Group className="mb-3">
                        <Form.Label htmlFor="input1">Disabled Input</Form.Label>
                        <Form.Control id="input1" name="input1" disabled/>
                        <Form.Text>We'll never share your email with anyone else.</Form.Text>
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label htmlFor="selectinput1">Select Input</Form.Label>
                        <Form.Select id="selectinput1">
                            <option>Option 1</option>
                            <option>Option 2</option>
                            <option>Option 3</option>
                            <option>Option 4</option>
                            <option>Option 5</option>
                            <option>Option 6</option>
                            <option>Option 7</option>
                        </Form.Select>
                    </Form.Group>
                </fieldset>
                <Form.Group class="mb-3">
                    <legend>Basic Checkbox and RadioButton</legend>
                    {['checkbox', 'radio'].map((type)=>{
                        return <div key={`default-${type}`} class="mb-3">
                            <Form.Check type={type} id={`default-${type}`} label={`default ${type}`}/>
                            <Form.Check type={type} id={`disabled-${type}`} label={`disabled ${type}`} disabled/>
                        </div>
                    })}
                </Form.Group>
                <Form.Group class="mb-3">
                    <legend>Basic Switches</legend>
                    <div className="mb-3">
                        <Form.Switch label="Check this Switch"/>
                        <Form.Switch label="Switch is alredy Checked" />
                    </div>
                    <div className="mb-3">
                        <Form.Switch label="Disabled Check this Switch" disabled/>
                        <Form.Switch label="Disabled Switch is alredy Checked" disabled/>
                    </div>                
                </Form.Group>
                <Form.Group className="mb-3">
                    <legend>Inline Checks</legend>
                    {['checkbox', 'radio'].map((type)=>{
                        return <div id={`inline-${type}`} className="mb-3">
                            <Form.Check inline type={type} id={`inline-${type}1`} label="1"/>
                            <Form.Check inline type={type} id={`inline-${type}2`} label="2"/>
                            <Form.Check inline type={type} id={`inline-${type}3`} label="3"/>
                        </div>
                    })}
                </Form.Group>
                <Form.Group className="mb-3">
                    <legend>Customizing FormCheck rendering</legend>
                    {['checkbox', 'radio'].map((type)=>{
                        return <div id={`render-${type}`} className="mb-3">
                            <Form.Check id={`render-${type}`}>
                                <Form.Check.Input type={type} isValid/>
                                <Form.Check.Label>{`Custom API ${type}`}</Form.Check.Label>
                                <Form.Control.Feedback type={'valid'}>Accomplished!</Form.Control.Feedback>
                            </Form.Check>
                        </div>
                    })}
                </Form.Group>
            </Card.Body>
            <Card.Footer>
                <Button type={'submit'}>Submit</Button>
            </Card.Footer>
        </Card>
        </Form>
        <Form>
        <Card>
            <Card.Header>
                <Card.Title></Card.Title>
            </Card.Header>
        </Card>
        </Form>
        </Col>
        </Row>
    </Container>
}
export default App