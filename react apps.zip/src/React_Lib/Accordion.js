import React, { useContext, useState } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import {
  Accordion,
  AccordionBody,
  AccordionHeader,
  AccordionItem,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Container,
  Row,
  UncontrolledAccordion,
} from 'reactstrap';
import {
    Accordion as BootstrapAccordion,
    AccordionContext,
    Alert,
    useAccordionButton
  } from 'react-bootstrap';

function App(props) {
  const [open, setOpen] = useState('1');
  function toggle(id){
    if(id === open){
        setOpen()
    }else{
        setOpen(id)
    }
  }
  function CustomToggle(props){
    const decoratedOnClick=useAccordionButton(props.eventKey, ()=>
    {return (props.callBack && props.callBack(props.eventKey))});
    return (<Button className='btn-light btn-outline-secondary'
        type="button"
        onClick={decoratedOnClick}>
        {props.children}
    </Button>)
  }
  function ContextAwareToggle(props){
    const decoratedOnClick=useAccordionButton(props.eventKey, ()=>
    {return (props.callBack && props.callBack(props.eventKey))})
    const {activeEventKey}=useContext(AccordionContext)
    return (<Button className='btn-light btn-outline-secondary'
    type="button"
    onClick={decoratedOnClick}
    style={activeEventKey === props.eventKey ? {"backgroundColor":"pink"}:{"backgroundColor":"lavender"}}>
        {props.children}
    </Button>)
  }
  function printAccordionID(eventKey){
    console.log(eventKey)
  }
  return (
    <div><Container className="align-self-center container">
        <Row>
        <Col style={{"padding":"10px"}} className='bg-transparent' xs="6" md="6" sm="12">
        <h2>ReactStrap Accordion Tutorial</h2>
        <Card style={{"padding":"5px", "marginBottom": "10px"}}>
            <CardHeader>
                Basic Accordion from Reactstrap
            </CardHeader>
            <CardBody>
                <Accordion flush open={open} toggle={toggle}>
                    <AccordionItem>
                        <AccordionHeader targetId='1'>
                            Accordion Item 1
                        </AccordionHeader>
                        <AccordionBody accordionId='1'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                    <AccordionItem>
                        <AccordionHeader targetId='2'>
                            Accordion Item 2
                        </AccordionHeader>
                        <AccordionBody accordionId='2'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                    <AccordionItem>
                        <AccordionHeader targetId='3'>
                            Accordion Item 3
                        </AccordionHeader>
                        <AccordionBody accordionId='3'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                </Accordion>
            </CardBody>
            <CardFooter>Basic Accordion completed</CardFooter>
        </Card>
        <Card style={{"padding":"5px", "marginBottom": "10px"}}>
            <CardHeader>
                Use of UncontrolledAccordion : Without Toggling function
            </CardHeader>
            <CardBody>
                <UncontrolledAccordion flush defaultOpen={['11']}>
                    <AccordionItem>
                        <AccordionHeader targetId='11'>
                            Accordion Item 1
                        </AccordionHeader>
                        <AccordionBody accordionId='11'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                    <AccordionItem>
                        <AccordionHeader targetId='22'>
                            Accordion Item 2
                        </AccordionHeader>
                        <AccordionBody accordionId='22'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                    <AccordionItem>
                        <AccordionHeader targetId='33'>
                            Accordion Item 3
                        </AccordionHeader>
                        <AccordionBody accordionId='33'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                </UncontrolledAccordion>
            </CardBody>
            <CardFooter>Basic Accordion completed</CardFooter>
        </Card>
        <Card style={{"padding":"5px", "marginBottom": "10px"}}>
            <CardHeader>
                Use of "stayOpen" in UncontrolledAccordion
            </CardHeader>
            <CardBody>
                <UncontrolledAccordion flush defaultOpen={['111']} stayOpen>
                    <AccordionItem>
                        <AccordionHeader targetId='111'>
                            Accordion Item 1
                        </AccordionHeader>
                        <AccordionBody accordionId='111'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                    <AccordionItem>
                        <AccordionHeader targetId='222'>
                            Accordion Item 2
                        </AccordionHeader>
                        <AccordionBody accordionId='222'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                    <AccordionItem>
                        <AccordionHeader targetId='333'>
                            Accordion Item 3
                        </AccordionHeader>
                        <AccordionBody accordionId='333'>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </AccordionBody>
                    </AccordionItem>
                </UncontrolledAccordion>
            </CardBody>
            <CardFooter>Basic Accordion completed</CardFooter>
        </Card>
        </Col>
        <Col style={{"padding":"10px"}} className="bg-transparent" xs="4" md="6" sm="12">
        <h2>React-Bootstrap Accordion Tutorial</h2>
        <Card style={{"padding":"5px", "marginBottom": "10px"}}>
            <CardHeader>
                Use of Accordion Using React-Bootstrap
            </CardHeader>
            <CardBody>
                <BootstrapAccordion flush defaultActiveKey={['111', '222']} alwaysOpen>
                    <BootstrapAccordion.Item eventKey="111">
                        <BootstrapAccordion.Header>
                            Accordion Item 1
                        </BootstrapAccordion.Header>
                        <BootstrapAccordion.Body>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </BootstrapAccordion.Body>
                    </BootstrapAccordion.Item>
                    <BootstrapAccordion.Item eventKey="222">
                        <BootstrapAccordion.Header>
                            Accordion Item 2
                        </BootstrapAccordion.Header>
                        <BootstrapAccordion.Body>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </BootstrapAccordion.Body>
                    </BootstrapAccordion.Item>
                    <BootstrapAccordion.Item eventKey="333">
                        <BootstrapAccordion.Header>
                            Accordion Item 3
                        </BootstrapAccordion.Header>
                        <BootstrapAccordion.Body>
                            <strong>This is the first item&#39;s accordion body.</strong>
                            You can modify any of this with custom CSS or overriding our default
                            variables. It&#39;s also worth noting that just about any HTML can
                            go within the <code>.accordion-body</code>, though the transition
                            does limit overflow.
                        </BootstrapAccordion.Body>
                    </BootstrapAccordion.Item>
                </BootstrapAccordion>
            </CardBody>
            <CardFooter>React Bootstrap basic Accordion completed</CardFooter>
        </Card>
        <BootstrapAccordion flush style={{"padding":"5px"}}>
            <Card style={{"padding":"5px"}}>
                <CardHeader>
                    <CustomToggle eventKey="1111">Click me!</CustomToggle>
                </CardHeader>
                <BootstrapAccordion.Collapse eventKey="1111">
                    <CardBody>
                    <strong>This is the first item&#39;s accordion body.</strong>
                    You can modify any of this with custom CSS or overriding our default
                    variables. It&#39;s also worth noting that just about any HTML can
                    go within the <code>.accordion-body</code>, though the transition
                    </CardBody>
                </BootstrapAccordion.Collapse>
            </Card>
            <Card style={{"padding":"5px"}}>
                <CardHeader>
                    <CustomToggle eventKey="2222">Click me!</CustomToggle>
                </CardHeader>
                <BootstrapAccordion.Collapse eventKey="2222">
                    <CardBody>
                    <strong>This is the first item&#39;s accordion body.</strong>
                    You can modify any of this with custom CSS or overriding our default
                    variables. It&#39;s also worth noting that just about any HTML can
                    go within the <code>.accordion-body</code>, though the transition
                    </CardBody>
                </BootstrapAccordion.Collapse>
            </Card>
        </BootstrapAccordion>
        <BootstrapAccordion style={{"padding":"5px"}}>
            <Card style={{"padding":"5px"}}>
                <CardHeader>
                    <ContextAwareToggle eventKey="3333">Click Me!</ContextAwareToggle>
                </CardHeader>
                <BootstrapAccordion.Collapse eventKey="3333">
                    <CardBody>
                    <strong>This is the first item&#39;s accordion body.</strong>
                    You can modify any of this with custom CSS or overriding our default
                    variables. It&#39;s also worth noting that just about any HTML can
                    go within the <code>.accordion-body</code>, though the transition
                    </CardBody>
                </BootstrapAccordion.Collapse>
            </Card>
            <Card style={{"padding":"5px"}}>
                <CardHeader>
                    <ContextAwareToggle eventKey="4444">Click me!</ContextAwareToggle>
                </CardHeader>
                <BootstrapAccordion.Collapse eventKey="4444">
                    <CardBody>
                    <strong>This is the first item&#39;s accordion body.</strong>
                    You can modify any of this with custom CSS or overriding our default
                    variables. It&#39;s also worth noting that just about any HTML can
                    go within the <code>.accordion-body</code>, though the transition
                    </CardBody>
                </BootstrapAccordion.Collapse>
            </Card>
        </BootstrapAccordion>
        </Col></Row></Container></div>
  );
}

export default App;
