import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Card, CardBody, CardColumns, CardDeck, CardFooter, CardGroup, CardHeader, CardText, CardTitle, Col, Container, Row } from "reactstrap";

function App(){
    return (<div>
        <Container>
        <Row>
        <Col>
            <h2>ReactStrap Column Tutorial</h2>
            <h3>Basic Card Tutorials</h3>
            <CardColumns>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <h3>Special Title Treatment</h3>
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <CardText>
                            With supporting text below as a natural lead-in to additional content.
                        </CardText>
                        <Button>Submit</Button>
                    </CardBody>
                    <CardDeck>last updated 2 weeks ago</CardDeck>
                    <CardFooter>Contact us</CardFooter>
                </Card>
                <Card className="text-start">
                    <CardTitle>Special Title Treatment</CardTitle>
                    <CardBody>
                        <CardText>
                            With supporting text below as a natural lead-in to additional content.
                        </CardText>
                        <Button color="primary">Go Somewhere</Button>
                    </CardBody>
                </Card>
                <Card className="text-center">
                    <CardTitle>Special Title Treatment</CardTitle>
                    <CardBody>
                        <CardText>
                            With supporting text below as a natural lead-in to additional content.
                        </CardText>
                        <Button color="primary">Go Somewhere</Button>
                    </CardBody>
                </Card>
                <Card className="text-end">
                    <CardTitle>Special Title Treatment</CardTitle>
                    <CardBody>
                        <CardText>
                            With supporting text below as a natural lead-in to additional content.
                        </CardText>
                        <Button color="primary">Go Somewhere</Button>
                    </CardBody>
                </Card>
            </CardColumns>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App;