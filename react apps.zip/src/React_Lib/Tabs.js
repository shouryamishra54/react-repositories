import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Col, Container, Nav, NavItem, NavLink, Row, TabContent, TabPane } from "reactstrap";
import { Button, Card, Nav as Nav1, Tab, Tabs } from "react-bootstrap";

function App(){
    const [tabPanelIndex, setTabPanelIndex]=useState()

    return <div>
        <Container>
        <Row>
        <h1>Tabs, Nav Tutorails</h1>
        <Col>
        <h2>React Tabs, Nav Tutorials</h2>
        <br></br>
        <h3>Basic Nav Sample</h3>
        <Nav pills>
            <NavItem>
                <NavLink href="#" onClick={()=>setTabPanelIndex('1')}>Link 1</NavLink>
            </NavItem>
            <NavItem>
                <NavLink href="#" onClick={()=>setTabPanelIndex('2')}>Link 2</NavLink>
            </NavItem>
            <NavItem>
                <NavLink href="#" disabled>Link 3</NavLink>
            </NavItem>
        </Nav>
        <br></br><br></br>
        React Bootstrap Tab Tutorial
        <Nav1 pills className="justify-content-center" activeKey="/home">
            <Nav1.Item>
                <Nav1.Link href="/home">Link 1</Nav1.Link>
            </Nav1.Item>
            <Nav1.Item>
                <Nav1.Link href="/home/link-1">Link 2</Nav1.Link>
            </Nav1.Item>
            <Nav1.Item>
                <Nav1.Link href="/home/link-2" disabled>Link 3</Nav1.Link>
            </Nav1.Item>
        </Nav1>
        <Nav1 pills className="justify-content-start" activeKey="/home">
            <Nav1.Item>
                <Nav1.Link href="/home">Link 1</Nav1.Link>
            </Nav1.Item>
            <Nav1.Item>
                <Nav1.Link href="/home/link-1">Link 2</Nav1.Link>
            </Nav1.Item>
            <Nav1.Item>
                <Nav1.Link href="/home/link-2" disabled>Link 3</Nav1.Link>
            </Nav1.Item>
        </Nav1>
        <Nav1 pills className="justify-content-end" activeKey="/home">
            <Nav1.Item>
                <Nav1.Link href="/home">Link 1</Nav1.Link>
            </Nav1.Item>
            <Nav1.Item>
                <Nav1.Link href="/home/link-1">Link 2</Nav1.Link>
            </Nav1.Item>
            <Nav1.Item>
                <Nav1.Link href="/home/link-2" disabled>Link 3</Nav1.Link>
            </Nav1.Item>
        </Nav1>
        <Tabs defaultActiveKey="home" justify>
            <Tab eventKey="home" title="Home">
                <p>Then hate me when thou wilt; if ever, now; Now, while the world is bent my deeds to cross, Join with the spite of fortune, make me bow, And do not drop in for an after-loss: Ah! do not, when my heart hath 'scap'd this sorrow, Come in the rearward of a conquer'd woe; Give not a windy night a rainy morrow, To linger out a purpos'd overthrow. If thou wilt leave me, do not leave me last, When other petty griefs have done their spite,</p>
            </Tab>
            <Tab eventKey="profile" title="Profile">
                <p>How can I then return in happy plight, That am debarre'd the benefit of rest? When day's oppression is not eas'd by night, But day by night and night by day oppress'd, And each, though enemies to either's reign, Do in consent shake hands to torture me, The one by toil, the other to complain How far I toil, still farther off from thee. I tell the day, to please him thou art bright, And dost him grace when clouds do blot the heaven:</p>
            </Tab>
            <Tab eventKey="longer-tab" title="Looonger Tab">
                <p>That you were once unkind befriends me now, And for that sorrow, which I then did feel, Needs must I under my transgression bow, Unless my nerves were brass or hammer'd steel. For if you were by my unkindness shaken, As I by yours, you've pass'd a hell of time; And I, a tyrant, have no leisure taken To weigh how once I suffer'd in your crime. O! that our night of woe might have remember'd My deepest sense, how hard true sorrow hits,</p>
            </Tab>
            <Tab eventKey="contact" title="Contact" disabled>
                <p>Unthrifty loveliness, why dost thou spend Upon thy self thy beauty's legacy? Nature's bequest gives nothing, but doth lend, And being frank she lends to those are free: Then, beauteous niggard, why dost thou abuse The bounteous largess given thee to give? Profitless usurer, why dost thou use So great a sum of sums, yet canst not live? For having traffic with thy self alone, Thou of thy self thy sweet self dost deceive:</p>
            </Tab>
        </Tabs>
        </Col>
        </Row>
        </Container>
    </div>
}
export default App