import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Col, Container, Form, FormGroup, Input, Label, ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Modal, ModalBody, ModalFooter, ModalHeader, Row } from "reactstrap";
import { Modal as Modal1 } from "react-bootstrap";

function App(){
    const [unmountOnClose, setUnmountOnClose]=useState(true)
    const [toggle1, setToggle1]=useState(false)
    const [toggle2, setToggle2]=useState(false)
    const [toggle3, setToggle3]=useState(false)
    const [toggle4, setToggle4]=useState(false)
    const [toggle5, setToggle5]=useState(false)
    const [toggle6, setToggle6]=useState(false)
    const [toggle8, setToggle8]=useState(false)
    const [toggle9, setToggle9]=useState(false)
    const [toggle10, setToggle10]=useState(false)
    const [toggle11, setToggle11]=useState(false)
    const [toggle12, setToggle12]=useState(false)
    const [toggle13, setToggle13]=useState(false)
    // const [button1, setButton1]=useState(false)
    console.log(unmountOnClose)
    return (<div>
        <Container>
        <Row><h1>Modals Tutorials</h1></Row>
        <Row>
        <Col>
        <h2>Reactstrap Modals Tutorials</h2>
        <br></br><br></br>
        <h3>Basic React Sample</h3>
        <Row>
            <ListGroup tag={'ul'} className="list-group-horizontal">
                <ListGroupItem tag={'li'}>
                    <ListGroupItemHeading>
                        <Button color="primary" onClick={()=>setToggle1(cur=>!cur)}>Click Me</Button>
                    </ListGroupItemHeading>
                    <ListGroupItemText>
                        <p>(Clicking outsite will close the Modal)</p>
                    </ListGroupItemText>
                </ListGroupItem>
                <ListGroupItem>
                    <ListGroupItemHeading>
                        <Button color="primary" onClick={()=>setToggle2(cur=>!cur)}>Click Me</Button>
                    </ListGroupItemHeading>
                    <ListGroupItemText>
                        <p>(Clicking outsite will not close the Modal)</p>
                    </ListGroupItemText>
                </ListGroupItem>
            </ListGroup>        
        </Row>
        <Modal isOpen={toggle1} toggle={()=>setToggle1(cur=>!cur)}>
            <ModalHeader toggle={()=>setToggle1(cur=>!cur)} ><h2>Modal Title</h2></ModalHeader>
            <ModalBody>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={()=>setToggle1(cur=>!cur)}>Do Something</Button>
                <Button onClick={()=>setToggle1(cur=>!cur)}>Cancel</Button>
            </ModalFooter>
        </Modal>
        <Modal isOpen={toggle2}>
            <ModalHeader toggle={()=>setToggle2(cur=>!cur)} ><h2>Modal Title</h2></ModalHeader>
            <ModalBody>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={()=>setToggle2(cur=>!cur)}>Do Something</Button>
                <Button onClick={()=>setToggle2(cur=>!cur)}>Cancel</Button>
            </ModalFooter>
        </Modal>
        <br></br><br></br>
        <h3>Scrollable Modals</h3>
        <Button color="primary" outline onClick={()=>setToggle3(cur=>!cur)}>Click Me</Button>
        <Modal isOpen={toggle3} scrollable>
            <ModalHeader toggle={()=>setToggle3(cur=>!cur)} ><h2>Modal Title</h2></ModalHeader>
            <ModalBody>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={()=>setToggle3(cur=>!cur)}>Do Something</Button>
                <Button onClick={()=>setToggle3(cur=>!cur)}>Cancel</Button>
            </ModalFooter>
        </Modal>
        <br></br><br></br><br></br>
        <h3>Custom Timeout Sample</h3>
        <Button color="primary" onClick={()=>setToggle4(cur=>!cur)}>Click Me</Button>
        <Modal isOpen={toggle4} scrollable toggle={()=>setToggle4(cur=>!cur)}
        modalTransition={{timeout:500}}
        backdropTransition={{timeout:900}}>
            <ModalHeader toggle={()=>setToggle4(cur=>!cur)} ><h2>Modal Title</h2></ModalHeader>
            <ModalBody>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <Input type="textarea"
                placeholder="Write something (data should remain in modal if unmountOnClose is set to false)"/>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={()=>setToggle4(cur=>!cur)}>Do Something</Button>
                <Button onClick={()=>setToggle4(cur=>!cur)}>Cancel</Button>
            </ModalFooter>
        </Modal>
        <br></br><br></br>
        <h3>Destructuring: Retaining the Modal data on closing the modal so that they can be filled again from the place it was being closed.</h3>
        <Form onSubmit={(e)=>e.preventDefault()}>
            <FormGroup>
                <Label for="unmountOnClose">Select from below if you want to retain the modal data</Label>
                <Input type={'select'} id="unmountOnClose" name="unmountOnClose"
                onChange={(e)=>setUnmountOnClose(cur=>!cur)}>
                    <option value={true}>TRUE</option>
                    <option value={false}>FALSE</option>
                </Input>
            </FormGroup>
            <Button color="primary" onClick={()=>setToggle5(cur=>!cur)}>Click Me</Button>
        </Form>
        <Modal isOpen={toggle5} scrollable unmountOnClose={!unmountOnClose}
            backdropTransition={{timeout:900}}>
            <ModalHeader toggle={()=>setToggle5(cur=>!cur)} ><h2>Modal Title</h2></ModalHeader>
            <ModalBody>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <Input type="textarea"
                placeholder="Write something (data should remain in modal if unmountOnClose is set to false)"/>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={()=>setToggle5(cur=>!cur)}>Do Something</Button>
                <Button onClick={()=>setToggle5(cur=>!cur)}>Cancel</Button>
            </ModalFooter>
        </Modal>
        <br></br><br></br>
        <h3>Return Focus after closing the Modal</h3>
        <Button color="primary" onClick={()=>setToggle6(cur=>!cur)}>Click Me</Button>
        <Modal returnFocusAfterClose isOpen={toggle6}>
        <ModalHeader toggle={()=>setToggle6(cur=>!cur)} ><h2>Modal Title</h2></ModalHeader>
            <ModalBody>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={()=>setToggle6(cur=>!cur)}>Do Something</Button>
                <Button onClick={()=>setToggle6(cur=>!cur)}>Cancel</Button>
            </ModalFooter>
        </Modal>
        <br></br><br></br>
        </Col>
        <Col>
        <h2>ReactBootstrap Modal Tutorials</h2>
        <br></br><br></br>
        <ListGroup tag={'ul'} className="list-group-horizontal">
            <ListGroupItem tag={'li'}>
                <ListGroupItemHeading>
                    <h3>Basic Modal Sample</h3>
                </ListGroupItemHeading>
                <ListGroupItemText>
                    <Button color="primary" onClick={()=>setToggle8(cur=>!cur)}>
                        Launch Demo Modal
                    </Button>                    
                </ListGroupItemText>
            </ListGroupItem>
            <ListGroupItem tag={'li'}>
                <ListGroupItemHeading>
                    <h3>Static Modal (will not close after clicking outside)</h3>
                </ListGroupItemHeading>
                <ListGroupItemText>
                    <Button color="primary" onClick={()=>setToggle9(cur=>!cur)}>
                        Click Here
                    </Button>
                </ListGroupItemText>
            </ListGroupItem>
        </ListGroup>
        <Modal1 show={toggle8} onHide={()=>{setToggle8(cur=>!cur)}}>
            <Modal1.Header closeButton>
                <Modal1.Title>Modal Heading</Modal1.Title>
            </Modal1.Header>
            <Modal1.Body>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </Modal1.Body>
            <Modal1.Footer>
                <Button color="secondary" onClick={()=>setToggle8(cur=>!cur)}>
                    Close
                </Button>
                <Button color="primary" onClick={()=>setToggle8(cur=>!cur)}>
                    Save Changes
                </Button>
            </Modal1.Footer>
        </Modal1>
        <Modal1 show={toggle9} onHide={()=>setToggle9(cur=>!cur)} backdrop='static' keyboard={false}>
            <Modal1.Header closeButton>
                <Modal1.Title>Modal Heading</Modal1.Title>
            </Modal1.Header>
            <Modal1.Body>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </Modal1.Body>
            <Modal1.Footer>
                <Button color="secondary" onClick={()=>setToggle9(cur=>!cur)}>
                    Close
                </Button>
                <Button color="primary" onClick={()=>setToggle9(cur=>!cur)}>
                    Save Changes
                </Button>
            </Modal1.Footer>
        </Modal1>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App;