import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Card, CardBody, Carousel, CarouselCaption, CarouselControl, CarouselIndicators, CarouselItem, Col, Collapse, Container, List, ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, ListInlineItem, Row, UncontrolledAccordion } from "reactstrap";
import { Carousel as Carousel1, ListGroup as ListGroup1, NavLink } from "react-bootstrap";
import CardHeader from "react-bootstrap/esm/CardHeader";

const items = [
    {
      src: 'https://picsum.photos/id/123/1200/400',
      altText: 'Slide 1',
      caption: 'Water',
      desc: 'Nulla vitae elit libero, a pharetra augue mollis interdum.',
      key: 1,
    },
    {
      src: 'https://picsum.photos/id/456/1200/400',
      altText: 'Slide 2',
      caption: 'Greenery',
      desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      key: 2,
    },
    {
      src: 'https://picsum.photos/id/678/1200/400',
      altText: 'Slide 3',
      caption: 'Mountains',
      desc: 'Praesent commodo cursus magna, vel scelerisque nisl consectetur.',
      key: 3,
    },
  ];
function App(){
    const [activeIndex, setActiveIndex]=useState(0)
    const [animating, setAnimating]=useState(false)
    const [status, setStatus]=useState("Closed...")
    const [toggle, setToggle]=useState(false)
    const slides=items.map((item)=>{
        return <CarouselItem tag="div">
            <img src={item.src} alt={item.altText}/>
            <CarouselCaption captionText={item.caption} captionHeader={item.desc}/>
        </CarouselItem>
    })
    function next(){
        
        setActiveIndex((cur)=>{
            if(activeIndex === items.length-1){
                return 0;
            }else{
                return cur+1;
            }
        })
    }
    function previous(){
        
        setActiveIndex((cur)=>{
            if(activeIndex === 0){
                return items.length-1;
            }else{
                return 0;
            }
        })
    }

    return (<div>
        <Container>
        <Row>
            <h2>Carousel is the React Components made up of Item, Caption, Indicator and Controls</h2>
        </Row>
        <Row>
        <Col>
            <h3>ReactStrap Carousel Tutorials</h3>
            <h4>Basic Controlled Carousel Sample</h4>
            <Carousel 
            activeIndex={activeIndex}
            next={next}
            previous={previous}
            >
                <CarouselIndicators
                items={items}
                activeIndex={activeIndex}
                onClickHandler={(index)=>{
                    
                    setActiveIndex(index)}}> 
                </CarouselIndicators>
                {slides}
                <CarouselControl
                direction="prev"
                directionText="Previous"
                onClickHandler={previous}/>
                <CarouselControl
                direction="next"
                directionText="Next"
                onClickHandler={next}/>
            </Carousel>
        </Col>
        <Col>
            <h3>React Boostrap Carousel Tutorials</h3>
            <Carousel1 style={{"color":"white"}} variant="light">
                {items.map((item)=>{
                    return <Carousel1.Item>
                        <img src={item.src} alt={item.altText}/>
                        <Carousel1.Caption>
                            <h2>{item.caption}</h2>
                            <p>{item.desc}</p>
                        </Carousel1.Caption>
                    </Carousel1.Item>
                })}
            </Carousel1>
        </Col>
        </Row>
        <Row>
        <div>
            <Button onClick={()=>setToggle(cur=>!cur)} color="primary">Toggle</Button>
            <h3>Status: {status}</h3>
            <Collapse
            isOpen={toggle}
            onEntering={()=>setStatus("Entering...")}
            onEntered={()=>setStatus("Entered...")}
            onExit={()=>setStatus("Exit...")}
            onExiting={()=>setStatus("Exiting...")}
            onExited={()=>setStatus("Closed...")}>
                <Card>
                    <CardHeader>Card Description</CardHeader>
                    <CardBody>
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus
            terry richardson ad squid. Nihil anim keffiyeh helvetica, craft beer
            labore wes anderson cred nesciunt sapiente ea proident.
                    </CardBody>
                </Card>
            </Collapse>
        </div>
        </Row>
        <Row>
            <h3>Inline List Sample</h3>
            <Card>
                <CardBody>
                <List type="inline">
                    <ListInlineItem>
                        Lorem ipsum
                    </ListInlineItem>
                    <ListInlineItem>
                        Phasellus iaculis
                    </ListInlineItem>
                    <ListInlineItem>
                        Nulla volutpat
                    </ListInlineItem>
                </List>
                </CardBody>
            </Card>
        </Row>
        <Row>
        <Col>
        <h3>ReactStrap List Group Tutorials</h3>
        <h4>ListItems with our without buttons and links</h4>
        <ListGroup>
            {items.map((item)=>{
                return <ListGroupItem action active={item.key===2}>{item.caption}</ListGroupItem>
            })}
        </ListGroup>
        <ListGroup flush>
            {items.map((item)=>{
                return <ListGroupItem action tag="a" href="#" disabled={item.key===2}>{item.caption}</ListGroupItem>
            })}
        </ListGroup>
        <ListGroup>
            {items.map((item)=>{
                return <ListGroupItem action tag="button" className="accordion-button">{item.caption}</ListGroupItem>
            })}
        </ListGroup>
        <ListGroup>
            {items.map((item)=>{
                return <ListGroupItem action>
                    <ListGroupItemHeading tag={'h3'}>{item.caption}</ListGroupItemHeading>
                    <ListGroupItemText tag={'a'} href="#">{item.desc}</ListGroupItemText>
                </ListGroupItem>
            })}
        </ListGroup>
        </Col>
        <Col>
        <h3>React Bootstrap ListGroup Tutorails</h3>
        <h4>Basic ReactBootstrap ListGroup Samples</h4>
        <ListGroup1>
            {items.map((item)=>{
                return <ListGroup1.Item action active={item.key===2}>{item.caption}</ListGroup1.Item>
            })}
        </ListGroup1>
        <ListGroup1  variant="flush">
            {items.map((item)=>{
                return <ListGroup1.Item action tag="a" href="#" disabled={item.key===2}>{item.caption}</ListGroup1.Item>
            })}
        </ListGroup1>
        <ListGroup1>
            {items.map((item)=>{
                return <ListGroup1.Item action tag="button" className="accordion-button">{item.caption}</ListGroup1.Item>
            })}
        </ListGroup1>
        <ListGroup1>
            {items.map((item)=>{
                return <ListGroup1.Item tag={'blockquote'} action>
                    <h3>{item.caption}</h3>
                    <p><a href="#">{item.desc}</a></p>
                </ListGroup1.Item>
            })}
        </ListGroup1>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App;