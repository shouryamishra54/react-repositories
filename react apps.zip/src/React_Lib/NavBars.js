import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Col, Collapse, Container, Dropdown, DropdownToggle, Form, FormGroup, Input, InputGroup, Nav, Navbar, NavbarBrand, NavbarText, NavbarToggler, NavItem, NavLink, Row } from "reactstrap";
import { 
    Navbar as Navbar1,
    Nav as Nav1,
    Dropdown as Dropdown1,
    Form as Form1,
    NavDropdown,
    Offcanvas,

} from "react-bootstrap";

function App(){
    const [isOpen, setIsOpen]=useState(false)
    const [darkTheme, setDarkTheme]=useState(true)
    const [offcanvasOpen, setOffcanvasOpen]=useState(false)

    return <div>
        <Container>
        <Row>
        <Col>
        <h2>Reactstrap NavBar Tutorials</h2>
        <br></br><br></br>
        <h3>Basic NavBar Sample</h3>
        <Navbar color="dark" light={false} dark={true} expand={true} container={true} fixed='top'>
            <NavbarBrand href="#">
                <img src="https://reactstrap.github.io/logo-white.svg" alt="logo"
                style={{height:60, width:60}}/>
                ReactStrap
            </NavbarBrand>
            <Nav tag={'nav'} className="nav-justified">
                <NavItem>
                    <NavLink href="/components"><p className="text-light">Components</p></NavLink>
                </NavItem>
                <NavItem>
                    <NavLink href="https://github.com/reactstrap/reactstrap"><p className="text-light">Github</p></NavLink>
                </NavItem>
            </Nav>
            <NavbarToggler onClick={()=>setIsOpen(cur=>!cur)}/>
            <Collapse isOpen={isOpen} onClick={()=>setIsOpen(cur=>!cur)} navbar>
            <Nav>
                <Form onSubmit={(e)=>e.preventDefault()}>
                    <FormGroup className="list-group-horizontal navbar-nav">
                        <Input type='search'></Input>
                        <Button type="submit">Search</Button>
                    </FormGroup>
                </Form>
            </Nav>
            </Collapse>
        </Navbar>
        <h2>React Bootstrap NavBar Tutorial (attach className="me-auto")</h2>
        <Navbar1 bg="light" expand="lg">
            <Container fluid>
            <Navbar1.Brand href="#">React-Bootstrap Navbar</Navbar1.Brand>
            <Navbar1.Toggle aria-controls=""/>
            <Navbar1.Collapse>
                <Nav1 className="me-auto" style={{'maxHeight':'100px'}} navbarScroll>
                    <Nav1.Item>
                        <Nav1.Link href="#action1">Home</Nav1.Link>
                    </Nav1.Item>
                    <Nav1.Item>
                        <Nav1.Link href="#action2">Link</Nav1.Link>
                    </Nav1.Item>
                    <Nav1.Item>
                        <Dropdown1>
                            <Dropdown1.Toggle>Link</Dropdown1.Toggle>
                            <Dropdown1.Menu>
                                <Dropdown1.Item>
                                    <Nav1.Link href="#action3">Action</Nav1.Link>
                                </Dropdown1.Item>
                                <Dropdown1.Item>
                                    <Nav1.Link href="#action4">Another Action</Nav1.Link>
                                </Dropdown1.Item>
                                <Dropdown1.Divider/>
                                <Dropdown1.Item>
                                    <Nav1.Link href="#action5">Something else here</Nav1.Link>
                                </Dropdown1.Item>
                            </Dropdown1.Menu>
                        </Dropdown1>
                    </Nav1.Item>
                </Nav1>
                <Nav1>
                    <Form1 className="d-flex">
                        <Form1.Control type="search" 
                        placeholder="Search"/>
                        <Button variant="outline-success">Search</Button>
                    </Form1>
                </Nav1>
            </Navbar1.Collapse>
            </Container>
        </Navbar1>
        <br></br><h3>You can also apply Fixed property with any of the two values - top and bottom</h3><br></br>
        <Navbar1 variant="dark" bg="dark" expand="lg" fixed='bottom'>
            <Container>
            <Navbar1.Brand href="#">Responsive Navbar</Navbar1.Brand>
            <Navbar1.Toggle />
            <Navbar1.Collapse>
                <Nav1 className="me-auto">
                    <Nav1.Link href="#features">Features</Nav1.Link>
                    <Nav1.Link href="#pricing">Pricing</Nav1.Link>
                    <Dropdown1>
                        <Dropdown1.Toggle variant="dark">Dropdown</Dropdown1.Toggle>
                        <Dropdown1.Menu variant="dark">
                            <Dropdown1.Item>
                                <Nav1.Link href="#action/1">Action</Nav1.Link>
                            </Dropdown1.Item>
                            <Dropdown1.Item>
                                <Nav1.Link href="#action/2">Another Action</Nav1.Link>
                            </Dropdown1.Item>
                            <Dropdown1.Divider/>
                            <Dropdown1.Item>
                                <Nav1.Link href="#action/3">Separated Action</Nav1.Link>
                            </Dropdown1.Item>
                        </Dropdown1.Menu>
                    </Dropdown1>
                    <NavDropdown title="Dropdown2">
                        <NavDropdown.Item>
                            <Nav1.Link href="#action/1">Action</Nav1.Link>
                        </NavDropdown.Item>
                        <NavDropdown.Item>
                            <Nav1.Link href="#action/2">Another Action</Nav1.Link>
                        </NavDropdown.Item>
                        <NavDropdown.Divider/>
                        <NavDropdown.Item>
                            <Nav1.Link href="#action/3">Separated Action</Nav1.Link>
                        </NavDropdown.Item>
                    </NavDropdown>
                </Nav1>
                <Nav1>
                    <Nav1.Link href="#deeds">More Deeds</Nav1.Link>
                    <Nav1.Link href="#memes">Dank Memes</Nav1.Link>
                </Nav1>
            </Navbar1.Collapse>
            </Container>
        </Navbar1>
        {[false, 'sm', 'md', 'lg', 'xl', 'xxl'].map((e)=>{
            return <Navbar1 bg="light" expand={e}>
                <Container>
                    <Navbar1.Brand>Customized Navbar</Navbar1.Brand>
                    <Navbar1.Toggle />
                    <Navbar1.Collapse>
                    <Nav1 className="me-auto" style={{'maxHeight':'100px'}} navbarScroll>
                        <Nav1.Item>
                            <Nav1.Link href="#action1">Home</Nav1.Link>
                        </Nav1.Item>
                        <Nav1.Item>
                            <Nav1.Link href="#action2">Link</Nav1.Link>
                        </Nav1.Item>
                        <Nav1.Item>
                            <Dropdown1>
                                <Dropdown1.Toggle variant="light">Link</Dropdown1.Toggle>
                                <Dropdown1.Menu>
                                    <Dropdown1.Item>
                                        <Nav1.Link href="#action3">Action</Nav1.Link>
                                    </Dropdown1.Item>
                                    <Dropdown1.Item>
                                        <Nav1.Link href="#action4">Another Action</Nav1.Link>
                                    </Dropdown1.Item>
                                    <Dropdown1.Divider/>
                                    <Dropdown1.Item>
                                        <Nav1.Link href="#action5">Something else here</Nav1.Link>
                                    </Dropdown1.Item>
                                </Dropdown1.Menu>
                            </Dropdown1>
                        </Nav1.Item>
                    </Nav1>
                    <Nav1>
                        <Form1 className="d-flex">
                            <Form1.Control type="search" 
                            placeholder="Search"/>
                            <Button variant="outline-success">Search</Button>
                        </Form1>
                    </Nav1>
                    </Navbar1.Collapse>
                </Container>
            </Navbar1>
        })}
        <h3>Use of Offcanvas with NavBar Changing themes (dark or light) according to the condition Offcanvas is opened or closed</h3>
        {[false, 'sm', 'md', 'lg', 'xl', 'xxl'].map((e)=>{
            return <Navbar1 bg='secondary' expand={e} variant={darkTheme?'dark':'light'}>
                <Container>
                <Navbar1.Brand>Offcampus Navbar</Navbar1.Brand>
                <Navbar1.Toggle onClick={()=>{
                    if(offcanvasOpen){
                        return;
                    }else{
                        setOffcanvasOpen(true)
                        setDarkTheme(cur=>!cur)
                    }}}/>
                <Navbar1.Offcanvas scroll={true}
                    onHide={()=>{
                        console.log("closed");
                        setDarkTheme(cur=>!cur); 
                        setOffcanvasOpen(false)
                    }}>
                    <Offcanvas.Header closeButton>
                        <Offcanvas.Title>OFFCANVAS</Offcanvas.Title>
                    </Offcanvas.Header>
                    <Offcanvas.Body>
                        <Nav1 className="me-auto" style={{'maxHeight':'100px'}} navbarScroll>
                            <Nav1.Item>
                                <Nav1.Link href="#action1">Home</Nav1.Link>
                            </Nav1.Item>
                            <Nav1.Item>
                                <Nav1.Link href="#action2">Link</Nav1.Link>
                            </Nav1.Item>
                            <Nav1.Item>
                                <Dropdown1>
                                    <Dropdown1.Toggle variant="tranparent" className={`text-${darkTheme?'light':''}`}>Link</Dropdown1.Toggle>
                                    <Dropdown1.Menu variant={darkTheme?'dark':'light'}>
                                        <Dropdown1.Item>
                                            <Nav1.Link href="#action3">Action</Nav1.Link>
                                        </Dropdown1.Item>
                                        <Dropdown1.Item>
                                            <Nav1.Link href="#action4">Another Action</Nav1.Link>
                                        </Dropdown1.Item>
                                        <Dropdown1.Divider/>
                                        <Dropdown1.Item>
                                            <Nav1.Link href="#action5">Something else here</Nav1.Link>
                                        </Dropdown1.Item>
                                    </Dropdown1.Menu>
                                </Dropdown1>
                            </Nav1.Item>
                        </Nav1>
                        <Nav1>
                            <Form1 className="d-flex">
                                <Form1.Control type="search" 
                                placeholder="Search"/>
                                <Button variant="outline-success">Go</Button>
                            </Form1>
                        </Nav1>
                    </Offcanvas.Body>
                </Navbar1.Offcanvas>
                </Container>
            </Navbar1>
        })}
        </Col>
        </Row>
        </Container>
    </div>
}
export default App;