import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";

import { Badge, Button, Col, Container, Row } from "reactstrap"
import { Badge as Badge1, Button as Button1 } from "react-bootstrap"

function App(){
    let a=0;
    let b=0;
    return (<div>
        <Container class="align-self-center container">
        <Row>
        <Col style={{"padding":"10px"}} xs="6" md="6" sm="12">
            <h2>ReactStrap Badges Tutorials</h2>
            <h4>Basic Badge</h4>
            <div>{['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                return <Badge color={color}>{color}</Badge>
            })}</div>
            <h4>Basic Badge</h4>
            <div>{['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                return <Badge color={color} href="#" className="text-decoration-none">{color}</Badge>
            })}</div>
            <h4>Badge with Buttons</h4>
            <div>{['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                a++;    
                return <Button color={color} outline href="#" className="text-decoration-none">
                    Notifications{' '}
                    <Badge color={color}>{a}</Badge>
                </Button>
            })}</div>
            <h1>Different Font Size</h1>
            <h2>Example Heading{' '}<Badge>New</Badge></h2>
            <h3>Example Heading{' '}<Badge>New</Badge></h3>
            <h4>Example Heading{' '}<Badge>New</Badge></h4>
            <h5>Example Heading{' '}<Badge>New</Badge></h5>
            <h6>Example Heading{' '}<Badge>New</Badge></h6>
        </Col>
        <Col style={{"padding":"10px"}} xs="6" md="6" sm="12">
            <h2>React-Bootstrap Badges Tutorials</h2>
            <h1>Different Font Size</h1>
            <h2>Example Heading{' '}<Badge1>New</Badge1></h2>
            <h3>Example Heading{' '}<Badge1>New</Badge1></h3>
            <h4>Example Heading{' '}<Badge1>New</Badge1></h4>
            <h5>Example Heading{' '}<Badge1>New</Badge1></h5>
            <h6>Example Heading{' '}<Badge1>New</Badge1></h6>
            <h3>Basic React-Bootstrap</h3>
            <div>
                {['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                  return <Badge1 bg={color}>{color}</Badge1>  
                })}
            </div>
            
            <h3>Badges with Reactstrap Buttons</h3>
            <div>
            {['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                b++;
                return <Button color={color} outline>Notifications{' '}<Badge1 bg={color}>{b}</Badge1></Button>
            })}
            </div>
            <h3>Badges with React-Bootstrap Buttons</h3>
            <div>
            {['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                b++;
                return <Button1 variant={`outline-${color}`} outline>Notifications{' '}<Badge1 bg={color}>{b}</Badge1></Button1>
            })}
            </div>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App