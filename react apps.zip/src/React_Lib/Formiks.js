import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Formik, useFormik } from 'formik';
import * as Yup from 'yup';
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";

function App(){
    const occupation=[
        "Artist", "Business", "Comedian", "Construction Worker", "Contractor", "Defence Professional",
        "Designer", "Education Professional", "Engineer", "Enterpreneur", "Freelancing",
        "Health Professional", "Social Media Experts", "Social Worker", "Sportsman", "IT Professional"
    ]
    const areaofinterest=[
        "Accounts", "Acting", "Animation", "Art", "Audio/Video Artist", "Construction", "Content Creation",
        "Designer", "Engineering", "Games",  "Social Media", "Software Development", "Sports", "Singing",
    ]
    function validatePassword(value){
        let spChars = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
        if(spChars.test(value)){
            return false
        }if(value.indexOf(' ')>=0){
            return false
        }
        return true
    }
    const validate=(values)=>{
        let errors={}
        if(values.firstname.length<=0){
            errors.firstname="Required"
        }if(values.firstname.length>20){
            errors.firstname="Must be always 20 chars or less"
        }if(values.lastname.length<=0){
            errors.lastname="Required"
        }if(values.lastname.length>30){
            errors.lastname="Must be always 30 chars or less"
        }if(values.email.length<=0){
            errors.email="Required"
        }if(values.email.indexOf('@')<=0 || values.email.indexOf('.')<0 || values.email.lastIndexOf('@')>values.email.lastIndexOf('.')){
            errors.email="Email is invalid"
        }if(values.password.length<=0){
            errors.password="Required"
        }if(validatePassword(values.password)){
            errors.password="Password is Invalid"
        }if(values.confirmpass<=0){
            errors.confirmpass="Required"
        }if(values.confirmpass !== values.password){
            errors.confirmpass="Confirm Password must be same as password"
        }if(values.occupation.length<=0){
            errors.occupation="You need to select your Occupation"
        }if(values.areaofinterest.length<=0 || values.areaofinterest[0].length<=0){
            errors.areaofinterest="You need to select your Area Of Interest"
        }
        return errors
    }
    const formik=useFormik({
        initialValues:{
            firstname:'', lastname:'', email:'', password:'', confirmpass:'', occupation:'',
            areaofinterest:[]
        },
        validate,
        onSubmit:(values, {setSubmitting})=>{
            setTimeout(()=>{
                alert(JSON.stringify(values, null, 2));
                setSubmitting(false)
            }, 1000)
        }
    })
    const formik1=useFormik({
        initialValues:{
            firstname:'', lastname:'', email:'', password:'', confirmpass:'', occupation:'',
            areaofinterest:[]
        },
        validationSchema: Yup.object({
            firstname: Yup.string().max(20, "Must be always 20 characters or less").required("Required"),
            lastname: Yup.string().required("Required").max(30, "Must be always 30 characters or less"),
            email: Yup.string().required("Required").email("Invalid Email Address"),
            password: Yup.string().required("Required").min(8, "Password must always be greated than or equal to 8 characters")
            .matches(/[0-9]/, "Password must contains a number")
            .matches(/[a-z]/, "Password must contain a lowercase Charater")
            .matches(/[A-Z]/, "Password must contain an uppercase Character")
            .matches(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/, "Password must contain atleast one special character"),
            confirmpass: Yup.string().required("Required").oneOf([Yup.ref('password'), null], "Must match \"Password\" Field"),
            occupation: Yup.string().required("Required")
        }),
        validate:(values)=>{
            let errors={}
            if(values.areaofinterest[0].length <= 0){
                errors.areaofinterest="Required";
            }
            return errors
        },
        onSubmit:(values, {setSubmitting})=>{
            setTimeout(()=>{
                alert(JSON.stringify(values, null, 2));
                setSubmitting(false)
            }, 1000)
        }
    })
    return <Container>
        <Row>
        <Col>
        <br></br>
        <Form onSubmit={formik.handleSubmit}>
        <Card>
            <Card.Header>
                <Card.Title>Basic Forms having Formik</Card.Title>
            </Card.Header>
            <Card.Body>
                <Form.Group>
                    <Form.Label htmlFor="firstname">First Name</Form.Label>
                    <Form.Control id="firstname" name="firstname" placeholder="Enter the First Name" 
                    type={'text'} onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.firstname} onTouchEnd={formik.handleBlur}
                    isInvalid={formik.touched.firstname && formik.errors.firstname ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.firstname}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="lastname">Last Name</Form.Label>
                    <Form.Control id="lastname" name="lastname" placeholder="Enter the Last Name" 
                    type={'text'} onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.lastname} onTouchEnd={formik.handleBlur}
                    isInvalid={formik.touched.lastname && formik.errors.lastname ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.lastname}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="emailid">Email</Form.Label>
                    <Form.Control id="emailid" name="email" placeholder="Enter the Email" 
                    type={'email'} onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.email} onTouchEnd={formik.handleBlur}
                    isInvalid={formik.touched.email && formik.errors.email ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.email}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="password">Password</Form.Label>
                    <Form.Control id="password" name="password" placeholder="Enter the Password" 
                    type={'password'} onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.password} onTouchEnd={formik.handleBlur}
                    isInvalid={formik.touched.password && formik.errors.password ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.password}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="confirmpass">Confirm Password</Form.Label>
                    <Form.Control id="confirmpass" name="confirmpass" placeholder="Confirm Password" 
                    type={'password'} onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.confirmpass} onTouchEnd={formik.handleBlur}
                    isInvalid={formik.touched.confirmpass && formik.errors.confirmpass ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.confirmpass}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="occupation"></Form.Label>
                    <Form.Select id="occupation" name="occupation"
                    onChange={formik.handleChange} value={formik.values.occupation}
                    isInvalid={formik.touched.occupation && formik.errors.occupation ? true : false}>
                        <option value="" selected>Select Occupation</option>
                        {occupation.map((prof)=>{
                            return <option value={prof}>{prof}</option>
                        })}
                        <option>Other</option>
                    </Form.Select>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.confirmpass}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="areaofinterest"></Form.Label>
                    <Form.Select multiple id="areaofinterest" name="areaofinterest" 
                    onChange={formik.handleChange} value={formik.values.areaofinterest}
                    isInvalid={formik.touched.areaofinterest && formik.errors.areaofinterest ? true : false}>
                        <option value="" selected>Select your Area of Interest</option>
                        {areaofinterest.map((aoi)=>{
                            return <option>{aoi}</option>
                        })}
                        <option value="Others">Others</option>
                    </Form.Select>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik.errors.areaofinterest}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <legend>Check this before submiting</legend>
                    <Form.Check type={'checkbox'} id="value1" name="checkthis" value={'Value 1'} label="Value 1"/>
                    <Form.Check type={'checkbox'} id="value2" name="checkthis" value={'Value 2'} label="Value 2"/>
                    <Form.Check type={'checkbox'} id="value1" name="checkthis" value={'Value 3'} label="Value 3"/>
                </Form.Group>
            </Card.Body>
            <Card.Footer>
                <Button type={'submit'}>Submit</Button>
            </Card.Footer>
        </Card>
        </Form>
        <br></br>
        </Col>
        </Row>
        <Row>
        <Col>
        <Form onSubmit={formik1.handleSubmit}>
        <Card>
            <Card.Header>
                <Card.Title>Formik: Use of Yup</Card.Title>
            </Card.Header>
            <Card.Body>
                <Form.Group>
                    <Form.Label htmlFor="firstname">First Name</Form.Label>
                    <Form.Control id="firstname" name="firstname" placeholder="Enter the First Name" 
                    type={'text'} onChange={formik1.handleChange} onBlur={formik1.handleBlur}
                    value={formik1.values.firstname} onTouchEnd={formik1.handleBlur}
                    isInvalid={formik1.touched.firstname && formik1.errors.firstname ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.firstname}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="lastname">Last Name</Form.Label>
                    <Form.Control id="lastname" name="lastname" placeholder="Enter the Last Name" 
                    type={'text'} onChange={formik1.handleChange} onBlur={formik1.handleBlur}
                    value={formik1.values.lastname} onTouchEnd={formik1.handleBlur}
                    isInvalid={formik1.touched.lastname && formik1.errors.lastname ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.lastname}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="emailid">Email</Form.Label>
                    <Form.Control id="emailid" name="email" placeholder="Enter the Email" 
                    type={'email'} onChange={formik1.handleChange} onBlur={formik1.handleBlur}
                    value={formik1.values.email} onTouchEnd={formik1.handleBlur}
                    isInvalid={formik1.touched.email && formik1.errors.email ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.email}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="password">Password</Form.Label>
                    <Form.Control id="password" name="password" placeholder="Enter the Password" 
                    type={'password'} onChange={formik1.handleChange} onBlur={formik1.handleBlur}
                    value={formik1.values.password} onTouchEnd={formik1.handleBlur}
                    isInvalid={formik1.touched.password && formik1.errors.password ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.password}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="confirmpass">Confirm Password</Form.Label>
                    <Form.Control id="confirmpass" name="confirmpass" placeholder="Confirm Password" 
                    type={'password'} onChange={formik1.handleChange} onBlur={formik1.handleBlur}
                    value={formik1.values.confirmpass} onTouchEnd={formik1.handleBlur}
                    isInvalid={formik1.touched.confirmpass && formik1.errors.confirmpass ? true : false}/>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.confirmpass}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="occupation"></Form.Label>
                    <Form.Select id="occupation" name="occupation"
                    onChange={formik1.handleChange} value={formik1.values.occupation}
                    isInvalid={formik1.touched.occupation && formik1.errors.occupation ? true : false}>
                        <option value="" selected>Select Occupation</option>
                        {occupation.map((prof)=>{
                            return <option value={prof}>{prof}</option>
                        })}
                        <option>Other</option>
                    </Form.Select>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.confirmpass}
                    </Form.Control.Feedback>
                </Form.Group>
                <Form.Group>
                    <Form.Label htmlFor="areaofinterest"></Form.Label>
                    <Form.Select multiple id="areaofinterest" name="areaofinterest" 
                    onChange={formik1.handleChange} value={formik1.values.areaofinterest}
                    isInvalid={formik1.touched.areaofinterest && formik1.errors.areaofinterest ? true : false}>
                        <option value="" selected>Select your Area of Interest</option>
                        {areaofinterest.map((aoi)=>{
                            return <option>{aoi}</option>
                        })}
                        <option value="Others">Others</option>
                    </Form.Select>
                    <Form.Control.Feedback type={'invalid'}>
                        {formik1.errors.areaofinterest}
                    </Form.Control.Feedback>
                </Form.Group>
            </Card.Body>
            <Card.Footer>
                <Button type={'submit'}>Submit</Button>
            </Card.Footer>
        </Card>
        </Form>
        <br></br>
        </Col>
        </Row>
    </Container>
}
export default App;