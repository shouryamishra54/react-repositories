import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";

import { Alert as Alert1, Card, Col, Container, Row, UncontrolledAlert } from "reactstrap";
import { Alert, Button } from "react-bootstrap";

function App(){
    const [show, setShow]=useState(true);
    const [alertnum, setAlertnum]=useState();
    const [fadealert, setFadeAlert]=useState(false);
    function toggleHandler(){
        setShow(false)
    }
    function button1handler(){

    }
    return (<div><Container className="align-self-center container">
        <Row>
        <Col style={{"padding":"10px"}} xs="6" md="6" sm="12">
            <h2>Reactstrap Alert Tutorial</h2>
            <h4>Basic Alert</h4>
            <Alert1>
                <h4 className="alert-heading">I am an alert and I can't be dismissed</h4>
                <p>
                    Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.
                </p>
                <hr/>
                <p>
                    Whenever you need to, be sure to use margin utilities to keep things nice and tidy.
                </p>
            </Alert1>
            <h4>Alert with close and open button</h4>
            <Alert1 isOpen={show} toggle={()=>{setShow(false)}}>
                <h4>I am an alert and I can be dismissed!</h4>
            </Alert1>
            <Button onClick={()=>{setShow(true)}}>Click here</Button>
            <h4>Use of UncontrolledAlert</h4>
            <UncontrolledAlert>
                <h4>I am an Uncontrolled Alert and I can be dismissed</h4>
            </UncontrolledAlert>
            <Alert1 isOpen={!fadealert}>
            <heading>.How's it going?!</heading>
                <p>
                Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget
                lacinia odio sem nec elit. Cras mattis consectetur purus sit amet
                fermentum.
                </p>
                <hr />
                <div className="d-flex justify-content-end">
                <Button onClick={() => setFadeAlert(true)} variant="outline-success">
                    Close me y'all!
                </Button>
                </div>
            </Alert1>
            {fadealert && <Button onClick={()=>{setFadeAlert(false)}}>Show Alert</Button>}
        </Col>
        <Col>
            {['primary','secondary','white','danger','warning','info','light','dark'].map((color)=>{
            return <Card>
                    <Alert1 isOpen={alertnum !== color && (alertnum || alertnum === undefined)} id={color} color={color} 
                    toggle={()=>{setAlertnum(color)}}>
                        <h4>. Give it a click if you like.</h4>
                        <p>
                            This is a {color} alert with {' '}
                            <a href="#">an example link</a>. Give it a click if you like.
                        </p>
                    </Alert1>  
                    {alertnum && alertnum === color &&
                    <Button variant={color} onClick={()=>{setAlertnum()}}>
                        Click me to display {color} alert
                    </Button>}                      
                </Card>
            })}
        </Col>
        </Row>
    </Container></div>)
}
export default App;