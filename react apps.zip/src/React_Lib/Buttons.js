import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Col, Container, Row } from "reactstrap";
import { Button as Button1 } from "react-bootstrap";

function App(){
    let a=0;
    function stimulateNetworkRequest(){
        return new Promise((resolve)=>setTimeout(() => {
            resolve();
        }, 2000))
    }
    // let isLoading=[];
    const [isLoading, setIsLoading]=useState(new Array(8).fill(false))
    const [buttonActivated, setButtonActivated]=useState()
    const [isLoading1, setIsLoading1]=useState(false)
    const [button1Activated, setButton1Activated]=useState(false)
    // const [buttonIds, setButtonIds]=useState([])
    // console.log(isLoading)
    useEffect((e)=>{
        // preventDefault();
        // console.log(buttonActivated)
        if(buttonActivated >= 0){
            stimulateNetworkRequest().then(()=>{
                for(let i=0;i<isLoading.length;i++){
                    if(isLoading[i] === true){
                        // console.log("Loaded "+i)
                        // isLoading.shift();
                        let newState=isLoading;
                        newState[i]=false
                        setIsLoading(newState)
                    }
                }
                setButtonActivated()
                // setButtonIds((prev)=>{prev.shift()})
            })    
            // setIsLoading((cur)=>!cur[buttonActivated])
            
            // setTimeout(()=>{console.log(isLoading);setIsLoading()}, 1000)
        }
    }, [buttonActivated])
    /*useEffect(()=>{
        console.log("Loading 2...")
        if(buttonActivated>=0 && isLoading[buttonActivated]===false){
            setButtonActivated()
        }
    }, [isLoading[buttonActivated]])*/
    useEffect(()=>{
        if(button1Activated && isLoading1){
            stimulateNetworkRequest().then(()=>{
                // isLoading.shift();
                setIsLoading1(false)
                setButton1Activated(false)
                // setButtonIds((prev)=>{prev.shift()})
            })
        }
    }, [button1Activated])
    // console.log(isLoading)
    return (<div>
        <Container className="align-self-center container">
        <Row>
        <Col style={{"padding":"10px"}} xs="6" md="6" sm="12">
            <h2>ReactStrap Button Tutorial</h2>
            <h3>Basic ReactStrap Buttons</h3>
            <Button color="success">Click Me</Button>
            <h2>Using 'a' tag and 'input' without using {'<>'} symbol along with Disabled and Outlines</h2>
            <Button color="primary" tag="a" href="#">Link</Button>{' '}
            <Button color="secondary" size="lg" tag="input" type="submit" value="Submit"></Button>{' '}
            <Button color="warning" tag="input" type="submit" value="Reset"></Button>{' '}
            <Button color="secondary" tag="input" type="submit" disabled value="Disabled"></Button>{' '}
            <Button color="danger" outline tag="input" type="submit" disabled value="Disbled Outline"></Button>
        </Col>
        <Col style={{"padding":"10px"}} xs="6" md="6" sm="12">
            <h2>React-Bootstrap Button Tutorial</h2>
            <h3>Basic React Bootstrap Buttons with outline</h3>
            <div>
                {['primary','secondary','success','danger','warning','info','light','dark'].map((color)=>{
                    const id=a++;
                    const outline=a>4?"outline-":"";
                    return <Button1 disabled={isLoading[id] === true }
                    style={{"padding":"5px", "margin":"5px"}} 
                    variant={`${outline}${color}`}
                    onClick={(e)=>{
                        // setButtonIds((prev)=>prev.push(id))
                        e.preventDefault()
                        // console.log(id)
                        // isLoading.push(id)
                        // setIsLoading((cur)=>[...cur, id])
                        let newState=isLoading;
                        newState[id]=true
                        setIsLoading(newState)
                        setButtonActivated(id)
                                              
                    }}>{(isLoading[id] === true) ? `Loading...`:`Button ${color}`}</Button1>
                })}
            </div>
            <h3>Changing the State of the button</h3>
            <Button1
            disabled={isLoading1}
            onClick={()=>{setIsLoading1(true); setButton1Activated(true)}}>
                {isLoading1? `Loading...`:`Click Me`}
            </Button1>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App;