import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap/dist/js/bootstrap.min.js";
import { Button, Card, CardBody, CardFooter, CardHeader, CardTitle, Col, Container, Form, FormFeedback, FormGroup, FormText, Input, Label, Row } from "reactstrap";

function App(){

    return (<div>
        <Container>
        <Row>
        <Col><br></br>
        <Card className="card">
        <Form onSubmit={(e)=>{e.preventDefault(); console.log("Submitted")}}>
            <CardHeader>
                <CardTitle>Simple Form Sample</CardTitle>
            </CardHeader>
            <CardBody>
                <FormGroup>
                    <Label for="emailaddress">Email</Label>
                    <Input id="emailaddress" name="email" placeholder="Enter Email Address" type={'email'}/>
                </FormGroup>
                <FormGroup>
                    <Label from="password">Password</Label>
                    <Input id="password" name="password" placeholder="Enter Password" type={'password'}/>
                </FormGroup>
                <FormGroup>
                    <Label for="selectoption">Select single option</Label>
                    <Input id="selectoption" name="select" placeholder="Select Option" type={'select'}>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </Input>
                </FormGroup>
                <FormGroup>
                    <Label for="selectmultoption">Select Multiple Option</Label>
                    <Input id="selectmultoption" name="selectmult" placeholder="Select Mutiple Option" type={'select'} multiple>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </Input>
                </FormGroup>
                <FormGroup>
                    <Label for="textarea">Textarea</Label>
                    <Input id="textarea" name="textarea" placeholder="Enter Text" type={'textarea'} bsSize={'lg'}/>
                </FormGroup>
                <FormGroup>
                    <Label id="inputfile">File</Label>
                    <Input type={'file'} id="inputfile" name="fileinput"/>
                    <FormText>
                        This is some placeholder block-level help text for the above input. It‘s a bit lighter and easily wraps to a new line.
                    </FormText>
                </FormGroup>
                <FormGroup>
                    <legend>Radio Buttons</legend>
                    <FormGroup check>
                        <Input type={'radio'} name="radio1"/>{' '}
                        <Label check>Option one is this and that—be sure to include why it‘s great</Label>
                    </FormGroup>
                    <FormGroup check>
                        <Input type={'radio'} name="radio1"/>{' '}
                        <Label check>Option two can be something else and selecting it will deselect option one</Label>
                    </FormGroup>
                </FormGroup>
                <FormGroup>
                    <legend>CheckBox</legend>
                    <FormGroup check>
                        <Input type={'checkbox'} name="check1"/>{' '}
                        <Label check>Check me out</Label>
                    </FormGroup>
                    <FormGroup check>
                        <Input type={'checkbox'} name="check1"/>{' '}
                        <Label check>Check me out</Label>
                    </FormGroup>
                </FormGroup>
            </CardBody>
            <CardFooter>
                <Button type={'submit'} color="primary">Submit</Button>
            </CardFooter>
        </Form>
        </Card><br></br><br></br>
        <Card>
        <Form>
            <CardHeader>
                <CardTitle>Form Feedback</CardTitle>
            </CardHeader>
            <CardBody>
                <FormGroup>
                    <Label for="emailaddr1">Input without Validation</Label>
                    <Input id="emailaddr1" name="email1" type={'email'}/>
                    <FormFeedback>You will not be able to see this.</FormFeedback>
                </FormGroup>
                <FormGroup>
                    <Label for="emailaddr">Valid Email Address</Label>
                    <Input id="emailaddr" name="email" type={'email'} valid/>
                    <FormFeedback valid>
                        Email is valid... (Need to apply "valid" attribute in formfeedback)
                    </FormFeedback>
                </FormGroup>
                <FormGroup>
                    <Label for="emailaddr2">Invalid Email Address</Label>
                    <Input id="emailaddr2" name="email2" type={'email'} invalid/>
                    <FormFeedback>
                        Email is invalid...(No need to apply "invalid" attribute in formfeedback)
                    </FormFeedback>
                </FormGroup>
                <FormGroup>
                    <Label for="password1">Password without validation</Label>
                    <Input id="password1" name="password" type={'password'}/>
                    <FormFeedback>You will not be able to see this.</FormFeedback>
                </FormGroup>
                <FormGroup className="position-relative">
                    <Label for="password">Valid Password</Label>
                    <Input id="password" name="password" type={'password'} valid/>
                    <FormFeedback valid tooltip>
                        Password is valid... (Need to apply "valid" attribute in formfeedback)
                    </FormFeedback>
                    <FormText>
                        Apply className="positon-relative" otherwise the tooltip will go to bottom
                    </FormText>
                </FormGroup>
                <FormGroup className="position-relative">
                    <Label for="password2">Invalid Password</Label>
                    <Input id="password2" name="password2" type={'password'} invalid/>
                    <FormFeedback tooltip>
                        Password is invalid... (No need to apply "invalid" attribute in formfeedback)
                    </FormFeedback>
                    <FormText>
                        Apply className="positon-relative" otherwise the tooltip will go to bottom
                    </FormText>
                </FormGroup>
            </CardBody>
            <CardFooter>
                <Button type={'submit'} color="primary">Submit</Button>
            </CardFooter>
        </Form>
        </Card><br></br><br></br>
        <Card>
        <Form>
            <CardHeader>
                <CardFooter>Form Grid</CardFooter>
            </CardHeader>
            <CardBody>
                <FormGroup row>
                    <Label for="emailaddr" sm={2}>Email</Label>
                    <Col sm={10}>
                        <Input id="emailaddr" name="emailaddr" type={'email'}/>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <Label for="password" sm={2}>Password</Label>
                    <Col sm={10}>
                        <Input id="password" name="password" type={'password'}/>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <Label for="selectoption" sm={2}>Select single option</Label>
                    <Col sm={10}>
                        <Input id="selectoption" name="select" placeholder="Select Option" type={'select'}>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                        </Input>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <Label for="selectmultoption" sm={2}>Select single option</Label>
                    <Col sm={10}>
                        <Input id="selectmultoption" name="selectmult" placeholder="Select Multiple Option" type={'select'} multiple>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                        </Input>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <Label for="textarea" sm={2}>Textarea</Label>
                    <Col sm={10}>
                        <Input id="textarea" name="textarea" placeholder="Enter Text" type={'textarea'} bsSize={'lg'}/>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <Label id="inputfile" sm={2}>File</Label>
                    <Col sm={10}>
                        <Input type={'file'} id="inputfile" name="fileinput"/>
                        <FormText>
                            This is some placeholder block-level help text for the above input. It‘s a bit lighter and easily wraps to a new line.
                        </FormText>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <legend className="col-sm-2">
                        Radio Button
                    </legend>
                    <Col sm={10}>
                        <FormGroup check>
                            <Input type={'radio'} name="radio2"/>{' '}
                            <Label check>
                                Option one is this and that—be sure to include why it‘s great
                            </Label>
                        </FormGroup>
                        <FormGroup check>
                            <Input type={'radio'} name="radio2"/>{' '}
                            <Label check>
                                Option two can be something else and selecting it will deselect option one
                            </Label>
                        </FormGroup>
                        <FormGroup check>
                            <Input type={'radio'} name="radio2"/>{' '}
                            <Label check>
                                Option three is disabled
                            </Label>
                        </FormGroup>
                    </Col>
                </FormGroup>
                <FormGroup row>
                    <legend className="col-sm-2">
                        CheckBox
                    </legend>
                    <Col sm={10}>
                        <FormGroup check>
                            <Input type={'checkbox'} name="check2"/>{' '}
                            <Label check>
                                Check me out
                            </Label>
                        </FormGroup>
                        <FormGroup check>
                            <Input type={'checkbox'} name="check2"/>{' '}
                            <Label check>
                                Check me out
                            </Label>
                        </FormGroup>
                    </Col>
                </FormGroup>
            </CardBody>
            <CardFooter>
                <FormGroup row>
                    <Col className="offset-sm-2">
                        <Button type={'submit'} color="primary">Submit</Button>
                    </Col>
                </FormGroup>
            </CardFooter>
        </Form>
        </Card><br></br><br></br>
        <Card>
        <Form>
            <CardHeader>
                <CardTitle>Form Grid with Rows</CardTitle>
            </CardHeader>
            <CardBody>
                <Row>
                <Col sm={6}>
                    <FormGroup>
                        <Label for="emailaddr" sm={2}>Email Address</Label>
                        <Input id="emailaddr" name="emailaddr" type={'email'}/>
                    </FormGroup>
                </Col>
                <Col sm={6}>
                    <FormGroup>
                        <Label for="password" sm={2}>Password</Label>
                        <Input id="password" name="password" type={'password'}/>
                    </FormGroup>
                </Col>
                </Row>
                <Row>
                    <FormGroup>
                        <Label for="addressline1" sm={2}>Address Line 1</Label>
                        <Input id="addressline1" name="address1" type={'text'}/>
                    </FormGroup>
                </Row>
                <Row>
                    <FormGroup>
                        <Label for="addressline2" sm={2}>Address Line 2</Label>
                        <Input id="addressline2" name="address2" type={'text'}/>
                    </FormGroup>
                </Row>
                <Row>
                    <Col sm={3}>
                        <FormGroup>
                            <Label for="cityname">City</Label>
                            <Input id="cityname" name="city" type={'text'}/>
                        </FormGroup>
                    </Col>
                    <Col sm={4}>
                        <FormGroup>
                            <Label for="statename">State</Label>
                            <Input id="statename" name="state" type={'text'}/>
                        </FormGroup>
                    </Col>
                    <Col sm={3}>
                        <FormGroup>
                            <Label for="countrycode">Country</Label>
                            <Input id="countrycode" name="country" type={'text'}/>
                        </FormGroup>
                    </Col>
                    <Col sm={2}>
                        <FormGroup>
                            <Label for="zipcode">Zipcode</Label>
                            <Input id="zipcode" name="zipcode" type={'text'}/>
                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <FormGroup>
                        <Input name="check3" type={'checkbox'}/>{' '}
                        <Label for="check3">Check me out</Label>
                    </FormGroup>
                </Row>
            </CardBody>
            <CardFooter>
                <FormGroup row>
                    <Col className="offset-sm-2">
                        <Button type={'submit'} color="primary">Submit</Button>
                    </Col>
                </FormGroup>
            </CardFooter>
        </Form>
        </Card>
        </Col>
        </Row>
        </Container>
    </div>)
}
export default App;