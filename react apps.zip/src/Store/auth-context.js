import React,{useState, useEffect} from "react";

const AuthContext=React.createContext({
    isLoggedIn:false,
    onLogin:(email, password)=>{},
    onLogout:()=>{}
})
export function AuthContextProvider(data){
    const [isLoggedIn, setIsLoggedIn]=useState(false);
    useEffect(()=>{
        const storedUserLoggedInInformation=localStorage.getItem('isloggedin');
        if(storedUserLoggedInInformation === '1'){
            setIsLoggedIn(true)
        }
        console.log(storedUserLoggedInInformation)
    }, [])
    function loginHandler(){
        //if(!localStorage.getItem('isloggedin')){
            setIsLoggedIn(true)
            localStorage.setItem('isloggedin', '1')
        //}
    }
    function logoutHandler(){
        //if(localStorage.getItem('isloggedin')){
            setIsLoggedIn(false)
            localStorage.removeItem('isloggedin')
        //}
    }
    return (
        <AuthContext.Provider value={{
            isLoggedIn:isLoggedIn, 
            onLogin:loginHandler, 
            onLogout:logoutHandler}}>
            {data.children}
        </AuthContext.Provider>
    )
}

export default AuthContext;