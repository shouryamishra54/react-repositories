import React, { Component, Fragment, useEffect, useState } from "react";
import { HashRouter as Router, Route, NavLink, Redirect } from "react-router-dom";
import "./App.css";
import "./HospitalApplication/App.css";
import ViewProfile from "./HospitalApplication/pages/ViewProfile";
import "./APIFetcher/styles/bootstrap.css"
import Header from "./Products/components/Layout/Header";
import NewProduct from "./Products/components/Product/NewProduct";
import Products from "./Products/components/Product/Products";

function App() {
  const [loadedProducts, setLoadedProducts]=useState();
  const [isLoading, setIsLoading]=useState(false);
  useEffect(()=>{
    fetchLoading()
  }, [])
  async function fetchLoading(){
    setIsLoading(true);
    const response=await fetch("http://localhost:5000/products")
    const responseData=await response.json();
    console.log(responseData)
    setLoadedProducts(responseData.products)
    setIsLoading(false)
  }
  async function addProductHandler(title, price){
    try{
      const newProduct = {title: title, price: +price}
      let hasError=false;
      const response = await fetch("http://localhost:5000/product", {
        method: "POST",
        body: JSON.stringify(newProduct),
        headers: {
          "Content-Type":"application/json"
        }
      })
      if(!response.ok){
        hasError=true
      }
      const responseData=await response.json()
      if(hasError){
        throw new Error(responseData.message)
      }
      if(!hasError && responseData.product.id){
        setLoadedProducts((prevProducts)=>{
          return prevProducts.concat({
            ...newProduct,
            id:responseData.product.id
          })
        })
      }
    }catch(e){
      console.log(e)
      alert(e.message || "Something went wrong")
    }
  }
  return (
    <div className="App">
      <div className="App__Form">
        <Fragment>
          <Header/>
          <NewProduct onAddProduct={addProductHandler}/>
          {isLoading && <h4>Loading...</h4>}
          {!isLoading && <Products products={loadedProducts}></Products>}
        </Fragment>
      </div>
    </div>
  )
}

export default App;