import { Fragment } from "react"
import classes from "./Header.module.css";

function Header(){
    return (<Fragment>
        <header className={classes.header}>
            <a className="Header_details" style={{"textDecoration":"none", "color":"white"}} 
            href="/"><h1>Products</h1></a>
        </header>
    </Fragment>)
}
export default Header