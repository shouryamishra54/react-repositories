import { Fragment, useState } from "react"
import Button from "../Button/Button";
import Input from "../Input/Input";

function NewProduct(props){
    const [title, setTitle]=useState('');
    const [price, setPrice]=useState('');
    function titleChangeHandler(e){
        setTitle(e.target.value)
    }
    function priceChangeHandler(e){
        setPrice(e.target.value)
    }
    function submitHandler(e){
        e.preventDefault();
        props.onAddProduct(title, price)
    }
    return (<Fragment>
        <section>
            <h2>Add a New Product</h2>
            <form onSubmit={submitHandler}>
                <Input type="text" label="Title" id="title" value={title} onChange={titleChangeHandler}/>
                <Input type="number" label="Price" id="price" step={0.01} value={price}
                onChange={priceChangeHandler}/>
                <Button type="submit">ADD PRODUCT</Button>
            </form>
        </section>
    </Fragment>)
}
export default NewProduct