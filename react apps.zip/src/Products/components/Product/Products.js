import { Fragment } from "react"
import ProductItem from "./ProductItem";

function Products(props){
    const products=props?props.products:null
    return (<Fragment>
        <section>
            {!products && <div>No Product Found</div>}
            {products && products.length>0 && <div>
                <header class="Header_details">
                    Products Detail
                </header>
                <ul>
                    {products.map((product)=>{
                        return (<ls key={product.id}><ProductItem item={product}/></ls>
                        )
                    })}
                </ul>
            </div>}
        </section>
    </Fragment>)
}
export default Products