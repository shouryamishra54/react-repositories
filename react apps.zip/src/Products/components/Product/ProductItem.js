
function ProductItem(props){
    const productItem=props?props.item:null;
    return (<div>
        {!productItem && <div><h3>Error in finding the Product</h3></div>}
        {productItem && <div>
            <h2>{productItem.title}</h2>
            <p>Price: {productItem.price}</p>
        </div>}
    </div>
    )
}
export default ProductItem