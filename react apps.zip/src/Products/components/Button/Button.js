
function Button(props){
    return (<div className={`button FormField__Button ${props.className}`}>
        <button type={props.type} id={props.id}>{props.children}</button>
    </div>)
}
export default Button