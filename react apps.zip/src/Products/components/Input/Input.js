
function Input(props){
    return (<div className={`input FormField_Input ${props.className}`}>
        <label htmlFor={props.id}>{props.label}</label>
        <input 
        type={props.type} step={props.step} id={props.id} value={props.value} onChange={props.onChange}/>
    </div>)
}
export default Input