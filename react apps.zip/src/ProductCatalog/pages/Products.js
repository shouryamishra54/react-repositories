import { useContext } from "react";
//import { useSelector } from "react-redux"
import ProductList from "../components/products/ProductList";
import { ProductContext } from "../context/product-redux";

function Products(){
    //const products = useSelector(state=>state.shop.products)
    // console.log(products)
    const products = useContext(ProductContext).products
    // console.log(products)
    return (
        <div>
            {products && products.length>=0 && 
            <ProductList productlist={products}></ProductList>}
            {!products && <h3>No Product Found</h3>}
        </div>
    )
}
export default Products;