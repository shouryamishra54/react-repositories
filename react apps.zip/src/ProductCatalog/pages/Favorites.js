import { useContext } from "react";
//import { useSelector } from "react-redux"
import FavoriteList from "../components/products/FavoriteList";
import { ProductContext } from "../context/product-redux";

function Favorites(){
    //const products = useSelector(state=>state.shop.products)
    const products = useContext(ProductContext).products;
    const favorites = products.filter((item)=>{return item.isFavorite})
    // console.log(products)
    return (
        <div>
            {favorites && favorites.length>=0 && 
            <FavoriteList productlist={favorites}></FavoriteList>}
            {!favorites && <h3>No Favorite!</h3>}
        </div>
    )
}
export default Favorites