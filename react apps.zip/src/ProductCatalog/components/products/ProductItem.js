import classes from "./ProductItem.module.css";
import Card from "../UI/Card/Card";
import Button from "../UI/Button/Button";
//import { useDispatch } from "react-redux";
//import { togglefav } from "../../store/actions/products";
import { useContext } from "react";
import { ProductContext } from "../../context/product-redux";

function ProductItem(props){
    //const dispatch=useDispatch();
    const productctx=useContext(ProductContext)
    function togglefavHandler(){
        // dispatch(togglefav(props.product.id))
        productctx.togglefav(props.product.id)
        console.log(props.product.isFavorite)
    }
    return (
        <Card>
            <span className={classes['product-item']}>
                <h3 className={props.product.isFavorite ? classes['is-fav'] : ``}>
                    {props.product.title}
                </h3>
            </span>
            <p>{props.product.description}</p>
            <Button onClick={togglefavHandler}>
                {props.product.isFavorite ? 'Un-Favorite' : 'Favorite'}
            </Button>
        </Card>
    )
}
export default ProductItem