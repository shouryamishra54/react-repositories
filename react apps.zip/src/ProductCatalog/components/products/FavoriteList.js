import Card from "../UI/Card/Card"
import FavoriteItem from "./FavoriteItem"

function FavoriteList(props){
    return (
        <Card>
            {props.productlist.map((item)=>{return <FavoriteItem product={item}></FavoriteItem>})}
        </Card>
    )
}
export default FavoriteList