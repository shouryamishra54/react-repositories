import Card from "../UI/Card/Card";
import ProductItem from "./ProductItem";

function ProductList(props){
    // console.log(props)
    return (
        <Card>
            {props.productlist.map((item)=>{return <ProductItem product={item}></ProductItem>})}
        </Card>
    )
}
export default ProductList