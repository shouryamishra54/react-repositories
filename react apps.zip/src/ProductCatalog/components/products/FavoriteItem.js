import classes from "./FavoriteItem.module.css";
import Card from "../UI/Card/Card";

function FavoriteItem(props){
    return (
        <Card style={{ marginBottom: '1rem' }}>
            <div className={classes['favorite-item']}>
                <h2>
                    {props.product.title}
                </h2>
                <p>{props.product.description}</p>
            </div>
        </Card>
    )
}
export default FavoriteItem