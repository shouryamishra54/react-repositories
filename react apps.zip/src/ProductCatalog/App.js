import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import { BrowserRouter, Redirect, Route, Switch, Routes } from "react-router-dom";
import Layout from "./ProductCatalog/components/layout/Layout.js"
import Products from "./ProductCatalog/pages/Products.js"
import Favorites from "./ProductCatalog/pages/Favorites.js"
//USE OF ROUTERS
//import Counter from "./use-of-redux/components/Counter"
//import Auth from "./use-of-redux/components/Auth"
//import Header from "./use-of-redux/components/Header"
//import UserProfile from "./use-of-redux/components/UserProfile"
import defautclasses from "./APIFetcher/styles/default.module.css";
import AuthPage from "./RouterTutorial/Quotes/Pages/AuthPage";
import ProfilePage from "./RouterTutorial/Quotes/Pages/ProfilePage";
import ErrorPage from "./RouterTutorial/Quotes/Pages/ErrorPage";
//import ProductDetail from "./RouterTutorial/Link/Component/Pages/ProductDetails";

//import { useSelector } from "react-redux";
//import store from "./use-of-redux/store/index";

//Use of Redux State Management
function App(){
    //const loggedin=useSelector(state=>state.authentication.login)
    return (<div className="App">
        <div className="page-header">
            <h1>Explaination of React-Router</h1>
        </div>
        <body>
            <Layout>
                <Switch>
                    <Route path="/" exact>
                        <Redirect to={"/products"}></Redirect>
                    </Route>
                    <Route path="/products" exact>
                        <Products />
                    </Route>
                    <Route path="/favorites">
                        <Favorites />
                    </Route>
                    <Route path="*">
                        <ErrorPage />
                    </Route>
                </Switch>
            </Layout>
        </body>
    </div>)
}
export default App;