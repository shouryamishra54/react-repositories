export const TOGGLE_FAV="togglefav";

export const togglefav = id =>{
    return ({type: TOGGLE_FAV, id: id})
}