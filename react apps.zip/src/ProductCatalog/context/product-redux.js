import React, { useEffect, useState } from "react";
export const ProductContext = React.createContext({
  products: [],
  togglefav: (id) => {}
});
export default function ProductContextProvider(data) {
    const [products, setProducts] = useState([
        {
          id: 'p1',
          title: 'Red Scarf',
          description: 'A pretty red scarf.',
          isFavorite: false
        },
        {
          id: 'p2',
          title: 'Blue T-Shirt',
          description: 'A pretty blue t-shirt.',
          isFavorite: false
        },
        {
          id: 'p3',
          title: 'Green Trousers',
          description: 'A pair of lightly green trousers.',
          isFavorite: false
        },
        {
          id: 'p4',
          title: 'Orange Hat',
          description: 'Street style! An orange hat.',
          isFavorite: false
        }
      ])
  
  /*useEffect(()=>{
        if(localStorage.getItem("token")){
            setToken(JSON.parse(localStorage.getItem("token")))
        }
    }, [])*/
    function toggleFavorite(id){
        setProducts((currProdList)=>{
            const index=products.findIndex((product)=>{return product.id === id})
            const updatedproducts=[...products]
            updatedproducts[index]={...updatedproducts[index], isFavorite:!updatedproducts[index].isFavorite}
            return updatedproducts
        })
    }
    return (
    <ProductContext.Provider
        value={{
        products: products,
        togglefav: toggleFavorite
        }}
    >
        {data.children}
    </ProductContext.Provider>
    );
}
// export default ProductContext;
