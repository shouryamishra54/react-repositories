import Carousel from "react-bootstrap/Carousel"
import Image from "react-bootstrap/esm/Image"
import ButtonGroup from "react-bootstrap/ButtonGroup"
import Button from "react-bootstrap/Button"
import Card from "react-bootstrap/Card";
import { useContext, useEffect, useState } from "react"
import { AuthContext } from "../../shared/context/auth-context"
import Container from "react-bootstrap/esm/Container"
import Map from "../../shared/components/UIElements/Map";
import Modal from "react-bootstrap/Modal";
import { Figure } from "react-bootstrap";
import { Link, NavLink, Redirect, useHistory } from "react-router-dom";
import { fetchImage } from "../../shared/libs/api";
import UseHttp from "../../shared/hooks/use-http";
// import Modal from "../../shared/components/UIElements/Modal";

function PlaceItem(props){
    const [mapOpened, setMapOpened]=useState(false);
    function mapClickHandler(){
        setMapOpened((prev)=>!prev)
    }
    const [imageLink, setImageLink]=useState()
    const {isLoading, error, data:imageData, sendRequest: getUserImage}=UseHttp(fetchImage)
    useEffect(()=>{
        if(props.place.images){
            getUserImage({imagePath:props.place.images[0]})
        }
    }, [])
    console.log(imageData)
    function generateImage(){
        let blob=new Blob([imageData.byteArray], {
            type: "image/jpeg, image/jpg, image/png"
        })
        let link=document.createElement("a")
        link.href=window.URL.createObjectURL(blob);
        setImageLink(link.href)
        link.href.concat(".png")
        link.download=props.place.images[0]
        window.open(link.href)
    }
    /*function redirect(id){
        const history=useHistory();
        history.push(`/places/${id}`)
    }*/
    console.log(mapOpened)
    return (<Card bg="light">
        <Card.Body>
            <Link onClick={()=>{if(imageData && imageData.imageData){generateImage()}}}>
            <Card.Img style={{"opacity": "0.5"}}
                height={500} width={300}
                src={imageData ? imageData.imageData : undefined}/></Link>
            <Carousel.Caption>
            <h3>
                <NavLink class="nav-link" style={{"color": "black"}} to={`/places/${props.place.id}`}>
                    <strong>{props.place.title}</strong>
                </NavLink>
            </h3>
            <p style={{"color": "black"}}>{props.place.address}</p>
            <ButtonGroup>
                <Button type="button" size="lg" variant="primary" onClick={mapClickHandler}>
                    Show on Map
                </Button>
            </ButtonGroup>
            </Carousel.Caption>
            <Modal
                show={mapOpened}
                onHide={mapClickHandler}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                <Modal.Title>{props.place.address}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                <h2>We are not able to open the map right now due to techincal issues.</h2>
                </Modal.Body>
                <Modal.Footer>
                <Button variant="secondary" onClick={mapClickHandler}>
                    Close
                </Button>
                <Button variant="primary">Understood</Button>
                </Modal.Footer>
            </Modal>
        </Card.Body>
        <Card.Footer>
            <div></div>
        </Card.Footer>
    </Card>)
}
export default PlaceItem