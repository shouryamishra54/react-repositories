import React, { Component } from "react";
import PropTypes from "prop-types";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "ckeditor5-build-classic-dna";
import UseHttp from "../../hooks/use-http";
import { uploadImage } from "../../libs/api";

export default class MyUploadAdapter {
  constructor(loader) {
    // The file loader instance to use during the upload.
    this.loader = loader;
  }

  // Starts the upload process.
  upload() {
    const {uploadLoading, uploadError, data: imageData, sendRequest:uploadImageRequest}=UseHttp(uploadImage)
    return this.loader.file.then(async (file) => {
        uploadImageRequest({file: file});
        if (uploadError) {
        console.log(uploadError);
      }
      // default image - in case upload failed
      let url = "https://source.unsplash.com/random";

      if (imageData && imageData.filename) {
        url = `http://localhost:5000/fetch-image?image=${imageData.filename}`
      }

    //   if (result && result.thumbnail && this.loader.onUpload) {
    //     this.loader.onUpload(result.thumbnail);
    //   }

      return Promise.resolve({
        default: url,
      });
    });
  }

  // Aborts the upload process.
  abort() {
    if (this.xhr) {
      this.xhr.abort();
    }
  }
}
