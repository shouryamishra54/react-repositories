import Figure from "react-bootstrap/Figure";
import Accordion from "react-bootstrap/Accordion";
import Card from "react-bootstrap/Card";
import CustomToggle from "../../shared/components/UIElements/CustomToggle";
import Button from "react-bootstrap/esm/Button";
import { Link, NavLink, Redirect } from "react-router-dom";
import UseHttp from "../../shared/hooks/use-http";
import { fetchImage } from "../../shared/libs/api";
import { useEffect, useState } from "react";

function UserItem(props){
    const [imageLink, setImageLink]=useState()
    // const [imageData, setImageData]=useState()
    const {isLoading, error, data:imageData, sendRequest: getUserImage}=UseHttp(fetchImage)
    useEffect(()=>{
        if(props.item.image){
            console.log(props.item.image)
            // const image=await fetch(`http://localhost:5000/fetch-image?image=${props.item.image}`)
            // setImageData(await image.arrayBuffer())
            getUserImage({imagePath:props.item.image})
        }
    }, [])
    function generateImage(){
        let blob=new Blob([imageData.byteArray], {
            type: "image/jpeg, image/jpg, image/png"
        })
        let link=document.createElement("a")
        link.href=window.URL.createObjectURL(blob);
        setImageLink(link.href)
        link.href.concat(".png")
        link.download=props.item.image
        window.open(link.href)
    }
    console.log(imageLink)
    return (<Card border={'light'}>
        <Card.Body>
            {(props.item.image && imageData) && <Figure>
                <Link onClick={generateImage}>
                <Figure.Image
                    style={{"borderRadius":"50%"}} thumbnail={true}
                    width={200} height={200} 
                    src={imageData.imageData} alt={props.item.name}>
                </Figure.Image>
                </Link>
                <Figure.Caption>
                    {props.item.name}
                </Figure.Caption>
            </Figure>
            }
            {props.item.places && props.item.places.length>0 &&
            <div>
                <h3>
                    {`${props.item.places.length} ${props.item.places.length === 1 ? "Place" : "Places"}`}
                </h3>
                <Button variant="primary" href={`/users/${props.item.userId}`}>
                    Go to {props.item.places.length === 1 ? "Place" : "Places"}
                </Button>
            </div>
            }
            {(!props.item.places || props.item.places.length <= 0) && 
            <h3>No Place exist for this user</h3>}
        </Card.Body>
    </Card>)
}
export default UserItem