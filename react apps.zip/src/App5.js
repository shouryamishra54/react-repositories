import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import Header from "./APIFetcher/custom/Header";
import Footer from "./APIFetcher/custom/Footer";
import ErrorBoundary from "./APIFetcher/components/ErrorBoundary";
import Tasks from "./APIFetcher/components/container/Tasks/Tasks.js";
import NewTask from "./APIFetcher/components/container/NewTask/NewTask.js";

//Use of Customized Hooks
function App(){
    const [loading, setLoading]=useState(true);
    const [error, setError]=useState();
    const [tasks, setTasks]=useState();
    async function fetchTasks(){
        try{
            setLoading(true);
            const response=await fetch("https://react-http-b2f00-default-rtdb.firebaseio.com/tasks.json");
            if(response.status === 200 || response.status === 201){
                const data=await response.json();
                const loadTasks=[];
                for(let keys in data){
                    loadTasks.push({id:keys,taskname:data[keys].text})
                }
                console.log(loadTasks)
                setTasks(loadTasks);
                setLoading(false);
            }else{
                throw new Error("Request Fetched")
            }                
        }catch(err){
            setError(err.message || 'Something Went Wrong!')
        }
    }
    useEffect(()=>{fetchTasks()},[])
    function addTaskHandler(task){
        setTasks((curState)=>curState.concat(task))
    }
    return (<div className="App">
    <div className="page-header">
        <h1>Explaination of Customized Hooks</h1>
    </div>
    <body>
        <React.Fragment>
            <div className="panel-heading">
                <Header></Header>
            </div>
            <ErrorBoundary>
                <NewTask onAddTask={addTaskHandler}></NewTask>
            </ErrorBoundary>
            <ErrorBoundary>
                <div className="panel panel-body">
                    <div>{loading && "Loading..."}</div>
                    <div>{!loading && <Tasks tasks={tasks}></Tasks>}</div>
                </div>
            </ErrorBoundary>
            <ErrorBoundary>
                <div className="panel">
                    {error && <div>{error}</div>}
                </div>
            </ErrorBoundary>
            <div className="panel-footer">
                <Footer></Footer>
            </div>
        </React.Fragment>
    </body>
</div>)
}
export default App;