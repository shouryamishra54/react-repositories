import React, { useState } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import PeopleList from "./APIFetcher/components/container/PeopleList";
import PlanetList from "./APIFetcher/components/container/PlanetList";
import MovieList from "./APIFetcher/components/container/MovieList";
import SpeciesList from "./APIFetcher/components/container/SpecieList";
import VehicleList from "./APIFetcher/components/container/VehicleList";
import StarshipList from "./APIFetcher/components/container/StarshipList";
import ErrorBoundary from "./APIFetcher/components/ErrorBoundary";
//import UserContext from "./UserFinder/Store/user-context"
//API Fetcher App

const dummy_user=[
    { id: 'u1', name: 'Max' },
    { id: 'u2', name: 'Manuel' },
    { id: 'u3', name: 'Julie' },
  ];
function App(){
    const [people, setPeople]=useState()
    const [planets, setPlanets]=useState()
    const [movies, setMovies]=useState()
    const [species, SetSpecies]=useState()
    const [vehicles, SetVehicles]=useState()
    const [starships, SetStarships]=useState()
    const [button, setButton]=useState(false)
    const [isLoading, setIsLoading]=useState(false)
    //const [button, setButton]= useState(new Array(6).map((item)=>{return false}))
    //const [isLoading, setIsLoading]= useState(new Array(6).map((item)=>{return false}))
    //const usercontext={users:dummy_user}
    async function movieButtonHandler(){
        
    }
    async function planetsButtonHandler(){

    }
    async function moviesButtonHandler(){
        //setButton((curState)=>[...curState, !curState[2]])
        //setIsLoading((curState)=>[...curState, !curState[2]])
        setButton((curState)=>!curState)
        setIsLoading(true)
        const response= await fetch("https://swapi.dev/api/films/")
        const data=await response.json()
        const transformedMovies=data.results.map((movieData)=>{
            return ({title:movieData.title,
            episodeno:movieData.episode_id,
            openingcrawl:movieData.opening_crawl,
            director:movieData.director,
            producer:movieData.producer,
            releasedate:movieData.release_date})
        })
        console.log(transformedMovies)
        setMovies(transformedMovies)
        //setIsLoading((curState)=>[...curState, !curState[2]])
        setIsLoading(false)
    }
    async function speciesButtonHandler(){

    }
    async function vehiclesButtonHandler(){

    }
    async function starshipsButtonHandler(){

    }
    return (<div className="App">
        <div className="page-header">
            <h1>API Handler</h1>
        </div>
        <body>
            <React.Fragment>
                <div>
                    <PeopleList></PeopleList>
                    <PlanetList></PlanetList>
                    <MovieList></MovieList>
                    <SpeciesList></SpeciesList>
                    <VehicleList></VehicleList>
                    <StarshipList></StarshipList>
                </div>
            </React.Fragment>
        </body>
    </div>)
}
export default App;