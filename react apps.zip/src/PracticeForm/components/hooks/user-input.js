import { useState } from "react";

function UserInput(validateInput){
    const [inputText, setInputText]=useState();
    const [inputError, setInputError]=useState(false);
    const [inputTouched, setInputTouched]=useState(false);
    const inputIsValid=validateInput(inputText) && inputTouched
    const inputChangeHandler=(event)=>{
        setInputText(event.target.value.trim())
        setInputTouched(true)
    }
    /*const inputBlurHandler=(event)=>{
        if(inputText && inputText.length>0){
            setInputError(!validateInput(inputText))
            return
        }setInputError(true)
    }*/
    const inputBlurHandler=(event)=>{
        setInputError(!validateInput(inputText))
    }
    const reset=()=>{
        setInputText('')
        setInputError(false)
    }
    return ({
        inputText,
        inputError,
        inputIsValid,
        inputChangeHandler,
        inputBlurHandler,
        reset
    })
}
export default UserInput;