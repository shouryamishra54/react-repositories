//import "./SimpleInput.module.css";
import { useEffect, useState } from "react";
import classes from "./SimpleInput.module.css";
import UserInput from "../hooks/user-input";

function SimpleInput(){
    //const [formIsValid, setFormIsValid]=useState(false)
    const{
        inputText: firstName,
        inputError: firstNameHasErr,
        inputIsValid: firstNameIsValid,
        inputChangeHandler: changeFirstNameHandler,
        inputBlurHandler: blurFirstNameHandler,
        reset: resetFirstName
    }=UserInput((value)=>value && value.trim()!=='');
    const{
        inputText: lastName,
        inputError: lastNameHasErr,
        inputIsValid: lastNameIsValid,
        inputChangeHandler: changeLastNameHandler,
        inputBlurHandler: blurLastNameHandler,
        reset: resetLastName
    }=UserInput((value)=>value && value.trim()!=='');
    const{
        inputText: emailId,
        inputError: emailIdHasErr,
        inputIsValid: emailIdIsValid,
        inputChangeHandler: changeEmailHandler,
        inputBlurHandler: blurEmailHandler,
        reset: resetEmail,
    }=UserInput((value)=>value && value.includes('@'))
    // const [firstName, setFirstName]=useState()
    // //const [firstNameIsValid, setFirstNameIsValid]=useState(false)
    // const [firstNameHasErr, setFirstNameHasErr]=useState(false)
    // const [formIsValid, setFormIsValid]=useState(false)
    // function changeNameHandler(event){
    //     setFirstName(event.target.value.trim())
    // }
    // function blurNameHandler(){
    //     if(firstName.length > 0){
    //         //setFirstNameIsValid(true)
    //         setFirstNameHasErr(false)
    //         return
    //     }//setFirstNameIsValid(false)
    //     setFirstNameHasErr(true)
    // }
    //const formIsValid=({firstNameIsValid, lastNameIsValid, emailIdIsValid, firstNameHasErr, lastNameHasErr, emailIdHasErr});
    /*useEffect(()=>{
        if(firstNameIsValid && lastNameIsValid && emailIdIsValid && firstNameHasErr && lastNameHasErr && emailIdHasErr){
            setFormIsValid(true);
        }
    }, [firstNameIsValid, lastNameIsValid, emailIdIsValid, firstNameHasErr, lastNameHasErr, emailIdHasErr])
    */
    let formIsValid;
    if((firstNameIsValid && lastNameIsValid && emailIdIsValid) ){
        formIsValid=true;
    }
    function submitHandler(event){
        event.preventDefault()
        if(!formIsValid){
            //setFirstNameHasErr(true)
            console.log("invalid Input")
            return
        }
        console.log("Hello")
        resetFirstName()
        resetLastName()
        resetEmail()
        //setFormIsValid(false)
    }
    const firstNameClass=!firstNameHasErr ? `${classes['form-control']}` : `${classes['form-control']} ${classes.invalid}`
    
    return (<form onSubmit={submitHandler} style={{"textAlign":"left"}}>
        <div className={`form-group ${classes['control-group']}`}>
            <div className={firstNameClass}>
                <label htmlFor="firstname">First Name: </label>
                <input type="text" name="firstname" id="firstname"
                onChange={changeFirstNameHandler}
                onBlur={blurFirstNameHandler}
                value={firstName}
                ></input>
                {firstNameHasErr && <p className="has-error">Please Enter the first name</p>}
            </div>
            <div className={`${classes['form-control']}`}>
                <label htmlFor="lastname">Last Name: </label>
                <input type="text" name="lastname" id="lastname"
                onChange={changeLastNameHandler}
                onBlur={blurLastNameHandler}
                value={lastName}
                ></input>
                {lastNameHasErr && <p className="has-error">Please Enter the last name</p>}
            </div>
        </div>
        <div className={`form-group ${classes['control-group']}`}>
            <div className={`${classes['form-control']}`}>
                <label htmlFor="email">Email ID: </label>
                <input type="email" name="email" id="email"
                onChange={changeEmailHandler}
                onBlur={blurEmailHandler}
                value={emailId}
                ></input>
                {emailIdHasErr && <p className="has-error">Please Enter a valid email</p>}
            </div>
        </div>
        <div className={`form-group ${classes['control-group']}`}>
            <div className={classes['form-actions']}>
                <button type="submit" disabled={!formIsValid}>Submit</button>
            </div>
        </div>
    </form>
    )
}
export default SimpleInput;