import React, { useEffect, useState } from "react";
import "./App.css";
import Home from "./components1/Home/Home.js";
import Login from "./components1/Login/Login.js";
import MainHeader from "./components1/MainHeader/MainHeader.js";

function App(){
    const [isLoggedIn, setIsLoggedIn]=useState(false);
    useEffect(()=>{
        const storedUserLoggedInInformation=localStorage.getItem('isloggedin');
        if(storedUserLoggedInInformation === '1'){
            setIsLoggedIn(true)
        }
    }, [])
    function loginHandler(){
        //if(!localStorage.getItem('isloggedin')){
            setIsLoggedIn(true)
            localStorage.setItem('isloggedin', '1')
        //}
    }
    function logoutHandler(){
        //if(localStorage.getItem('isloggedin')){
            setIsLoggedIn(false)
            localStorage.removeItem('isloggedin')
        //}
    }
    return (<div className="App">
    <React.Fragment>
        <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler}>
            <main>
                {!isLoggedIn && <Login onLogin={loginHandler}></Login>}
                {isLoggedIn && <Home></Home>}
            </main>
        </MainHeader>
    </React.Fragment>
    </div>
    );
}
export default App;