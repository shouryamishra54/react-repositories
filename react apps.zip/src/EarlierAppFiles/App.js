import React, { useContext, useEffect, useState } from "react";
import "./App.css";
import Home from "./components1/Home/Home.js";
import Login from "./components1/Login/Login.js";
import MainHeader from "./components1/MainHeader/MainHeader.js";
import AuthContext from "./Store/auth-context.js";
//import {AuthContextProvider} from "./Store/auth-context.js";
//import {AuthContextProvider} from "./Store/auth-context.js";
//Building and using a custom context provider cmp

function App(){
    /*const [isLoggedIn, setIsLoggedIn]=useState(false);
    useEffect(()=>{
        const storedUserLoggedInInformation=localStorage.getItem('isloggedin');
        if(storedUserLoggedInInformation === '1'){
            setIsLoggedIn(true)
        }
    }, [])
    function loginHandler(){
        //if(!localStorage.getItem('isloggedin')){
            setIsLoggedIn(true)
            localStorage.setItem('isloggedin', '1')
        //}
    }
    function logoutHandler(){
        //if(localStorage.getItem('isloggedin')){
            setIsLoggedIn(false)
            localStorage.removeItem('isloggedin')
        //}
    }*/
    const context=useContext(AuthContext);
    console.log(context.isLoggedIn)
    return (<div className="App">
        <header className="App-header">
            <MainHeader/>
            <React.Fragment>
                <main>
                    {!context.isLoggedIn && <Login></Login>}
                    {context.isLoggedIn && <Home></Home>}
                </main>
            </React.Fragment>
        </header>
    </div>
    );
}
export default App;