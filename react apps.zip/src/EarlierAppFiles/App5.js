import React, { useEffect, useState } from "react";
import "./App.css";
import Home from "./components1/Home/Home.js";
import Login from "./components1/Login/Login.js";
import MainHeader from "./components1/MainHeader/MainHeader.js";
import AuthContext from "./Store/auth-context";
// Making Context Dynamic

function App(){
    const [isLoggedIn, setIsLoggedIn]=useState(false);
    useEffect(()=>{
        const storedUserLoggedInInformation=localStorage.getItem('isloggedin');
        if(storedUserLoggedInInformation === '1'){
            setIsLoggedIn(true)
        }
    }, [])
    function loginHandler(){
        //if(!localStorage.getItem('isloggedin')){
            setIsLoggedIn(true)
            localStorage.setItem('isloggedin', '1')
        //}
    }
    function logoutHandler(){
        //if(localStorage.getItem('isloggedin')){
            setIsLoggedIn(false)
            localStorage.removeItem('isloggedin')
        //}
    }
    return (<div className="App">
    <React.Fragment>
        <AuthContext.Provider value={{isLoggedIn:isLoggedIn, onLogout:logoutHandler}}>
            <MainHeader>
                <main>
                    {!isLoggedIn && <Login onLogin={loginHandler}></Login>}
                    {isLoggedIn && <Home></Home>}
                </main>
            </MainHeader>
        </AuthContext.Provider>
    </React.Fragment>
    </div>
    );
}
export default App;