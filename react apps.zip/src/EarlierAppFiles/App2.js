import logo from './logo.svg';
import './App.css';
//import ExpenseItem from "./components/ExpenseItem.js";
//import ItemHeader from "./components/ItemHeader.js";
import Expenses from "./components/Expenses.js";
import NewExpense from "./components/ExpenseForm/NewExpense.js"
import { useState, Fragment } from 'react';
const dummyExpenses = [
  {
    id: Math.random().toString(),
    title: 'Toilet Paper',
    amount: 94.12,
    date: new Date(2020, 7, 14),
  },
  { id: Math.random().toString(), title: 'New TV', amount: 799.49, date: new Date(2021, 2, 12) },
  {
    id: Math.random().toString(),
    title: 'Car Insurance',
    amount: 294.67,
    date: new Date(2021, 2, 28),
  },
  {
    id: Math.random().toString(),
    title: 'New Desk (Wooden)',
    amount: 450,
    date: new Date(2021, 5, 12),
  },
];
//const items=JSON.stringify(expenses)
//var cnt=0;
//const items=Object.fromEntries(expenses)
console.log(dummyExpenses)
function App() {
  const [expenses, setExpenses]=useState(dummyExpenses);
  function addExpense(expense){
    setExpenses((prevExpenses)=>{return [...prevExpenses, expense]})
  }
  console.log(expenses)
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
      <Fragment>
      <div>
        <NewExpense onAddExpense={addExpense}></NewExpense>
      </div>
      <div>
          <h2>Let's get Started</h2>
          <p><Expenses items={expenses}></Expenses></p>
      </div>
      </Fragment>
    </div>
  );
}

export default App;
