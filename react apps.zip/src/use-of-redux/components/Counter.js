import { useState } from "react"
import {useSelector, useDispatch} from "react-redux";
import { counterActions } from "../store/index";
import ErrorBoundary from "../../APIFetcher/components/ErrorBoundary"

//Use of React-Redux
function Counter(data){
    const [error, setError]=useState(null);
    const counter=useSelector(state=>state.counter.counter);
    const showCounter=useSelector(state=>state.counter.showCounter);
    const dispatch=useDispatch();
    function incrementHandler(){
        setError(null)
        //dispatch(counterActions.increment())
        dispatch({type:'increment'})
    }
    function decrementHandler(){
        try{
            //dispatch(counterActions.decrement())
            dispatch({type:"decrement"})
        }catch(err){
            setError(err.message)
        }
    }
    function increaseHandler(){
        setError(null)
        //dispatch(counterActions.increase(10))
        dispatch({type:"increase", value:5})
    }
    function toggleHandler(){
        setError(null)
        //dispatch(counterActions.toggleCounter())
        dispatch({type:"toggleButton"})
    }
    return(<div>
        <button onClick={incrementHandler}>Increment</button>
        <button onClick={decrementHandler}>Decrement</button>
        <button onClick={increaseHandler}>Increase</button>
        <button onClick={toggleHandler}>ToggleButton</button>
        {!error && showCounter && <div><h2>{counter}</h2></div>}
        {error && <div><h2>{error}</h2></div>}
    </div>)
}

export default Counter