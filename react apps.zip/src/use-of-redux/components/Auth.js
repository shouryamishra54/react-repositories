import {useState} from "react";
import {useSelector, useDispatch} from "react-redux";

function Auth(){
    const dispatch=useDispatch();
    const login=useSelector(state=>state.authentication.login);
    function loginHandler(event){
        event.preventDefault()
        dispatch({type:"login"})
    }
    return(<main>
        <section>
        <form onSubmit={loginHandler}>
          <div>
            <label htmlFor='email'>Email</label>
            <input type='email' id='email' />
          </div>
          <div>
            <label htmlFor='password'>Password</label>
            <input type='password' id='password' />
          </div>
          <button>Login</button>
        </form>
      </section>
    </main>)
}
export default Auth;