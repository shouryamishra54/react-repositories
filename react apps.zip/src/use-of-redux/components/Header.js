import { useSelector, useDispatch } from 'react-redux';


function Header(){
  const dispatch = useDispatch();
  const isAuth = useSelector((state) => state.authentication.login);

  const logoutHandler = () => {
    dispatch({type:"logout"});
  };

  return (
    <header>
      <h1>Redux Auth</h1>
      {isAuth && (
        <nav>
          <ul>
            <li>
              <a href='/'>My Products</a>
            </li>
            <li>
              <a href='/'>My Sales</a>
            </li>
            <li>
              <button onClick={logoutHandler}>Logout</button>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}

export default Header;