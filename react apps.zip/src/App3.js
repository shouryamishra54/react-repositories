import React from "react"
import "./App.css"
import UserFinder from "./UserFinder/Components/UserFinder.js"
import UserContext from "./UserFinder/Store/user-context"
//User Finder App

const dummy_user=[
    { id: 'u1', name: 'Max' },
    { id: 'u2', name: 'Manuel' },
    { id: 'u3', name: 'Julie' },
  ];
function App(){
    const usercontext={users:dummy_user}
    return (<div className="App">
        <React.Fragment>
            <UserContext.Provider value={usercontext}>
                <UserFinder></UserFinder>
            </UserContext.Provider>
        </React.Fragment>
    </div>)
}
export default App;