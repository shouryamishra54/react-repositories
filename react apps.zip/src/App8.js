import React, { useState, useEffect } from "react"
import "./App.css"
import "./APIFetcher/styles/bootstrap.css"
import Counter from "./use-of-redux/components/Counter"
import Auth from "./use-of-redux/components/Auth"
import Header from "./use-of-redux/components/Header"
import UserProfile from "./use-of-redux/components/UserProfile"
import defautclasses from "./APIFetcher/styles/default.module.css";
import { useSelector } from "react-redux";
//import store from "./use-of-redux/store/index";

//Use of Redux State Management
function App(){
    const loggedin=useSelector(state=>state.authentication.login)
    return (<div className="App">
        <div className="page-header">
            <h1>Explaination of Redux State Management</h1>
        </div>
        <body>
            <React.Fragment>
                <div className="panel-heading">
                    <Header></Header>
                </div>
                <div className="panel-body">
                    {loggedin && <UserProfile></UserProfile>}
                    {!loggedin && <Auth></Auth>}
                </div>
                <div className={`panel-body container panel ${defautclasses['form']}`}>
                    <Counter></Counter>
                </div>
                </React.Fragment>
        </body>
    </div>)
}
export default App;