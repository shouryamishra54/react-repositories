const User = require("./../models/user");

async function getAllUsers() {
  return await User.find({});
};

async function getOneUser(id) {
  let user = await User.findById(id);
  let res = user.toObject();
  delete res.password;
  return res;
};

async function addUser(user) {
  return await User.create(user);
};

async function updateUser(user) {
  let res;
  //check if the user is updating the profile or the password
  if (user.password) {
    const foundUser = await User.findById(user._id);
    //check if the old password matches the one in the db
    if (!foundUser.validPassword(user.oldPassword)) {
      throw new Error("Incorrect old password");
    }
    //encrypt the password
    foundUser.password = foundUser.encryptPassword(user.password);
    res = await User.findByIdAndUpdate(user._id, foundUser);
  } else {
    res = await User.findByIdAndUpdate(user._id, user);
  }
  return res;
};

async function deleteUser(id) {
  return await User.findOneAndRemove({ _id: id });
};
module.exports = { getAllUsers, getOneUser, addUser, updateUser, deleteUser }