const Post = require("./../models/post");
const User = require("./../models/user");

async function getAllPosts() {
  return await Post.find({});
};

async function getOnePost(id) {
  //find post
  const post = await Post.findById(id).populate({
    path: "comments",
    populate: {
      path: "createdBy",
    },
  });

  let res;
  if (post) {
    //get the name of the creator
    const user = await User.findById(post.createdBy);
    res = {
      ...post.toObject(),
      createdByName: user.userName,
      userImageUrl: user.imagePath,
    };
  }
  return res;
};

async function getPostByUserID(userId) {
  return await Post.find({ createdBy: userId });
};

async function addPost(post) {
  //add post
  return await Post.create(post);
};

async function updatePost(post) {
  return await Post.findByIdAndUpdate(post._id, post);
};

async function deletePost(id) {
  return await Post.findOneAndRemove({ _id: id });
};
module.exports = { getAllPosts, getOnePost, getPostByUserID, addPost, updatePost, deletePost }