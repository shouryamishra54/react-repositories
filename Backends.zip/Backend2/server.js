const express = require("express");
const dotenv = require("dotenv").config();
const path = require("path");
// dotenv.config({ path: path.join(__dirname, "../.env") });
const postRoutes = require("./routes/postRoutes");
const userRoutes = require("./routes/userRoutes");
const authRoutes = require("./routes/authRoutes");
const commentRoutes = require("./routes/commentRoutes");
const cors = require("cors");
const bodyParser = require("body-parser");
const connectDB = require("./db/dbConfig");
const passport = require("passport");
const { passportMiddleware } = require("./middlewares/passport");

const app = express();

const port = process.env.PORT || 5000;

function setupServer() {
  connectDB();
  middlewares();
  app.use("/api/posts", postRoutes);
  app.use("/api/users", userRoutes);
  app.use("/api/comments", commentRoutes);
  app.use("/api/auth", authRoutes);
  // app.use(express.static(path.join(__dirname, "./../my-app/build")));
  // app.get("*", (req, res) => {
  //   res.sendFile(path.join(__dirname, "./../my-app/build", "index.html"));
  // });
}

function middlewares() {
  app.use(cors());
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: true }));
  // Passport middleware
  app.use(passport.initialize());
  passportMiddleware;
}

app.listen(port, () => {
  console.log("Server listening on port " + port);
});

setupServer();
