const mongodb=require("mongodb")
const mongoose=require("mongoose");
const fs=require("fs");
const assert = require("assert");
const url=`mongodb+srv://mycluster.nkqkk.mongodb.net/${process.env.DB_NAME}?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority`;
// const cred="./../X509-cert-2389018379024932381.pem";
const cred=process.env.DB_CRED
const client=new mongodb.MongoClient(url, {
    sslCert: cred,
    sslKey: cred
})
let bucket;
let db;
async function connectDB(callBack){
    const conn=await mongoose.connect(url, {sslCert: cred, sslKey: cred}).then(()=>{
        console.log("Connection Successful")
        db=mongoose.connections[0].db
        bucket=new mongoose.mongo.GridFSBucket(db, {
            bucketName: "uploads",
            chunkSizeBytes: 1048576
        })
        callBack()
    }).catch((err)=>{
        console.log("Error: "+err)
    })
    return {db: db, bucket: bucket}
}

module.exports=connectDB
// module.exports={connectDB, url, bucket}
