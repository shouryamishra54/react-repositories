const mongoose = require("mongoose");
const cred=process.env.DB_CRED
const url=`${process.env.DB_CONNECTION_URL}${process.env.DB_NAME}?${process.env.DB_CONNECTION_QUERY}`;
async function connectDB(callback) {
    await mongoose.connect(url, {sslCert: cred, sslKey: cred}).then(()=>{
        console.log("Connection Successful to Database: " + mongoose.connections[0].db.namespace)
        callback()
    }).catch((err)=>{
        console.log("Error: "+err)
    })
}
module.exports = connectDB