const mongoose = require('mongoose');

const EmailMsgSchema = new mongoose.Schema({
    from: { type: String, required: true },
    to: { type: String, required: true },
    cc: { type: String, required: false },
    subject: { type: String, required: true },
    message: { type: String, required: true },
    sentBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    isFlagged: { type: Boolean, default: false },
}, {
    toObject: { virtuals: true },
    toJSON: { virtuals: true },
    timestamps: true
});

const EmailMsg = mongoose.model('EmailMsg', EmailMsgSchema);

module.exports = EmailMsg;