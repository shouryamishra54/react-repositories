const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { ObjectId } = require('mongodb');
const { boolean } = require('yargs');

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  bio: { type: String },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  isPublic: { type: Boolean, default: true },
  isAdmin: { type: Boolean, default: false },
  isAdminBlocked: { type: Boolean, default: false },
  noViews: { type: Number, default: 0 },
  followRequestSend: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  followRequestReceived: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  following: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  blockedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  blockers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  profileviewers: [{ 
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    frequency: { type: Number, default: 1 } 
  }],
  profilesviewed: [{ 
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    frequency: { type: Number, default: 1 } 
  }],
  profileImage: {
    type: String,
    default: 'https://res.cloudinary.com/<your_cloud_name>/image/upload/v1634014012/default-profile-image.jpg'
  },
  contact: {
    contactNo: { type: String },
    countryCode: { type: Number },
  },
  address: {
    houseNo: { type: String },
    city: { type: String },
    state: { type: String },
    country: { type: String },
  },
  description: { type: String },
  occupation: { type: String },
  religion: { type: String },
  interests: [{ type: String }],
  active: { type: Boolean, default: true },
  posts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Post' }],
  isAccountVerified: { type: Boolean, default: false },
  accountVerificationToken: String,
  accountVerificationTokenExpires: Date,
  passwordResetToken: String,
  passwordChangeAt: Date,
  passwordResetTokenExpires: Date,
}, { 
    toObject:{ 
      virtuals: true,
      transform: function (doc, ret) {
        delete ret.passwordResetToken;
        delete ret.password;
        delete ret.accountVerificationToken;
        return ret;
      }
    }, 
    toJSON: {
      virtuals: true,
      transform: function (doc, ret) {
        delete ret.passwordResetToken;
        delete ret.password;
        delete ret.accountVerificationToken;
        return ret;
      }
    }, 
    timestamps: true 
});

UserSchema.pre('save', async function (next) {
  try {
    if (!this.isModified('password')) {
      return next();
    }
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    return next();
  } catch (err) {
    return next(err);
  }
});

UserSchema.pre('findOneAndDelete', async function (next) {
  try{
    let objtoreturn = {
      deletedSendRequests: [],
      deletedRecievedRequests: [],
      followingDeleted: [],
      followersDeleted: [],
      blockedUsersDeleted: [],
      blockerUsersDeleted: [],
      profileviewers: [],
      profilesviewed: []
    }
    if(this.followRequestSend?.length > 0){
      await this.populate("followRequestSend").then((data)=>{
        data?.followRequestSend?.map(async(user)=>{objtoreturn.deletedSendRequests.push(await user.rejectFollowRequest(this))})
      })
    }
    if(this.followRequestReceived?.length > 0){
      await this.populate("followRequestReceived").then((data)=>{
        data?.followRequestReceived?.map(async(user)=>{objtoreturn.deletedRecievedRequests.push(await this.rejectFollowRequest(user))})
      })
    }
    if(this.following?.length > 0 || this.followers?.length > 0){
      if(this.following?.length > 0) {
        await this.populate("following").then((data)=>{
          data?.following?.map(async(user)=>{objtoreturn.followingDeleted.push(await this.unFollowUser(user))})
        })
      }
      if(this.followers?.length > 0) {
        await this.populate("followers").then((data)=>{
          data?.followers?.map(async(user)=>{
            if(await user.unFollowUser(this)?.unFollowId === this.id){
              objtoreturn.followersDeleted.push({followerId: user.id})
            }
          })
        })
      }
    }
    if(blockedUsers?.length > 0 || blockers?.length > 0){
      if(blockedUsers?.length > 0) {
        await this.populate("blockedUsers").then((data)=>{
          data?.blockedUsers?.map(async(user)=>{objtoreturn.blockedUsersDeleted.push(await this.unBlockUser(user))})
        })
      }
      if(blockers?.length > 0) {
        await this.populate("blockers").then((data)=>{
          data?.blockers?.map(async(user)=>{
            if(await user.unBlockUser(this)?.unBlockedId === this.id){
              objtoreturn.blockerUsersDeleted.push({blockerId: user.id})
            }
          })
        })
      }
    }
    if(profileviewers?.length > 0 || profilesviewed?.length > 0){
      if(profileviewers?.length > 0) {
        await this.populate("profileviewers").then((data)=>{
          data?.profileviewers?.map(async(user1)=>{
            const user=user1.user
            const index1 = this.profileviewers.indexOf({user: user.id})
            this.profileviewers.splice(index1, 1)
            const index2 = user.profilesviewed.indexOf({user: this.id})
            user.profilesviewed.splice(index2, 1)
            await user.save();
            objtoreturn.profileviewers.push({viewerId: user.id})
          })
        })
      }
      if(profilesviewed?.length > 0) {
        await this.populate("profilesviewed").then((data)=>{
          data?.profilesviewed?.map(async(user1)=>{
            const user=user1.user
            const index1 = this.profilesviewed.indexOf({user: user.id})
            this.profilesviewed.splice(index1, 1)
            const index2 = user.profileviewers.indexOf({user: this.id})
            user.profileviewers.splice(index2, 1)
            await user.save();
            objtoreturn.profilesviewed.push({viewerId: user.id})
          })
        })
      }
    }
    return next() 
  }catch(err) {
    return next(err) 
  }
})

UserSchema.pre('remove', async function (next) {
  try{
    let objtoreturn = {
      deletedSendRequests: [],
      deletedRecievedRequests: [],
      followingDeleted: [],
      followersDeleted: [],
      blockedUsersDeleted: [],
      blockerUsersDeleted: [],
      profileviewers: [],
      profilesviewed: []
    }
    if(this.followRequestSend?.length > 0){
      await this.populate("followRequestSend").then((data)=>{
        data?.followRequestSend?.map(async(user)=>{objtoreturn.deletedSendRequests.push(await user.rejectFollowRequest(this))})
      })
    }
    if(this.followRequestReceived?.length > 0){
      await this.populate("followRequestReceived").then((data)=>{
        data?.followRequestReceived?.map(async(user)=>{objtoreturn.deletedRecievedRequests.push(await this.rejectFollowRequest(user))})
      })
    }
    if(this.following?.length > 0 || this.followers?.length > 0){
      if(this.following?.length > 0) {
        await this.populate("following").then((data)=>{
          data?.following?.map(async(user)=>{objtoreturn.followingDeleted.push(await this.unFollowUser(user))})
        })
      }
      if(this.followers?.length > 0) {
        await this.populate("followers").then((data)=>{
          data?.followers?.map(async(user)=>{
            if(await user.unFollowUser(this)?.unFollowId === this.id){
              objtoreturn.followersDeleted.push({followerId: user.id})
            }
          })
        })
      }
    }
    if(blockedUsers?.length > 0 || blockers?.length > 0){
      if(blockedUsers?.length > 0) {
        await this.populate("blockedUsers").then((data)=>{
          data?.blockedUsers?.map(async(user)=>{objtoreturn.blockedUsersDeleted.push(await this.unBlockUser(user))})
        })
      }
      if(blockers?.length > 0) {
        await this.populate("blockers").then((data)=>{
          data?.blockers?.map(async(user)=>{
            if(await user.unBlockUser(this)?.unBlockedId === this.id){
              objtoreturn.blockerUsersDeleted.push({blockerId: user.id})
            }
          })
        })
      }
    }
    if(profileviewers?.length > 0 || profilesviewed?.length > 0){
      if(profileviewers?.length > 0) {
        await this.populate("profileviewers").then((data)=>{
          data?.profileviewers?.map(async(user1)=>{
            const user=user1.user
            const index1 = this.profileviewers.indexOf({user: user.id})
            this.profileviewers.splice(index1, 1)
            const index2 = user.profilesviewed.indexOf({user: this.id})
            user.profilesviewed.splice(index2, 1)
            await user.save();
            objtoreturn.profileviewers.push({viewerId: user.id})
          })
        })
      }
      if(profilesviewed?.length > 0) {
        await this.populate("profilesviewed").then((data)=>{
          data?.profilesviewed?.map(async(user1)=>{
            const user=user1.user
            const index1 = this.profilesviewed.indexOf({user: user.id})
            this.profilesviewed.splice(index1, 1)
            const index2 = user.profileviewers.indexOf({user: this.id})
            user.profileviewers.splice(index2, 1)
            await user.save();
            objtoreturn.profilesviewed.push({viewerId: user.id})
          })
        })
      }
    }
    return next() 
  }catch(err) {
    return next(err) 
  }
})

UserSchema.methods.comparePassword = async function (password) {
  try {
    return await bcrypt.compare(password, this.password);
  } catch (err) {
    throw new Error(err);
  }
};

UserSchema.methods.generateAccountVerificationToken = async function () {
    try {
        const verificationToken = crypto.randomBytes(32).toString('hex');
        this.accountVerificationToken = crypto.createHash('sha256').update(verificationToken).digest('hex')
        this.accountVerificationTokenExpires = Date.now() + 10*60*1000; // 10 minutes
        return verificationToken;
    } catch (err) {
        throw new Error(err);
    }
}

UserSchema.methods.generatePasswordResetToken = async function () {
    try {
        const passwordResetToken = crypto.randomBytes(32).toString('hex');
        this.passwordResetToken = crypto.createHash('sha256').update(passwordResetToken).digest('hex')
        this.passwordResetTokenExpires = Date.now() + 10*60*1000; // 10 minutes
        return passwordResetToken
    } catch (err) {
        throw new Error(err);
    }
}

UserSchema.methods.profileViewedByUser = async function (user) {
  try {
    if(!user || !user.active || !user.isAccountVerified || user.isAdminBlocked) {
      return;
    }else{
      // console.log(this.profileviewers.findIndex(data => data.user == user.id))
      if(!this.profileviewers.find(data => data.user == user.id)) {
        // console.log("1")
        this.profileviewers.push({user: user.id})
      }else {
        // console.log("2")
        const index = this.profileviewers.findIndex(data => data.user == user.id)
        let frequency = this.profileviewers[index].frequency;
        this.profileviewers[index] = {user: user.id, frequency: ++frequency}
      }
      // console.log("middle")
      if(!user.profilesviewed.find(data => data.user == this.id)) {
        // console.log("3")
        user.profilesviewed.push({user: this.id})
      }else {
        // console.log("4")
        const index = user.profilesviewed.findIndex(data => data.user == this.id);
        let frequency = user.profilesviewed[index].frequency;
        user.profilesviewed[index] = {user: this.id, frequency: ++frequency};
      }
      await user.save();
    }
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.getNoOfFollowing = async function () {
  let noOfFollowing = 0;
  await this.populate("following").then((data)=>{
    noOfFollowing=data?.following.filter(user => user.active && !user.isAdminBlocked).length;
  });
  return noOfFollowing;
}

UserSchema.methods.getNoOfFollowers = async function () {
  let noOfFollowers = 0;
  await this.populate("followers").then((data)=>{
    noOfFollowers=data?.followers.filter(user => user.active && !user.isAdminBlocked).length;
  });
  return noOfFollowers;
}

UserSchema.methods.getNoOfProfileViewers = async function () {
  return this.profileviewers?.length || 0
}

UserSchema.methods.getNoOfViews = async function () {
  let noOfViews = 0;
  if(this.profileviewers?.length > 0){
    this.profileviewers.map((user) => {noOfViews += user.frequency})
  }
  return noOfViews;
}

UserSchema.methods.getNoOfViewsForUser = async function(user1) {
  let noOfViews = 0;
  if(this.profileviewers?.length > 0){
    noOfViews = this.profileviewers.filter(user => user.user === user1.id)?.[0].frequency || noOfViews;
  }
  return noOfViews;
}

UserSchema.methods.getViewsPerUser = async function () {
  let objtoreturn = []
  if(this.profileviewers?.length > 0){
    await this.populate({
      path: "profileviewers",
      populate: {
        path: "user"
      }
    }).then((data) => {
      data.profileviewers.map((data1) => {
        objtoreturn.push({
          user: data1.user,
          noOfViews: data1.frequency
        })
      })
    })
  }
  return objtoreturn;
}

UserSchema.methods.getNoOfProfilesViewed = async function () {
  let frequency = 0;
  await this.populate("profilesviewed").then((data)=>{
    frequency=data?.profilesviewed.filter(user => user.user && user.user.active && !user.user.isAdminBlocked).length;
  });
  return frequency;
}

UserSchema.methods.getNoOfVisitsForUser = async function (user) {
  let frequency = 0;
  console.log(user.id)
  frequency = this.profilesviewed.find(data => data.user == user.id)?.frequency || frequency
  return frequency;
}

UserSchema.methods.isFollowingUser = async function (user) {
  let following = false;
  if(user && user.active && !user.isAdminBlocked && user.isAccountVerified){
    following = this.following?.includes(user.id)
    if(following && !user.followers?.includes(this.id)){
      user.followers.push(this.id);
      await user.save();
    }
    if(!following && user.followers?.includes(this.id)){
      this.following.push(user.id);
      following=true
    }
  }
  return following;
}

UserSchema.methods.isFollowedByUser = async function (user) {
  let followed = false;
  if(user && user.active && !user.isAdminBlocked && user.isAccountVerified){
    followed = this.followers?.includes(user.id)
    if(followed && !user.following?.includes(this.id)){
      user.following.push(this.id);
      await user.save();
    }
    if(!followed && user.following?.includes(this.id)){
      this.followers.push(user.id);
      followed=true
    }
  }
  return followed;
}

UserSchema.methods.isUserBlocked = async function (user) {
  let blocked = false;
  if(user && user.active && !user.isAdminBlocked && user.isAccountVerified){
    blocked = this.blockedUsers?.includes(user.id)
    if(blocked && !user.blockers?.includes(this.id)){
      user.blockers.push(this.id);
      await user.save();
    }
    if(!blocked && user.blockers?.includes(this.id)){
      this.blockedUsers.push(user.id);
      blocked=true
    }
  }
  return blocked;
}

UserSchema.methods.isBlockedByUser = async function (user) {
  let blocked = false;
  if(user && user.active && !user.isAdminBlocked && user.isAccountVerified){
    blocked = this.blockers?.includes(user.id)
    if(blocked && !user.blockedUsers?.includes(this.id)){
      user.blockedUsers.push(this.id);
      await user.save();
    }
    if(!blocked && user.blockedUsers?.includes(this.id)){
      this.blockers.push(user.id);
      blocked=true
    }
  }
  return blocked;
}

UserSchema.methods.ViewUserProfile = async function (user) {
  const index1 = this.users?.profilesviewed.indexOf({user: user.id}) || -1
  if(!this.profilesviewed || index1 < 0){
    this.profilesviewed.push({user: user.id, frequency: 1});
  }else{
    this.profilesviewed[index1] = {
      ...this.profilesviewed[index1], noOfViews: ++this.profilesviewed[index1].frequency
    }
  }
  const index2 = user.profileviewers.indexOf({user: this.id}) || -1
  if(!user.profileviewers || index2 < 0){
    user.profileviewers.push({user: this.id, frequency: 1})
  }else{
    user.profileviewers[index2] = {
      ...user.profileviewers[index2], frequency: ++user.profileviewers[index2].frequency
    }
  }
  await user.save();
}

UserSchema.methods.requestSentIfPrivate = async function (user) {
  let requestSent = false;
  if(user && user.active && !user.isAdminBlocked && user.isAccountVerified){
    await this.populate("followRequestSend").then((data) => {
      requestSent = this.followRequestSend.includes(user.id)
      data.followRequestSend.map(async (user) => {
        if(requestSent && !user.followRequestReceived.includes(this.id)){
          user.followRequestReceived.push(this.id);
          await user.save();
        }
        if(!requestSent && user.followRequestReceived.includes(this.id)){
          this.followRequestSend.push(user.id);
          requestSent=true
        }
      })
    })
  }
  return requestSent;
}

UserSchema.methods.blockUser = async function (user) {
  let objtoreturn, fl=0;
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if(this.followers.includes(user.id) || this.following.includes(user.id)){
      const index1 = this.followers.indexOf(user.id)
      const index2 = this.following.indexOf(user.id)
      const index3 = user.followers.indexOf(this.id)
      const index4 = user.following.indexOf(this.id)
      if(index1 >= 0){
        this.followers.splice(index1, 1);
      }if(index2 >= 0){
        this.following.splice(index2, 1);
      }if(index3 >= 0){
        user.followers.splice(index3, 1); fl=1;
      }if(index4 >= 0){
        user.following.splice(index4, 1); fl=1;
      }
    }
    if(this.blockedUsers.includes(user.id) || user.blockers.includes(this.id)){
      if (!this.blockedUsers.includes(user.id)) {
        this.blockedUsers.push(user.id)
      }if(!user.blockers.includes(this.id)) {
        user.blockers.push(this.id);
        await user.save();
      }
      return ({
        message: "You have already blocked this user",
        statusCode: 400
      })
    }
    if(this.followRequestReceived.includes(user.id) || this.followRequestSend.includes(user.id)){
      const index1 = this.followRequestSend.indexOf(user.id)
      const index2 = this.followRequestReceived.indexOf(user.id)
      const index3 = user.followRequestSend.indexOf(this.id)
      const index4 = user.followRequestReceived.indexOf(this.id)
      if(index1 >= 0){
        this.followRequestSend.splice(index1, 1);
      }if(index2 >= 0){
        this.followRequestReceived.splice(index2, 1);
      }if(index3 >= 0){
        user.followRequestSend.splice(index3, 1); fl=1;
      }if(index4 >= 0){
        user.followRequestReceived.splice(index4, 1); fl=1;
      }
    }
    this.blockedUsers.push(user.id)
    if(!user.blockers.includes(this.id)){
      user.blockers.push(this.id); fl=1;
    }
    if(fl === 1){
      await user.save();
    }
    const noOfFollowing = this.getNoOfFollowing();
    const noOfFollowers = this.getNoOfFollowers();
    return {...objtoreturn, blockedId: user.id, noOfFollowing: noOfFollowing, noOfFollowers: noOfFollowers}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.unBlockUser = async function (user) {
  let objtoreturn
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if(!this.blockedUsers.includes(user.id)){
      const index = user.blockers.indexOf(this.id)
      if(index >= 0){
        user.blockers.splice(index, 1);
        await user.save();
      }
      return ({
        message: "You haven't blocked this user",
        statusCode: 400
      })
    }
    const index1 = this.blockedUsers.indexOf(user.id);
    const index2 = user.blockers.indexOf(this.id);
    if(index1 >= 0){
      this.blockedUsers.splice(index1, 1);
    }if(index2 >= 0){
      user.blockers.splice(index2, 1);
      await user.save();  
    }
    const noOfFollowing = this.getNoOfFollowing();
    const noOfFollowers = this.getNoOfFollowers();
    return {unBlockedId: user.id, noOfFollowing: noOfFollowing, noOfFollowers: noOfFollowers}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.followUser = async function (user) {
  let objtoreturn
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if(this.blockedUsers.includes(user.id)){
      return ({ message: "You have blocked this user, please unblock to follow", statusCode: 400 });
    }
    if (this.following.includes(user.id)) {
      return ({ message: 'You are already following this user', statusCode: 400 });
    }
    this.following.push(user.id);
    // this.noFollowing++;
    console.log("You are following " + user.name)
    user.followers.push(this.id);
    // user.noFollowers++;
    await user.save();
    const noOfFollowing = this.getNoOfFollowing();
    return {...objtoreturn, followingId: user.id, userFollowed: true, noOfFollowing: noOfFollowing}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.unFollowUser = async function (user) {
  let objtoreturn
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if (!this.following.includes(user.id)) {
      return ({ message: 'You are not following this user', statusCode: 400 });
    }
    if(this.blockedUsers.includes(user.id)){
      return ({ message: "You have already blocked this user, no need to unfollow", statusCode: 400 });
    }
    const followingIndex=this.following.indexOf(user.id);
    this.following.splice(followingIndex, 1);
    // this.noFollowing--;
    const followersIndex=user.followers.indexOf(this.id);
    user.followers.splice(followersIndex, 1);
    // user.noFollowers--;
    await user.save();
    const noOfFollowers = this.getNoOfFollowers();
    return {...objtoreturn, unFollowId: user.id, userUnfollowed: true, noOfFollowers: noOfFollowers}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.sendFollowRequest = async function (user) {
  let objtoreturn
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if(this.blockedUsers.includes(user.id)){
      return ({ message: "You have blocked this user, please unblock to follow", statusCode: 400 });
    }
    if (this.following.includes(user.id)) {
      return ({ message: 'You are already following this user', statusCode: 400 });
    }
    if (this.followRequestSend.includes(user.id)) {
      return ({message: 'Follow Request Sent already', statusCode: 400})
    }
    this.followRequestSend.push(user.id);
    if (!user.followRequestReceived.includes(user.id)) {
      user.followRequestReceived.push(this.id);
      await user.save();
    }
    const noOfFollowing = this.getNoOfFollowing();
    return {followRequestUserId: user.id, followRequestSend: true, noOfFollowing: noOfFollowing, 
    message: "Follow Request Sent"}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.cancelFollowRequest = async function (user) {
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified || !this.followRequestSend.includes(user.id)) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    const index1 = this.followRequestSend.indexOf(user.id)
    const index2 = user.followRequestReceived.indexOf(this.id)
    if(index1 >= 0 ) {
      this.followRequestSend.splice(index1, 1);
    }if(index2 >= 0 ) {
      user.followRequestReceived.splice(index2, 1);      
      await user.save();
    }
    const noOfFollowing = this.getNoOfFollowing();
    return {followRequestUserId: user.id, followRequestCancelled: true, noOfFollowing: noOfFollowing,
    message: "Follow Request cancelled"}  
  }catch (err) {
    throw new Error(err)
  }
}

UserSchema.methods.acceptFollowRequest = async function (user) {
  let objtoreturn
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified || !this.followRequestReceived.includes(user.id)) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if (this.blockedUsers.includes(user.id)){
      return ({ message: "You have blocked this user, please unblock to accept request", statusCode: 400 });
    }
    if (this.followers.includes(user.id)) {
      return ({ message: 'You are already followed by this user', statusCode: 400 });
    }
    const followerDetails = await user.followUser(this)
    console.log(followerDetails)
    const userFollowing = await followerDetails?.userFollowed === true
    if(!userFollowing || userFollowing === false || followerDetails.followingId !== this.id){
      return ({ message: 'Something went wrong, unable to acceptRequest', statusCode: 500 });
    }
    const index1 = this.followRequestReceived.indexOf(user.id)
    const index2 = user.followRequestSend.indexOf(this.id)
    if(index1 >= 0){
      this.followRequestReceived.splice(index1, 1);
    }if(index2 >= 0){
      user.followRequestSend.splice(index2, 1);
      await user.save();
    }
    const noOfFollowers = this.getNoOfFollowers();
    return {followRequestUserId: user.id, followRequestAccepted: userFollowing, noOfFollowers: noOfFollowers, 
    message: "Follow Request Accepted"}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.rejectFollowRequest = async function (user) {
  let objtoreturn
  try{
    if (!user || !user.active || user.isAdminBlocked || !user.isAccountVerified || !this.followRequestReceived.includes(user.id)) {
      return ({ message: 'User not found', statusCode: 400 });
    }
    if(this.blockedUsers.includes(user.id)){
      return ({ message: "You have blocked this user, please unblock to follow", statusCode: 400 });
    }
    if (this.followers.includes(user.id)) {
      return ({ message: 'You are already followed by this user', statusCode: 400 });
    }
    const index1 = this.followRequestReceived.indexOf(user.id)
    const index2 = user.followRequestSend.indexOf(this.id)
    if(index1 >= 0){
      this.followRequestReceived.splice(index1, 1);
    }if(index2 >= 0){
      user.followRequestSend.splice(index2, 1);
      await user.save();
    }
    const noOfFollowers = this.getNoOfFollowers();
    return {followRequestUserId: user.id, followRequestRejected: true, noOfFollowers: noOfFollowers, 
    message: "Follow Request Rejected"}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.deactivateUser = async function (user) {
  if(!user || !user.isAccountVerified) {
    return ({ message: 'User not found', statusCode: 400 });
  }
  if(!user.active || user.isAdminBlocked) {
    return ({message: 'User is already inactive or blocked', status: 400})
  }
  try{
    user.active = false;
    await user.save();
    if(!user.active){
      objtoreturn = { 
        message: "User inactivated successfully", statusCode: 200 
      };
    }
    return {...objtoreturn, deactivatedUserId: user.id}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.activateUser = async function (user) {
  if(!user || !user.isAccountVerified) {
    return ({ message: 'User not found', statusCode: 400 });
  }
  if(user && user.active) {
    return ({ message: 'User is already active', statusCode: 400 });
  }
  if(user.isAdminBlocked) {
    return ({message: 'User is blocked, please unblock to activate user', status: 400})
  }
  try{
    user.active = true;
    await user.save();
    if(user.active){
      objtoreturn = { 
        message: "User activated successfully", statusCode: 200 
      };
    }
    return {...objtoreturn, activatedUserId: user.id}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.adminBlockUser = async function (user) {
  if(!user) {
    return ({ message: 'User not found', statusCode: 400 });
  }
  if(!user.active || user.isAdminBlocked) {
    return ({message: 'User is already inactive or blocked', status: 400})
  }
  try{
    user.isAdminBlocked = true;
    await user.save();
    if(user.isAdminBlocked){
      objtoreturn = { message: "User admin blocked successfully", statusCode: 200 };
    }
    return {...objtoreturn, adminBlockUserId: user.id}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.adminUnblockUser = async function (user) {
  if(!user) {
    return ({ message: 'User not found', statusCode: 400 });
  }
  if(user && !user.isAdminBlocked) {
    return ({ message: 'User is already unblocked', statusCode: 400 });
  }
  if(!user.active) {
    return ({message: 'User is inactive state, please activate to unblock the user', status: 400})
  }
  try{
    user.isAdminBlocked = false;
    await user.save();
    if(!user.isAdminBlocked){
      objtoreturn = { message: "User unblocked successfully", statusCode: 200 };
    }
    return {...objtoreturn, adminUnblockUserId: user.id}
  } catch(err) {
    throw new Error(err)
  }
}

UserSchema.methods.setProfilePublic = async function () {
  let objtoreturn
  if(this.isPublic === true){
    objtoreturn={message: 'User is already public', status: 400}
  }else{
    this.isPublic = true;
    if(this.isPublic === true){
      objtoreturn={message: 'Profile is set as public'}
    }else{
      objtoreturn={message: 'Unable to set this Profile public, Internal server error', status: 400}
    }
  }
  return objtoreturn;
}

UserSchema.methods.setProfilePrivate = async function () {
  let objtoreturn
  if(this.isPublic === false){
    objtoreturn={message: 'User is already private', status: 400}
  }else{
    this.isPublic = false;
    if(this.isPublic === false){
      objtoreturn={message: 'Profile is set as private'}
    }else{
      objtoreturn={message: 'Unable to set this Profile private, Internal server error', status: 400}
    }
  }
  return objtoreturn;
}

const User = mongoose.model('User', UserSchema);

module.exports = User;