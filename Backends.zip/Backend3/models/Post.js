const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
  langcode: { type: String, enum: ['en', 'hi'], default: 'en' },
  isPublic: { type: Boolean, default: true },
  isAdminBlocked: { type: Boolean, default: false },
  views: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }],
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }],
  dislikes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }],
  createdAt: { type: Date, default: Date.now },
  lastModifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  images: [{ type: String }]
}, { 
    toObject: { virtuals: true }, 
    toJSON: { virtuals: true}, 
    timestamps: true 
});


const Post = mongoose.model('Post', PostSchema);

module.exports = Post;