const mongoose = require("mongoose");
const validateId = require("../utils/validateId");

const CategorySchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    parent: { type: mongoose.Schema.Types.ObjectId, ref: "Category" },
  },
  {
    toObject: {virtuals: true}, 
    toJSON: {virtuals: true}, 
    timestamps: true 
  }
);

/*
CategorySchema.pre("save", async function (next) {
  try {
    if(this.parent){
      const id=this.parent;
      validateId(id);
      var parent = await Category.findById(id);
      if(parent && !parent?.children?.includes(this.id)){
        parent.children.push(this.id);
        await parent.save();
      }  
    }
    next();  
  } catch(err) {
    return next(err);
  }
})
*/

CategorySchema.pre("remove", async function (next) {
  const category = this;
  // Delete child categories recursively
  async function deleteChildren(categoryId) {
    const children = await Category.find({ parent: categoryId }).exec();
    for (const child of children) {
      await child.remove();
      await deleteChildren(child._id);
    }
  }
  await deleteChildren(category._id);
  next();
});

const Category = mongoose.model("Category", CategorySchema);

module.exports = Category;