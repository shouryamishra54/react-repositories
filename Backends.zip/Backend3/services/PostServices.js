const Post = require("../models/Post");
const User = require("../models/User");

exports.getPostsByParameters = async (user=null, author=null, parameters, callback) => {
    const { limit, page, skip, category, sort, filters } = parameters;
    let categoryFilter = await Category.findOne({ title: category })?.id;
    categoryFilter = categoryFilter ? {category: categoryFilter} : undefined
    console.log(categoryFilter)
    let filter = {
        ...filters,
        ...categoryFilter,
        // isPublic: true, // filter only public posts
        // 'author.isPublic': true // filter out posts with private author accounts
    };
    let posts = await Post.find(filter)
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit + parseInt(skip))
    .limit(limit)
    .populate('author', 'name email followers blockedUsers isPublic', ) // populate author with name and email fields
    .populate({
      path: 'likes',
      select: 'name email followers following',
      options: { sort: { followers: -1 } } // sort users in decreasing order of followers
    }).populate({
      path: 'category',
      select: 'title'
    });
  
    const totalPosts = await Post.countDocuments(filters);
    const totalPages = Math.ceil(totalPosts / limit);
    if(req.user){
      validateId(req.user.id)
      console.log(req.user.name)
      if(req.user.isAdmin){
        //do nothing get all user posts as it is
      }else {
        let privateUserIds = []
        const privateUsers = await User.find({isPublic: false}).then((data) => {
          data.map((user) => {privateUserIds.push(user.id)})
        })
        filter = {
          ...categoryFilter,
          $or: [
            { isPublic: true, author: { $nin: privateUserIds } }, // Include public posts
            { author: req.user.id }, // Include private posts of the logged-in user
            { author: { $in: privateUserIds, $in: req.user.following } }, // Include all posts (public/private) is authors followed by users
            // { isPublic: false, author: { $in: req.user.following } }, // Include private posts of the users being followed by the logged-in user
          ],
          author: { $nin: [req.user.blockers, req.user.blockedUsers] }, // Exclude posts from authors blocked by the logged-in user
          // author: { $nin: req.user.blockers, $nin: req.user.blockedUsers }, // Exclude posts from authors blocked by the logged-in user
          // category: categoryFilter ? categoryFilter._id : undefined || { $exists: true }, // Include posts with the specified category or any category if not provided
        };
      }
      posts = await Post.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .populate('author', 'name email followers blockedUsers isPublic') // populate author with name and email fields
      .populate({
        path: 'likes',
        select: 'name email followers following',
        options: { sort: { followers: -1 } } // sort users in decreasing order of followers
      });
    }else{
      filter = {...filter, isPublic: true}
      let privatePosts=posts.filter(post => !post.author.isPublic);
      posts = posts.filter(post => !privatePosts.includes(post));
    }
    res.json({
      success: true,
      message: 'Posts fetched successfully',
      data: posts,
      page,
      totalPages,
      totalPosts,
    });
}