const express = require('express');
const expressValidator = require('express-validator');
const auth = require('../middlewares/auth');
const optionalAuth = require('../middlewares/optionalAuth');
const { getPostById, getAllPosts, updatePost, createPost, deletePost, likePost, dislikePost, getUsersLikedPost, getUsersDislikedPost, getPostAnalytics, getUserPostAnalytics, makePrivate, makePublic, getAllPostsAnalytics, getPostsByUser } = require('../controllers/PostController');
const admin = require('../middlewares/admin');
const router = express.Router();

router.get('/', optionalAuth, getPostsByUser);
router.get('/:id', getPostById);
router.post('/new', auth, createPost);
router.put('/:id', auth, updatePost);
router.delete('/:id', auth, deletePost);
router.get('/user-posts/:id/', getPostsByUser);
router.put('/:id/like', auth, likePost);
router.put('/:id/dislike', auth, dislikePost);
router.get('/:id/like', auth, getUsersLikedPost);
router.get('/:id/dislike', auth, getUsersDislikedPost);
router.get('/:id/analytics', auth, getPostAnalytics);
router.get('/:id/user-posts-analytics', auth, getUserPostAnalytics);
router.get('/all-posts-analytics', auth, admin, getAllPostsAnalytics);
router.put('/:id/make-private', auth, makePrivate);
router.put('/:id/make-public', auth, makePublic);

module.exports = router