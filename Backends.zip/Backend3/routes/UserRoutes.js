const express = require('express');
const expressValidator = require('express-validator');
const { getUserProfileController, userRegisterController, userLoginController, verifyAccountController, changePasswordController, forgetPasswordController, followUserController, unfollowUserController, blockUserController, unblockUserController, setUserProfilePublicController, setUserProfilePrivateController, updateMyProfileController, updateUserProfileController, deleteMyProfileController, deleteUserProfileController, resetPasswordController, cancelFollowRequestController, acceptFollowRequestController, rejectFollowRequestController } = require('../controllers/UserControllers');
const auth = require('../middlewares/auth');
const router = express.Router()

router.get('/profile', getUserProfileController)
router.get('/profile/:username', getUserProfileController)
router.post('/register', userRegisterController);
router.post('/login', userLoginController);
router.get('/verify/:token', auth, verifyAccountController);
router.put('/changepassword', auth, changePasswordController);
router.post('/forgetpassword', forgetPasswordController);
router.put('/resetpassword/:passwordToken', resetPasswordController);
router.put('/follow', auth, followUserController);
router.put('/unfollow', auth, unfollowUserController);
router.put('/cancel-follow-request', auth, cancelFollowRequestController);
router.put('/accept-follow-request', auth, acceptFollowRequestController);
router.put('/reject-follow-request', auth, rejectFollowRequestController);
router.put('/block', auth, blockUserController);
router.put('/unblock', auth, unblockUserController);
router.put('/public', auth, setUserProfilePublicController);
router.put('/private', auth, setUserProfilePrivateController);
router.put('/me', auth, updateMyProfileController);
router.put('/:id', auth, updateUserProfileController);
router.delete('/me', auth, deleteMyProfileController);
router.delete('/:id', auth, deleteUserProfileController);

module.exports = router