const express = require('express');
const expressValidator = require('express-validator');
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');
const { addCategory, getCategoryById, getCategoriesByParentCategory, updateCategory, deleteCategory, getCategoriesByKeyword, getCategoryByChildCategory, getAllAncestors, getAllSuccessors } = require('../controllers/CategoryController');
const router = express.Router()

router.get('/', getCategoriesByKeyword)
router.get('/:id', getCategoryById)
router.get('/:id/get-ancestors', getAllAncestors);
router.get('/:id/get-successors', getAllSuccessors);
router.get('/:id/get-children', getCategoriesByParentCategory)
router.get('/:id/get-parent', getCategoryByChildCategory)
router.post('/new', auth, admin, addCategory)
router.put('/:id', auth, admin, updateCategory)
router.delete('/:id', auth, admin, deleteCategory)

module.exports = router;