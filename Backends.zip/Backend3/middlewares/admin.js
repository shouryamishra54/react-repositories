const admin = (req, res, next) => {
    if(req.user.role === 'admin' || req.user.isAdmin === true) {
        next();
    } else {
        res.sendStatus(403).json({message: 'You are not authorized to do this action'});
    }
}
module.exports = admin;