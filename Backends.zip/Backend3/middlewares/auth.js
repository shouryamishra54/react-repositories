const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req, res, next) => {
    let token;
    if(req?.headers?.authorization?.startsWith('Bearer ')){
        token = req.headers.authorization.split(" ")[1];
        if(token){
            try{
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                if(decoded){
                    let user = await User.findById(decoded?.id).catch((err) => {
                        res.status(401)
                        return next(new Error("User doesn't exist"))
                    });
                    if(user){
                        user = await User.findById(decoded?.id).select("-password")
                        req.user = user
                        res.setHeader('Authorization', req.headers.authorization);
                        next();
                    }
                }else{
                    res.status(401)
                    return next(new Error("Invalid Token"));
                }
            }catch(err){
                res.status(401)
                return next(new Error("Authentication failed: "));
            }
        }else{
            res.status(401)
            return next(new Error("Authentication Token not found"));
        }
    }else{
        res.status(401)
        return next(new Error("Authentication Token not attached to the request"));
    }
};

module.exports = auth;