function errorHandler(err, req, res, next){
    console.log("error 1")
    const statusCode = res.statusCode || 500
    res.status(statusCode).json({
        message : statusCode === 500 ? "Server Error" : err?.message,
        stack : process.env.NODE_ENV === "PRODUCTION" ? null : err?.stack
    })
}
function notFound(req, res, next){
    console.log("error 2")
    const error = new Error("Requested Resource Not Found.")
    const statusCode = res.statusCode || 404
    res.status(statusCode)
    next(error)
}
module.exports = { errorHandler, notFound }