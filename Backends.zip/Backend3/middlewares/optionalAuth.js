const jwt = require('jsonwebtoken');
const User = require('../models/User');

const optionalAuth = async (req, res, next) => {
    let token;
    try{
        if(req?.headers?.authorization?.startsWith('Bearer ')){
            token = req.headers.authorization.split(" ")[1];
            if(token){
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                if(decoded){
                    let user = await User.findById(decoded?.id).catch((err) => {
                        res.status(401)
                        throw new Error("User doesn't exist")
                    });
                    if(user){
                        user = await User.findById(decoded?.id).select("-password")
                        req.user = user
                        res.setHeader('Authorization', req.headers.authorization);
                    }
                }
            }
        }
        next();
    }
    catch(err){
        res.status(401)
        return next(new Error("Authentication failed: "));
    }
};

module.exports = optionalAuth;