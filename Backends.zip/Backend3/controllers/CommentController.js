const Comment = require('../models/Comment');
const User = require('../models/User');

// add a new comment
exports.addComment = async (req, res) => {
  const { postId, parentId, content } = req.body;
  const userId = req.user.id;
  const parent = parentId ? {parent: parentId} : undefined;
  try {
    const newComment = await Comment.create({
      userId,
      postId,
      ...parent,
      content
    });
    
    res.status(201).json(newComment);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Unable to add comment' });
  }
}

// GET /posts/:postId/comments
exports.getCommentsForPost = async (req, res, next) => {
  try {
    const postId = req.params.postId;
    const comments = await Comment.find({ post: postId })?.populate('author', 'name username followers following');

    res.status(200).json({
      message: 'Comments fetched successfully',
      comments: comments.map(comment => comment.toObject())
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: err });
  }
};

// Fetch a single comment and populate the user who made the comment
exports.getCommentById = (req, res, next) => {
  Comment.findById(req.params.commentId)
    .populate('author', 'username name') // Populate the user field with only the username and email fields
    .exec((err, comment) => {
      if (err) {
        return res.status(400).json({
          error: 'Comment not found',
        });
      }
      req.comment = comment;
      next();
    });
};

// Delete a comment
exports.deleteComment = async (req, res) => {
  try {
    const { id } = req.params;
    const comment = await Comment.findById(id);

    if (!comment) {
      return res.status(404).json({ msg: 'Comment not found' });
    }

    // Check if the user is authorized to delete the comment
    if (comment.user.toString() !== req.user.id || req.user.isAdmin) {
      return res.status(401).json({ msg: 'User not authorized' });
    }

    await comment.remove();

    res.json({ msg: 'Comment deleted' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// Edit a comment
exports.editComment = async (req, res) => {
  try {
    const { id } = req.params;
    const { text } = req.body;
    const comment = await Comment.findById(id);

    if (!comment) {
      return res.status(404).json({ msg: 'Comment not found' });
    }

    // Check if the user is authorized to edit the comment
    if (comment.user.toString() !== req.user.id) {
      return res.status(401).json({ msg: 'User not authorized' });
    }

    comment.content = text;

    await comment.save();

    res.json(comment);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};