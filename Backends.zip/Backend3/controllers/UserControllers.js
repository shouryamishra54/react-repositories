const express = require('express');
const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const User = require('../models/User');
const auth = require('../middlewares/auth');
const admin = require('../middlewares/admin');
const expressAsyncHandler = require('express-async-handler');

// Register a new user
// const router = express.Router();
const sgMail = require('@sendgrid/mail');
const nodemailer = require('nodemailer');
const generateToken = require('../utils/generateToken');
const UserValidator = require('../validators/UserValidator');
const validateId = require('../utils/validateId');
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const getUserProfileController = expressAsyncHandler(async (req, res, next) => {
  try{
    // let arr = ["shourya": {
    //   "height": "180 cm",
    //   "weight": "95 Kg"
    // }, "mishra": {
    //   "height": "188 cm",
    //   "weight": "90 Kg"
    // }]
    const {username}=req.params;
    const {id} = req.query;
    let user;
    const usertofind = await User.findById(id) || await User.findOne({username: username})
    let objtoreturn
    let token = req.headers?.authorization?.startsWith('Bearer ') ? req.headers.authorization.split(" ")[1] : undefined;
    if(token){
      const decoded = jwt.decode(token, process.env.JWT_SECRET);
      if(decoded?.id){
        validateId(decoded?.id);
        user = await User.findById(decoded?.id).select("-password")
        res.setHeader('Authorization', req.headers.authorization);
      }
    }
    if(!user || !user?.role !== 'admin'){
      if(!usertofind || !usertofind.active || !usertofind.isAccountVerified || usertofind.isAdminBlocked){
        return res.status(400).json({accountExists: false, message: "User Account not found"})
      }
      if(user && await user.isBlockedByUser(usertofind)){
        await user.save();
        return res.status(400).json({accountExists: true, message: "You are blocked"})  
      }
    }
    let flag=0;
    if(user){
      if(user.id === usertofind?.id || user.role === 'admin'){
        objtoreturn = {
          user: usertofind.toObject(),
          noOfFollowers: await usertofind.getNoOfFollowers(),
          noOfFollowing: await usertofind.getNoOfFollowing(),
          noOfviews: await usertofind.getNoOfViews(),
          noOfProfileViewers: await usertofind.getNoOfProfileViewers(),
          noOfViewsPerPerson: await usertofind.getViewsPerUser(),
          noOfUserProfilesVisited: await usertofind.getNoOfProfilesViewed()
        }
      }
      else if(!usertofind?.isPublic && !usertofind?.isFollowedByUser(user)){
        flag=0;
        objtoreturn = {
          isProfilePublic: false, 
          isFollowingThisUser: user.isFollowingUser(usertofind),
          isFollowedByThisUser: user.isFollowedByUser(usertofind),
          message: "User Profile is private, only followers can view user profiles."
        }
      }else{
        flag=1;
        objtoreturn = {
          isProfilePublic: usertofind.isPublic,
          user: usertofind.toObject(), 
          noOfTimesProfileVisited: await user.getNoOfVisitsForUser(usertofind),
          isFollowingThisUser: await user.isFollowingUser(usertofind),
          isFollowedByThisUser: await user.isFollowedByUser(usertofind),
          isUserBlocked: await user.isUserBlocked(usertofind),
          noOfFollowers: await usertofind.getNoOfFollowers(),
          noOfFollowing: await usertofind.getNoOfFollowing()
        }
      }
      if(flag === 1) {
        await usertofind.profileViewedByUser(user);
      }
      await usertofind.save();
      await user.save();
    }else{
      if(!usertofind?.isPublic){
        objtoreturn = {
          isProfilePublic: false, 
          message: "User Profile is private, only followers can view user profiles."
        }
      }else{
        objtoreturn = {
          isProfilePublic: usertofind.isPublic,
          user: usertofind.toObject(), 
          noOfFollowers: await usertofind.getNoOfFollowers(),
          noOfFollowing: await usertofind.getNoOfFollowing()
        }
      }
    }
    res.json(objtoreturn)
  } catch(err){
    console.error(err.message);
    res.status(500).send('Server Error');    
  }
})

// User authentication
const userLoginController = expressAsyncHandler(async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email })
    if (!user) {
      res.status(401)
      return next(new Error("Invalid Credentials"));
      // return res.status(401).json({ msg: 'Invalid Credentials' });
    }
    const isMatch = await user.comparePassword(password);
    // const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      res.status(401)
      return next(new Error("Invalid Credentials"))
      // return res.status(401).json({ msg: 'Invalid Credentials' });
    }
    const payload = {
      user: {
        id: user.id,
      },
    };
    const token = generateToken({ id: user.id, username: user.username, role: user.role })
    res.setHeader('Authorization', token);
    let objtoreturn;
    if(!user.isAccountVerified){
      if(user.accountVerificationTokenExpires >= Date.now()){
        objtoreturn={
          verifylinkisvalid: user.accountVerificationTokenExpires >= Date.now(),
          message: "Please verify your account. Click the account verification link send on your mail",
        }
      }else{
        let accountVerificationToken = await user.generateAccountVerificationToken()
        await user.save()
        const resetURL = `If you were requested to verify your account, verify now within 10 minutes, otherwise ignore this message <a href="http://localhost:3000/verify-account/${accountVerificationToken}">Click to verify your account</a>`;
        const msg = {
          to: user.email,
          from: "shouryamishra54@gmail.com",
          subject: "Verify your account",
          text: resetURL,
        };
  
        await sgMail.send(msg, (err, info) => {
          if(err) {
            console.log(err)
            res.status(402)
            return next(err)
          }else{
            console.log(info)
            successmsg="Account created, Verification mail sent."
          }
        });
        objtoreturn = {accverificationtoken: accountVerificationToken}
      }
    }
    res.json({
      ...objtoreturn,
      token: token,
      user: user.toObject()
    })
  } catch (err) {
    console.error(err.message);
    throw new Error(err);
    res.status(500).send('Server Error');
  }
})

// User account verification
const userRegisterController = expressAsyncHandler(async (req, res, next) => {
  const { name, username, email, password, bio, contact, address, description, 
    religion, interests } = req.body;
  try {
    let user = await User.findOne({ email });
    if (user) {
      res.status(400)
      return next(new Error("User already exists"));
    }
    user = new User({
      name, username, email, password, bio, contact, address, 
      description, religion, interests, isVerified: false
    });
    //Checking Validity of Data
    const dataError=UserValidator(user)
    if(dataError){
      res.status(404)
      return next(new Error(dataError))
    }
    let successmsg="Account created but mail not send."
    // const salt = await bcrypt.genSalt(10);
    // user.password = await bcrypt.hash(password, salt);
    await user.save();
    const payload = {
      user: {
        id: user.id,
      },
    };
    const token = generateToken({ id: user.id, username: user.username, role: user.role })
    let accountVerificationToken
    if(token){
      accountVerificationToken = await user.generateAccountVerificationToken()
      await user.save()
      const resetURL = `If you were requested to verify your account, verify now within 10 minutes, otherwise ignore this message <a href="http://localhost:3000/verify-account/${accountVerificationToken}">Click to verify your account</a>`;
      const msg = {
        to: user.email,
        from: "shouryamishra54@gmail.com",
        subject: "Verify your account",
        text: resetURL,
      };

      await sgMail.send(msg, (err, info) => {
        if(err) {
          console.log(err)
          res.status(402)
          return next(err)
        }else{
          console.log(info)
          successmsg="Account created, Verification mail sent."
        }
      });
    }
    res.json({
      authtoken: generateToken({ id: user.id, username: username, role: user.role }), 
      accverificationtoken: accountVerificationToken,
      message: successmsg
    })
  } catch (err) {
    console.log(err)
    throw new Error(err);
  }
})

// Verify account
const verifyAccountController = expressAsyncHandler(async (req, res, next) => {
  try {
    const hashedToken = crypto.createHash('sha256').update(req.params.token).digest('hex');
    const userFound = await User.findOne({
      accountVerificationToken: hashedToken,
      accountVerificationTokenExpires: {$gt: Date.now()},
    })
    if (!userFound || !userFound.id) {
      res.status(400)
      return next(new Error("Invalid Token"))
    }
    userFound.isAccountVerified = true;
    userFound.accountVerificationToken = undefined;
    userFound.accountVerificationTokenExpires = undefined;
    await userFound.save();
    res.setHeader('Authorization', req.headers.authorization);
    res.json({user: userFound.toObject(), token: req.headers.authorization.split(" ")[1]})
    // res.redirect('http://localhost:3000/login');
  } catch (err){
   throw new Error(err)
   res.status(500).send('Server Error');
  }
})

// Change Password
const changePasswordController = expressAsyncHandler(async (req, res, next) => {
  const { email, oldPassword, newPassword } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      res.status(400)
      return next(new Error("User not found"))
    }
    const isMatch = ((req.user.id === user.id) && await user.comparePassword(oldPassword));
    if (!isMatch) {
      res.status(401)
      return next(new Error("Invalid password"));
    }
    if(await user.comparePassword(newPassword)){
      res.status(400)
      return next(new Error("New Password must be different from the last 3 passwords"))
    }
    user.password = newPassword
    await user.save();
    res.status(200).json({ message: 'Password changed successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
})

// Forget Password
const forgetPasswordController = expressAsyncHandler(async (req, res, next) => {
  const { email } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      res.status(400)
      return next("User not found");
    }
    const token = await user.generatePasswordResetToken();
    let successmsg  
    await user.save()
    const resetURL = `If you were requested to verify your account, verify now within 10 minutes, otherwise ignore this message <a href="http://localhost:3000/verify-account/${token}">Click to verify your account</a>`;
    const msg = {
      to: user.email,
      from: "shouryamishra54@gmail.com",
      subject: "Reset your password",
      text: resetURL,
    };

    await sgMail.send(msg, (err, info) => {
      if(err) {
        res.status(402)
        return next(err)
      }else{
        successmsg="Account created, Verification mail sent."
      }
    });
    res.json({
      token: token,
      passwordToken: successmsg
    })
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Reset your password
const resetPasswordController = expressAsyncHandler(async (req, res, next) => {
  try{
    const hashedToken = crypto.createHash('sha256').update(req.params.passwordToken).digest('hex');
    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: {$gt: Date.now()},
    })
    if(!user) {
      res.status(400).send("Password Token Expired")
    }
    const { password, confirmPassword } = req.body;
    if(confirmPassword !== password) {
      res.status(400).send("Confirm Password must be the same as Password");
    }
    user.password = confirmPassword
    user.passwordResetToken = undefined;
    user.passwordResetTokenExpires = undefined;
    user.passwordChangeAt = Date();
    await user.save();
    res.json({ user: user.toObject(), msg: "Password reset successful." });
  } catch(err) { 
    throw new Error(err);
  }
})

// Follow a User
const followUserController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { followingId } = req.body;
  try {
    const userToFollow = await User.findById(followingId);
    let followingDetail;
    if(userToFollow?.active && !userToFollow.isPublic){
      followingDetail = await user.sendFollowRequest(userToFollow)
    }else{
      followingDetail=await user.followUser(userToFollow);
    }
    await user.save();
    res.status(await followingDetail?.statusCode || 200).json({ 
      message: await followingDetail?.message || 'User followed successfully.'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Cancel sent follow request
const cancelFollowRequestController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { followingId } = req.body;
  try {
    const userToFollow = await User.findById(followingId);
    const cancelRequestDetail = await user.cancelFollowRequest(userToFollow);
    await user.save();
    res.status(await cancelRequestDetail?.statusCode || 200).json({ 
      message: await cancelRequestDetail?.message || 'Follow Request Cancelled Successfully.'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Accept received follow request
const acceptFollowRequestController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { followerId } = req.body;
  try {
    const follower = await User.findById(followerId);
    const acceptRequestDetail = await user.acceptFollowRequest(follower);
    await user.save();
    res.status(await acceptRequestDetail?.statusCode || 200).json({ 
      message: await acceptRequestDetail?.message || 'Follow Request Accepted Successfully.'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Reject received follow request
const rejectFollowRequestController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { followerId } = req.body;
  try {
    const rejectedFollower = await User.findById(followerId);
    const rejectRequestDetail = await user.rejectFollowRequest(rejectedFollower);
    await user.save();
    res.status(await rejectRequestDetail?.statusCode || 200).json({ 
      message: await rejectRequestDetail?.message || 'Follow Request Rejected Successfully.'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Unfollow a User
const unfollowUserController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { followingId } = req.body;
  try {
    const following = await User.findById(followingId);
    const followingDetail=await user.unFollowUser(following)
    await user.save();
    res.status(await followingDetail?.statusCode || 200).json({ 
      message: await followingDetail?.message || 'User unfollowed successfully.'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Block a User
const blockUserController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { blockedId } = req.body;
  try {
    const blocked = await User.findById(blockedId);
    const blockedUserDetail=await user.blockUser(blocked);
    await user.save();
    res.status(await blockedUserDetail?.statusCode || 200).json({ 
      message: await blockedUserDetail?.message || 'User blocked successfully'
    });
  } catch (err) {
    console.error(err);
    res.status(500).send(err.message);
  }
});

// Unblock a User
const unblockUserController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user
  const { blockedId } = req.body;
  try {
    const blocked = await User.findById(blockedId);
    const blockedUserDetail=await user.unBlockUser(blocked);
    await user.save();
    res.status(await blockedUserDetail?.statusCode || 200).json({ 
      message: await blockedUserDetail?.message || 'User unblocked successfully'
    });
  } catch (err) {
    console.error(err);
    res.status(500).send(err.message);
  }
});

// Set profile as Public
const setUserProfilePublicController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user;
  try {
    // const user = await User.findById(userId);
    // if (!user) {
    //   return res.status(400).json({ message: 'User not found' });
    // }
    const publicmessage = await user.setProfilePublic();
    await user.save();
    res.status(await publicmessage?.statusCode || 200).json({ 
      message: await publicmessage?.message || 'User Profile is set Public successfully'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Set profile as Private
const setUserProfilePrivateController = expressAsyncHandler (async (req, res, next) => {
  const user = req.user;
  try {
    // const user = await User.findById(userId);
    // if (!user) {
    //   return res.status(400).json({ message: 'User not found' });
    // }
    const privatemessage = await user.setProfilePrivate();
    await user.save();
    res.status(await privatemessage?.statusCode || 200).json({ 
      message: await privatemessage?.message || 'User Profile is set Private successfully'
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Update my profile
const updateMyProfileController = expressAsyncHandler (async (req, res, next) => {
  const fields = { name, email, bio, contact, address, description, 
    religion, interests } = req.body;
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }
    Object.keys(fields).map((p)=>{user[p]=updatedUser[p]})
    // user.name = name || user.name;
    // user.email = email || user.email;
    // user.bio = bio || user.bio;
    await user.save();
    res.status(200).json({ message: 'Profile updated successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Update a user profile (applicable only for admin users)
const updateUserProfileController = expressAsyncHandler (async (req, res, next) => {
  const fields = { name, email, bio, contact, address, description, 
    religion, interests } = req.body;
  const { id } = req.params;
  try {
    const user = await User.findById(id);
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }
    Object.keys(fields).map((p)=>{user[p]=updatedUser[p]})
    // user.name = name || user.name;
    // user.email = email || user.email;
    // user.bio = bio || user.bio;
    await user.save();
    res.status(200).json({ message: 'Profile updated successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Delete my profile
const deleteMyProfileController = expressAsyncHandler (async (req, res, next) => {
  try {
    await User.findByIdAndDelete(req.user.id);
    res.status(200).json({ message: 'Profile deleted successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// Delete a user profile (applicable only for admin users)
const deleteUserProfileController = expressAsyncHandler (async (req, res, next) => {
  const { id } = req.params;
  try {
    await User.findByIdAndDelete(id);
    res.status(200).json({ message: 'Profile deleted successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});


module.exports = {
  getUserProfileController, userRegisterController,  userLoginController,  verifyAccountController,  changePasswordController,  forgetPasswordController, resetPasswordController,  followUserController,  unfollowUserController,  blockUserController,  unblockUserController,  setUserProfilePublicController,  setUserProfilePrivateController,  updateMyProfileController,  updateUserProfileController,  deleteMyProfileController,  deleteUserProfileController, cancelFollowRequestController, acceptFollowRequestController, rejectFollowRequestController
}