const { ObjectId } = require('mongodb');
const Category = require('../models/Category');
const User = require('../models/User');
const validateId = require('../utils/validateId');

// add a new Category
exports.addCategory = async (req, res, next) => {
  const { title, parentCategoryID } = req.body;
  const userId = req.user.id;
  const parent = parentCategoryID ? await Category.findById(parentCategoryID) ? {parent: parentCategoryID} : undefined : undefined;
  try {
    const categories = await Category.find({
        title: { $regex: title.trim(), $options: 'i' }, ...parent
    });
    if(categories && categories !== null && categories.length > 0) {
        console.log(categories)
        res.status(200).json({
            success: false,
            message: "The Category with the given title is found",
            categories: categories?.map((category) => category.toObject()),
        });
    } else {
        const newCategory = await Category.create({
        user: userId,
        title: title.trim(),
        ...parent,
    });

    res.status(201).json(newCategory.toObject());      
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Unable to create Category' });
  }
}

// GET /Category/:categoryId
exports.getCategoryById = async (req, res, next) => {
    const { id } = req.params;
    validateId(id);
    try {
        let objtoreturn={};
        if(id) { validateId(id); }
        const category = await Category.findById(id)?.populate('user', 'username name role')
        if(category && category !== null) {
            objtoreturn.success = true
            objtoreturn.category = category
        } else {
            objtoreturn.success = false
            objtoreturn.message = 'Category not found'
        }
        res.status(200).json(objtoreturn);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: err });
    }
};

// Fetch categories by keyword in title
exports.getCategoriesByKeyword = async (req, res) => {
    const { keyword } = req.query;
    // const keywordWithoutSpaces = keyword.replace(/\s/g, '');
    filter = (keyword?.trim() && keyword.trim() !== null) ? {title: {$regex: keyword.trim(), $options: 'i'}} : undefined;
    console.log(keyword)
    try {
        let objtoreturn = {}
        const categories = await Category.find({...filter})?.populate('user', 'username name role')
        objtoreturn.success = true;
        objtoreturn.categories = categories;
        if(categories && categories.length === 0){
            objtoreturn.success = false;
            objtoreturn.message = 'Category/Categories not found';
        }
        res.status(200).json(objtoreturn);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
};

// Fetch a single Category and populate the user who made the Category
exports.getCategoryByChildCategory = (req, res, next) => {
    if(req.params.id){
      validateId(req.params.id);
      Category.findById(req.params.id).exec((err, category) => {
        if (err) {
          return res.status(400).json({
              success: false,
              error: 'Child Category not found',
          });
        } else {
          Category.findById(category.parent)
          .populate('user', 'username name role') // Populate the user field with only the username and email fields
          .populate('parent', 'user title parent') // Populate the parents
          .exec((err1, category1) => {
            if(err1 || (category1 === undefined || category1 === null)) {
              return res.status(200).json({
                success : false,
                error: 'This category is a root category with no parent',
              })
            } else {
              return res.status(200).json({
                success: true,
                parent: category1
              })
            }
          })
        }
      })
    } else {
        res.status(404).json({
            success: false,
            error: "Please Enter a valid Child Category"
        })
    }
};

// Fetch a single Category and populate the user who made the Category
exports.getCategoriesByParentCategory = (req, res, next) => {
    const { id } = req.params;
    if(req.params.id){
      validateId(id)
      Category.find({parent: ObjectId(id)})
      .populate('user', 'username name role') // Populate the user field with only the username and email fields
      .exec((err, categories) => {
        if (err || (categories?.length === 0)) {
          return res.status(400).json({
              success: false,
              error: 'Category not found',
          });
        }
        res.status(200).json({
          success: true,
          children: categories
        });
        // next();
      });    
    } else {
        res.status(404).json({
            success: false,
            error: "Please Enter a valid Parent Category"
        })
    }
};

// Delete a Category
exports.deleteCategory = async (req, res, next) => {
  try {
    const { id } = req.params;
    const category = await Category.findById(id);

    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    // Check if the user is authorized to delete the Category
    if (category.user.toString() !== req.user.id || !req.user.isAdmin) {
      return res.status(401).json({ message: 'User not authorized' });
    }

    await category.remove();

    res.json({ success: true, message: 'Category deleted' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// Edit a Category
exports.updateCategory = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title } = req.body;
    const category = await Category.findById(id);

    if (!category) {
      return res.status(404).json({ message: 'Category not found' });
    }

    // Check if the user is authorized to edit the Category
    if (category.user.toString() !== req.user.id  || !req.user.isAdmin) {
      return res.status(401).json({ success: false, message: 'User not authorized' });
    }

    category.title = title;

    await category.save();

    res.json({ success: true, caregory: category.toObject() });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// Controller function to get the ancestors of a category
exports.getAllAncestors = async (req, res, next) => {
  try {
    const categoryId = req.params.id;
    // Recursively find the ancestors of the category
    const findCategoryAncestors = async (categoryId, ancestors = []) => {
      const category = await Category.findById(categoryId).exec();
      if (!category) {
        return ancestors;
      }

      const parentCategory = await Category.findById(category.parent).exec();
      if (!parentCategory) {
        // If there is no parent, this category is the root category
        ancestors.unshift(category);
        return ancestors;
      }

      ancestors.unshift(category);
      return findCategoryAncestors(parentCategory._id, ancestors);
    };

    // Call the recursive function to get the ancestors
    const ancestors = await findCategoryAncestors(categoryId);
    let category = {};
    if (ancestors.length > 0) {
      const buildHierarchy = (ancestors, index) => {
        const currentCategory = ancestors[index];
        if (index < ancestors.length - 1) {
          // currentCategory.children = buildHierarchy(ancestors, index + 1);
          return {
            ...currentCategory.toObject(),
            children: buildHierarchy(ancestors, index + 1)
          }
        }
        return currentCategory;
      };

      category = buildHierarchy(ancestors, 0);
    }

    res.status(200).json({ ancestors: ancestors, category: category });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching ancestors' });
  }
};

// Controller function to get the category hierarchy with children
exports.getAllSuccessors = async (req, res, next) => {
  try {
    const categoryId = req.params.id;

    // Recursively find the category hierarchy
    const findCategoryHierarchy = async (categoryId) => {
      const category = await Category.findById(categoryId).exec();
      if (!category) {
        return null;
      }

      const children = await Category.find({ parent: category._id }).exec();
      const categoryWithChildren = { ...category.toObject(), children: [] };

      for (const child of children) {
        const childCategory = await findCategoryHierarchy(child._id);
        categoryWithChildren.children.push(childCategory);
      }

      return categoryWithChildren;
    };

    // Call the recursive function to get the category hierarchy
    const categoryHierarchy = await findCategoryHierarchy(categoryId);

    res.status(200).json({ categoryHierarchy });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching the category hierarchy' });
  }
};
