//========================================================================================================================================================
											//POST Controller API
//========================================================================================================================================================

const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const User = require('../models/User');
const Category = require('../models/Category');
const { ObjectId } = require('mongodb');
const validateId = require('../utils/validateId');

// Create a post
exports.createPost = async (req, res, next) => {
  try {
    if (req.user) {
      if(req.user.active && req.user.isAccountVerified && !req.user.isAdminBlocked){
        validateId(req.body.categoryID);
        Category.findById(req.body.categoryID).exec((err, category) => {
          if(err || (category === undefined || category === null)) {
            res.status(400).json({ success: false, message: 'No such category is found. Please enter a valid category.'})
          } else {
            Post.create({
              title: req.body.title,
              category: category.id,
              content: req.body.content,
              author: req.user.id
            }).exec((err, post) => {
              if(err || (post === undefined || post === null)) {
                res.status(500).json({ success: false, message: 'Unable to create post. Internal server error...'})
              } else {
                res.json({ success: true, data: post.toObject() });
              }
            })
          }
        })
      } else {
        res.status(403).json({ success: false, message: 'You are not allowed to add any post'})
      }
    } else {
      res.status(401).json({ success: false, message: 'Please Login/SignUp to add any post'})
    }
  } catch (err) {
    next(err);
  }
};

// Get all posts
exports.getAllPostsWithoutSort = async (req, res, next) => {
  try {
    // Get the page, limit, skip, and category values from the query parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    const category = req.query.category || '';

    // Get all posts matching the given category
    const posts = await Post.find({ category })
      .sort({ createdAt: 'desc' })
      .limit(limit)
      .skip(skip)
      .populate('author', 'name email');

    // Get the total count of posts matching the given category
    const count = await Post.countDocuments({ category });

    res.status(200).json({
      status: 'success',
      data: {
        posts,
        page,
        limit,
        skip,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    next(error);
  }
};

// Get all posts sorted in decreasing order of their likes and filter according to categories, limit and pages
exports.getAllPosts = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10; // default limit is 10
    const skip = parseInt(req.query.skip) || 0; // default skip is 0
    const category = req.query.category || ''; // default category is ''
    const sort = req.query.sort || '-likes'; // default sort is -likes (decreasing order of likes)

    let categoryFilter = await Category.findOne({ title: category })?.id;
    categoryFilter = categoryFilter ? {category: categoryFilter} : undefined
    console.log(categoryFilter)
    let filter = {
        ...categoryFilter,
        // isPublic: true, // filter only public posts
        // 'author.isPublic': true // filter out posts with private author accounts
    };
    let posts = await Post.find(filter)
    .sort(sort)
    .skip(skip*limit)
    .limit(limit)
    .populate('author', 'name email followers blockedUsers isPublic', ) // populate author with name and email fields
    .populate({
      path: 'likes',
      select: 'name email followers following',
      options: { sort: { followers: -1 } } // sort users in decreasing order of followers
    }).populate({
      path: 'category',
      select: 'title'
    });

    /*const filter = {
        category: categoryFilter ? categoryFilter._id : undefined,
        $or: [
          { isPublic: true }, // Include public posts
          { 'author.followers': userId } // Include private posts for the logged-in user who follows the author
        ],
        $nor: [
          { 'author.blockedUsers': userId }, // Exclude posts by authors who blocked the logged-in user
          { blockedUsers: userId } // Exclude posts blocked by the logged-in user
        ]
    };*/
    if(req.user){
      validateId(req.user.id)
      console.log(req.user.name)
      if(req.user.isAdmin){
          filter = {...categoryFilter, 
            // category: categoryFilter ? categoryFilter._id : undefined
          }
      }else {
        let privateUserIds = []
        const privateUsers = await User.find({isPublic: false}).then((data) => {
          data.map((user) => {privateUserIds.push(user.id)})
        })
        filter = {
          ...categoryFilter,
          $or: [
            { isPublic: true, author: { $nin: privateUserIds } }, // Include public posts
            { author: req.user.id }, // Include private posts of the logged-in user
            { author: { $in: privateUserIds, $in: req.user.following } }, // Include all posts (public/private) is authors followed by users
            // { isPublic: false, author: { $in: req.user.following } }, // Include private posts of the users being followed by the logged-in user
          ],
          author: { $nin: [req.user.blockers, req.user.blockedUsers] }, // Exclude posts from authors blocked by the logged-in user
          // author: { $nin: req.user.blockers, $nin: req.user.blockedUsers }, // Exclude posts from authors blocked by the logged-in user
          // category: categoryFilter ? categoryFilter._id : undefined || { $exists: true }, // Include posts with the specified category or any category if not provided
        };
      }
      posts = await Post.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .populate('author', 'name email followers blockedUsers isPublic') // populate author with name and email fields
      .populate({
        path: 'likes',
        select: 'name email followers following',
        options: { sort: { followers: -1 } } // sort users in decreasing order of followers
      });
    }else{
      filter = {...filter, isPublic: true}
      let privatePosts=posts.filter(post => !post.author.isPublic);
      posts = posts.filter(post => !privatePosts.includes(post));
    }
    return res.status(200).json({ success: true, data: posts.map(post => post.toObject()) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// Get all user posts according to decreasing order of creation
exports.getPostsByUserNewestFirst = async (req, res) => {
  const { userId } = req.params;
  // const { limit = 10, page = 1, skip = 0, category = '' } = req.query;
  const validLimit = [5, 10, 20, 50, 100]
  const limit = validLimit.includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 10; // default limit is 10
  const page = parseInt(req.query.page) >= 1 ? parseInt(req.query.page) : 1; // default limit is 1
  const skip = parseInt(req.query.skip) >= 0 ? parseInt(req.query.skip) : 0; // default skip is 0
  const category = req.query.category || ''; // default category is ''
  const filters = { author: userId };
  try{
    let categoryFilter = await Category.findOne({ title: category })?.id;
    categoryFilter = categoryFilter ? {category: categoryFilter} : undefined
    console.log(categoryFilter)
    let filter = {
      author: userId,
        ...categoryFilter,
        // isPublic: true, // filter only public posts
        // 'author.isPublic': true // filter out posts with private author accounts
    };
    let posts = await Post.find(filter)
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit + parseInt(skip))
    .limit(limit)
    .populate('author', 'name email followers blockedUsers isPublic', ) // populate author with name and email fields
    .populate({
      path: 'likes',
      select: 'name email followers following',
      options: { sort: { followers: -1 } } // sort users in decreasing order of followers
    }).populate({
      path: 'category',
      select: 'title'
    });
  
    const totalPosts = await Post.countDocuments(filters);
    const totalPages = Math.ceil(totalPosts / limit);
    if(req.user){
      validateId(req.user.id)
      console.log(req.user.name)
      if(req.user.isAdmin){
        //do nothing get all user posts as it is
      }else {
        let privateUserIds = []
        const privateUsers = await User.find({isPublic: false}).then((data) => {
          data.map((user) => {privateUserIds.push(user.id)})
        })
        filter = {
          ...categoryFilter,
          $or: [
            { isPublic: true, author: { $nin: privateUserIds } }, // Include public posts
            { author: req.user.id }, // Include private posts of the logged-in user
            { author: { $in: privateUserIds, $in: req.user.following } }, // Include all posts (public/private) is authors followed by users
            // { isPublic: false, author: { $in: req.user.following } }, // Include private posts of the users being followed by the logged-in user
          ],
          author: { $nin: [req.user.blockers, req.user.blockedUsers] }, // Exclude posts from authors blocked by the logged-in user
          // author: { $nin: req.user.blockers, $nin: req.user.blockedUsers }, // Exclude posts from authors blocked by the logged-in user
          // category: categoryFilter ? categoryFilter._id : undefined || { $exists: true }, // Include posts with the specified category or any category if not provided
        };
      }
      posts = await Post.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .populate('author', 'name email followers blockedUsers isPublic') // populate author with name and email fields
      .populate({
        path: 'likes',
        select: 'name email followers following',
        options: { sort: { followers: -1 } } // sort users in decreasing order of followers
      });
    }else{
      filter = {...filter, isPublic: true}
      let privatePosts=posts.filter(post => !post.author.isPublic);
      posts = posts.filter(post => !privatePosts.includes(post));
    }
    res.json({
      success: true,
      message: 'Posts fetched successfully',
      data: posts,
      page,
      totalPages,
      totalPosts,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });    
  }
};

// Get all user posts sorted in decreasing order of their likes and filter according to categories, limit and filter
exports.getPostsByUser = async (req, res) => {
  const userId = req.params.userId;
  // const { limit, page, skip, category } = req.query;
  const validLimit = [5, 10, 20, 50, 100]
  const limit = validLimit.includes(parseInt(req.query.limit)) ? parseInt(req.query.limit) : 10; // default limit is 10
  const page = parseInt(req.query.page) >= 1 ? parseInt(req.query.page) : 1; // default limit is 1
  const skip = parseInt(req.query.skip) >= 0 ? parseInt(req.query.skip) : 0; // default skip is 0
  const category = req.query.category || ''; // default category is ''
  const filters = { author: userId };
  try{
    let categoryFilter = await Category.findOne({ title: category })?.id;
    categoryFilter = categoryFilter ? {category: categoryFilter} : undefined
    console.log(categoryFilter)
    let filter = {
      author: userId,
        ...categoryFilter,
        // isPublic: true, // filter only public posts
        // 'author.isPublic': true // filter out posts with private author accounts
    };
  
    let posts = await Post.find(filter)
    .sort({ likes: -1 })
    .skip((page - 1) * limit + parseInt(skip))
    .limit(limit)
    .populate('author', 'name email followers blockedUsers isPublic', ) // populate author with name and email fields
    .populate({
      path: 'likes',
      select: 'name email followers following',
      options: { sort: { followers: -1 } } // sort users in decreasing order of followers
    }).populate({
      path: 'category',
      select: 'title'
    });
  
    const totalPosts = await Post.countDocuments(filters);
    const totalPages = Math.ceil(totalPosts / limit);
  
    if(req.user){
      validateId(req.user.id)
      console.log(req.user.name)
      if(req.user.isAdmin){
        //do nothing get all user posts as it is
      }else {
        let privateUserIds = []
        const privateUsers = await User.find({isPublic: false}).then((data) => {
          data.map((user) => {privateUserIds.push(user.id)})
        })
        filter = {
          ...categoryFilter,
          $or: [
            { isPublic: true, author: { $nin: privateUserIds } }, // Include public posts
            { author: req.user.id }, // Include private posts of the logged-in user
            { author: { $in: privateUserIds, $in: req.user.following } }, // Include all posts (public/private) is authors followed by users
            // { isPublic: false, author: { $in: req.user.following } }, // Include private posts of the users being followed by the logged-in user
          ],
          author: { $nin: [req.user.blockers, req.user.blockedUsers] }, // Exclude posts from authors blocked by the logged-in user
          // author: { $nin: req.user.blockers, $nin: req.user.blockedUsers }, // Exclude posts from authors blocked by the logged-in user
          // category: categoryFilter ? categoryFilter._id : undefined || { $exists: true }, // Include posts with the specified category or any category if not provided
        };
      }
      posts = await Post.find(filter)
      .sort({ likes: -1 })
      .skip(skip)
      .limit(limit)
      .populate('author', 'name email followers blockedUsers isPublic') // populate author with name and email fields
      .populate({
        path: 'likes',
        select: 'name email followers following',
        options: { sort: { followers: -1 } } // sort users in decreasing order of followers
      });
    }else{
      filter = {...filter, isPublic: true}
      let privatePosts=posts.filter(post => !post.author.isPublic);
      posts = posts.filter(post => !privatePosts.includes(post));
    }
    res.json({
      success: true,
      message: 'Posts fetched successfully',
      data: {
        posts,
        page,
        totalPosts,
        totalPages,
      },
    });  
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

// Get a post by ID
exports.getPostById = async (req, res, next) => {
  try {
    validateId(req.params.id)
    const post = await Post.findById(req.params.id)
    .populate('author', 'name email followers blockedUsers isPublic', ) // populate author with name and email fields
    const publicUser = await post.author.isPublic
    const publicPost = post.isPublic
    let objtoreturn
    if (req.user) {
      validateId (req.user.id)
      const following = req.user.isFollowing(await User.findById(post.author.id)) ? true : false
      const isBlocked = req.user.isBlockedUser(await User.findById(post.author.id)) ? true : false
      if(isBlocked === true) {
        post = null
      } else {
        if ((!publicUser || !publicPost) && following === false) {
          post = null
        }
      }
      objtoreturn = {
        success: (post && post !== null),
        post: (post && post !== null) ? post.toObject() : undefined, 
        publicPost, publicUser, following, isBlocked
      }
    } else {
      if (!publicUser || !publicPost) {
        post = null
      }
      objtoreturn = {
        success: (post && post !== null),
        post: (post && post !== null) ? post.toObject() : undefined, 
        publicPost, publicUser
      }
    }
    if (!objtoreturn.success) {
      return res.status(404).json({ success: false, message: 'Post not found' });
    }
    res.json(objtoreturn);
  } catch (err) {
    next(err);
  }
};

// Update a post
exports.updatePost = async (req, res, next) => {
  try {
    if (req.user) {
      if(req.user.active && req.user.isAccountVerified && !req.user.isAdminBlocked){
        let post = await Post.findById(req.params.id);
        if (!post) {
          return res.status(404).json({ success: false, message: 'Post not found' });
        }
        if (post.author.toString() !== req.user.id && req.user.role !== 'admin') {
          return res.status(403).json({ success: false, message: 'You are not authorized to update this post' });
        }
        post.title = req.body.title || post.title;
        post.content = req.body.content || post.content;
        post.category = req.body.category ? await Category.find({ title: req.body.category })?.id : post.category;
        post = await post.save();
        res.status(200).json({ success: true, data: post.toObject() });
      } else {
        res.status(403).json({ success: false, message: 'You are not allowed to update this post'})
      }  
    } else {
      res.status(401).json({ success: false, message: 'Please Login/SignUp to update this post'})
    }
  } catch (err) {
    next(err);
  }
};

// Delete a post
exports.deletePost = async (req, res, next) => {
  try {
    if (req.user) {
      if(req.user.active && req.user.isAccountVerified && !req.user.isAdminBlocked){
        const post = await Post.findById(req.params.id);
        if (!post) {
          return res.status(404).json({ success: false, message: 'Post not found' });
        }
        if (post.author.toString() !== req.user.id && req.user.role !== 'admin') {
          return res.status(403).json({ success: false, message: 'You are not authorized to delete this post' });
        }
        await post.remove();    
        res.status(200).json({ success: true, message: 'Post deleted successfully' });
      } else {
        res.status(403).json({ success: false, message: 'You are not allowed to delete this post'})
      }
    } else {
      res.status(401).json({ success: false, message: 'Please Login/SignUp to delete this post'})
    }
  } catch (err) {
    next(err);
  }
};

//Liking a Post
exports.likePost = async (req, res) => {
  try {
    if (req.user) {
      if(req.user.active && req.user.isAccountVerified && !req.user.isAdminBlocked){
        const postId = req.params.id;
        const userId = req.user.id;
        const post = await Post.findById(postId);
        if (!post) {
          return res.status(404).json({ error: 'Post not found' });
        }
        if (post.likes.includes(userId)) {
          return res.status(400).json({ error: 'You have already liked this post' });
        }
        if (post.dislikes.includes(userId)) {
          post.dislikes.pull(userId);
        }
        post.likes.push(userId);
        await post.save();
        res.status(200).json({ message: 'Post liked successfully' });    
      } else {
        res.status(403).json({ success: false, message: 'You are not allowed to like this post'})
      }
    } else {
      res.status(401).json({ success: false, message: 'Please Login/SignUp to Like this post'})
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

//Unliking a Post
exports.unlikePost = async (req, res) => {
  try {
    if (req.user) {
      if(req.user.active && req.user.isAccountVerified && !req.user.isAdminBlocked){
        const postId = req.params.id;
        const userId = req.user.id;
        const post = await Post.findById(postId);
        if (!post) {
          return res.status(404).json({ error: 'Post not found' });
        }
        if (!post.likes.includes(userId)) {
          return res.status(400).json({ error: 'You have not liked this post yet' });
        }
        post.likes.pull(userId);
        await post.save();    
        res.status(200).json({ message: 'Post unliked successfully' });
      } else {
        res.status(403).json({ success: false, message: 'You are not allowed to unlike this post'})
      }
    } else {
      res.status(401).json({ success: false, message: 'Please Login/SignUp to unlike this post'})
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

//Disliking a Post
exports.dislikePost = async (req, res) => {
  try {
    if (req.user) {
      if(req.user.active && req.user.isAccountVerified && !req.user.isAdminBlocked){
        const postId = req.params.id;
        const userId = req.user.id;
        const post = await Post.findById(postId);
        if (!post) {
          return res.status(404).json({ error: 'Post not found' });
        }
        if (post.dislikes.includes(userId)) {
          return res.status(400).json({ error: 'You have already disliked this post' });
        }
        if (post.likes.includes(userId)) {
          post.likes.pull(userId);
        }
        post.dislikes.push(userId);
        await post.save();
        res.status(200).json({ message: 'Post disliked successfully' });
      } else {
        res.status(403).json({ success: false, message: 'You are not allowed to dilike this post'})
      }
    } else {
      res.status(401).json({ success: false, message: 'Please Login/SignUp to unlike this post'})
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getAllPostsByUser = async (req, res) => {
  const userId = req.params.userId;

  try {
    const posts = await Post.find({ author: userId }).populate('author');
    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getAllPostsAnalytics = async (req, res) => {
  try {
    const postCount = await Post.countDocuments();
    const likesCount = await Post.aggregate([
      { $group: { _id: null, likes: { $sum: '$likes' } } }
    ]);
    const dislikesCount = await Post.aggregate([
      { $group: { _id: null, dislikes: { $sum: '$dislikes' } } }
    ]);
    const commentsCount = await Post.aggregate([
      { $project: { num_comments: { $size: '$comments' } } },
      { $group: { _id: null, comments: { $sum: '$num_comments' } } }
    ]);

    const analytics = {
      postCount: postCount,
      likesCount: likesCount[0].likes,
      dislikesCount: dislikesCount[0].dislikes,
      commentsCount: commentsCount[0].comments
    };

    res.status(200).json(analytics);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getPostAnalytics = async (req, res) => {
  const postId = req.params.postId;

  try {
    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const views = post.views.length;
    const likes = post.likes.length;
    const dislikes = post.dislikes.length;

    const analytics = {
      views: views,
      likes: likes,
      dislikes: dislikes
    };

    res.status(200).json(analytics);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getUserPostAnalytics = async (req, res) => {
  const userId = req.params.userId;

  try {
    const posts = await Post.find({ user: userId });
    if (!posts) {
      return res.status(404).json({ error: 'No posts found' });
    }

    let totalViews = 0;
    let totalLikes = 0;
    let totalDislikes = 0;

    posts.forEach(post => {
      totalViews += post.views.length;
      totalLikes += post.likes.length;
      totalDislikes += post.dislikes.length;
    });

    const analytics = {
      totalViews: totalViews,
      totalLikes: totalLikes,
      totalDislikes: totalDislikes
    };

    res.status(200).json(analytics);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getUsersLikedPost = async (req, res, next) => {
  try {
    const postId = req.params.postId;

    // Find the post
    const post = await Post.findById(postId);

    if (!post) {
      const error = new Error('Post not found');
      error.statusCode = 404;
      throw error;
    }

    // Get an array of user ids who liked the post
    const userIds = post.likes.map((like) => like.user);

    // Find all the users who liked the post and sort them by the number of followers in descending order
    const users = await User.find({ _id: { $in: userIds } })
      .sort({ followersCount: -1 })
      .select('-password -email -createdAt -updatedAt -__v');

    res.status(200).json({
      message: 'Users who liked the post successfully fetched',
      users: users,
    });
  } catch (error) {
    next(error);
  }
};

exports.getUsersDislikedPost = async (req, res, next) => {
  try {
    const postId = req.params.postId;

    // Find the post
    const post = await Post.findById(postId);

    if (!post) {
      const error = new Error('Post not found');
      error.statusCode = 404;
      throw error;
    }

    // Get an array of user ids who liked the post
    const userIds = post.dislikes.map((like) => like.user);

    // Find all the users who liked the post and sort them by the number of followers in descending order
    const users = await User.find({ _id: { $in: userIds } })
      .sort({ followersCount: -1 })
      .select('-password -email -createdAt -updatedAt -__v');

    res.status(200).json({
      message: 'Users who disliked the post successfully fetched',
      users: users,
    });
  } catch (error) {
    next(error);
  }
};

// Function to make a post public
exports.makePublic = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Check if the user making the request is the author of the post
    if (post.author.toString() !== req.user.id) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Update the post's visibility to public
    post.public = true;
    await post.save();

    res.status(200).json(post);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// Function to make a post private
exports.makePrivate = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Check if the user making the request is the author of the post
    if (post.author.toString() !== req.user.id) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Update the post's visibility to private
    post.public = false;
    await post.save();

    res.status(200).json(post);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};
