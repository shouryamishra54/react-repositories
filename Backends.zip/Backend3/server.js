const express = require("express");
const dotenv = require("dotenv").config();
const { errorHandler, notFound } = require("./middlewares/ErrorHandler");
const connectDB = require("./config/DBConnection");
const UserRouter = require("./routes/UserRoutes");
const PostRouter = require("./routes/PostRoutes");
const CategoryRouter = require("./routes/CategoryRoutes");
const app = express();
app.use(express.json());
const port = process.env.PORT || 5000;

app.use("/api/users", UserRouter)
app.use("/api/posts", PostRouter)
app.use("/api/categories", CategoryRouter)

app.use(errorHandler)
app.use(notFound)
function success(){
  app.listen(port, () => {
    console.log("Server listening on port " + port);
  });
}
connectDB(success);

