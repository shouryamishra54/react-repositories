const HttpError = require("../models/http-error");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const uuid = require("uuid");
const fs = require("fs");
const path = require("path");
const validator = require("validator");
const User=require("../models/User");
const { default: isEmail } = require("validator/lib/isEmail");
const { default: isEmpty } = require("validator/lib/isEmpty");
const { default: isStrongPassword } = require("validator/lib/isStrongPassword");
const userError = require("../validators/user-validator");
const { default: mongoose } = require("mongoose");
const Place = require("../models/Place");
const { db, bucket, connectDB } = require("../DB/Connection");
const { Readable } = require("stream");
const { Grid } = require("gridfs-stream");
const { getImage, getImages, addImage, addImages, updateFile, updateFiles, 
    deleteImage, deleteImages } = require("../utils/image-operations")
let users = [];

async function getAllUsers(req, res, next){
    const {page=1, limit=10} = req.query
    const users=await User.find()
    .limit((!parseInt(limit) || limit <= 0 || limit >100) ? 10 : limit)
    .skip((!parseInt(page) || page <= 0) ? 0 : (page-1)*limit).catch((err)=>{
        const error=new HttpError("Something went wrong, Unable to find User", 500)
        return next(error)
    })
    if(!users || users === undefined || users === null){
        const error=new Error("No User found", 404)
        return next(error)
    }
    users.map((user)=>{
        // console.log(typeof(user.image))
        if(user.image){
            fs.readFile(user.image.toString(), (err, data)=>{
                if(err){
                    user.image="Cannot fetch Image for this user"
                }else{
                    user.image=data
                }
            })
        }
    })
    res.status(201).json({users:users.map((user)=>{
        // const thisuser=user.toObject({getters: true, setters: true})
        return {userId: user.id, name: user.name, username: user.username, 
            email: user.emailId, image: user.image, places: user.places}
    })})
}
async function getUser(req, res, next){
    const id=req.params.uid;
    if(!id || id === null ){
        const error=new HttpError("User ID not found in URL... Please provide right URL", 403)
        return next(error)
    }
    // const user=users.filter((u)=>{return (u.id === id)})
    const user=await User.findById(id).catch((err)=>{
        const error=new HttpError("Something went wrong, Unable to find User", 500)
        return next(error)
    })
    if(!user || user === undefined || user === null){
        const error=new Error("No User found for this ID", 404)
        return next(error)
    }
    res.status(201).json({user:user.toObject({getters:true})})
}
async function createUser(req, res, next){
    // const user={
    //     id:uuid(), ...req.body
    // }
    console.log(req.body)
    const usertofind=await User.findOne({emailId:req.body.emailId}).catch((err)=>{
        const error=new HttpError("Something went wrong, unable to create user", 500)
        return next(error)
    })
    // req.body.image=(req.body.image)
    if(usertofind){
        const error=new HttpError("User existing already for the given emailId", 404)
        return next(error)
    }
    let hashedPassword
    try{
        hashedPassword=await bcrypt.hash(req.body.password, 12)
    }catch(e){
        const error=new HttpError("Could not create user, please try again", 500)
        return next(error)
    }
    req.body={...req.body, password: hashedPassword}
    let user=new User({...req.body, places:[]})
    // console.log(req.body)
    /*if(req.file && req.file.path){
        console.log(req.file)
        user=new User({...req.body, image:req.file.path, places:[]})
    }*/
    if(req.file){
        console.log(req.file)
        const bucket=(await connectDB()).bucket
        // let imgbuf=Buffer.from(req.body.image, "base64")
        // const imagename=req.body.username+"-profilepic.png";
        // imgbuf=Buffer.from(new Uint8Array(req.body.image), "base64")
        // console.log(imgbuf)
        Readable.from(req.file.buffer)
        .pipe(bucket.openUploadStream(req.file.originalname))
        .on("error", (err)=>{
            console.log(err)
            assert.equal(null, err)
        }).on("finish", ()=>{
            console.log("uploaded")
        }).on("close", ()=>{
            console.log("Closed")
        })
        user=new User({...req.body, image:req.file.originalname, places:[]})
    }
    const dataError=userError(user)
    if(dataError){
        const error=new HttpError(dataError, 404)
        return next(error)
    }
    users.push(user.toObject())
    // console.log(user)
    user.save().catch((err)=>{
        const error=new HttpError("Something went wrong, unable to create user", 500)
        return next(err)
    })
    let token;
    try{
        token=jwt.sign(
            {userId: user.id, email: user.emailId, username: user.username},
            'supersecret_dont_share',
            {expiresIn: 3600}
        );
    }catch(e){
        const error=new HttpError("Signing up failed, please try again later", 500)
        return next(error)
    }
    res.status(201).json({userId: user.id, username: user.username, email: user.emailId, token: token})
}
async function updateUser(req, res, next){
    const id=req.params.uid;
    if(!id || id === null ){
        const error=new HttpError("User ID not found in URL... Please provide right URL", 403)
        return next(error)
    }if(id !== req.userData.userId){
        const error=new HttpError("You are not allowed to change this user profile", 403)
        return next(error)
    }
    // const index=users.findIndex((u)=>{return (u.id === id)})
    // let user=users.find((u)=>{return (u.id === id)})
    // if((index === undefined || index === -1) || user === undefined){
    //     const error=new HttpError("No User found for this ID", 404)
    //     return next(error)
    // }
    const user=await User.findById(id).catch((err)=>{
        const error=new HttpError("Something went wrong, unable to update user data", 500)
        return next(error)
    })
    if(!user || user === undefined || user === null){
        const error=new Error("No User found for this ID", 404)
        return next(error)
    }
    let hashedPassword
    try{
        hashedPassword=await bcrypt.hash(req.body.password, 12)
    }catch(e){
        const error=new HttpError("Internal Server Error, Unable to update user", 500)
        return next(error)
    }
    const updatedUser={...user.toObject({getters:true}), ...req.body, password:hashedPassword}
    /*const dataIsValid=!(isEmpty(updatedUser.name) || isEmpty(updatedUser.emailId) || 
    isEmpty(updatedUser.password)) && isEmail(updatedUser.emailId) && 
    isStrongPassword(updatedUser.password, [{
        minLength: 10, minLowercase: 1, minUppercase: 1, minNumbers: 1, minSymbols: 1
    }])
    if(!dataIsValid){
        const error=new HttpError("User data is wrongly typed. Please correct it", 404)
        return next(error)
    }*/
    const dataError=userError(updatedUser)
    if(dataError){
        const error=new HttpError(dataError, 404)
        return next(error)
    }
    // users[index]=updatedUser;
    Object.keys(req.body).map((p)=>{user[p]=updatedUser[p]})
    await user.save().catch((err)=>{
        const error=new HttpError("Something went wrong, Unable to update user data", 500)
        return next(error)
    })
    res.status(201).json({updatedUser})
}
async function loginUser(req, res, next){
    // const user=users.find((u)=>{u.emailId === req.body.emailId})
    const user=await User.findOne({
        emailId:req.body.emailId
    }).catch((err)=>{
        const error=new HttpError("Something went wrong, unable to login", 500)
        return next(error)
    })
    if(!user || user === undefined || user === null){
        const error=new HttpError("Invalid credentials, could not log you in", 404)
        return next(error)
    }
    let isValidPassword
    try{
        isValidPassword=await bcrypt.compare(req.body.password, user.password)
    }catch(e){
        const error=new HttpError("Could not log you in, please check your credentials and try again", 500)
        return next(error)
    }
    if(!isValidPassword || isValidPassword === false){
        const error=new HttpError("Invalid credentials, could not log you in", 404)
        return next(error)
    }
    let token;
    try{
        token=jwt.sign(
            {userId: user.id, email: user.emailId, username: user.username},
            'supersecret_dont_share',
            {expiresIn: 3600}
        );
    }catch(e){
        const error=new HttpError("Login failed, please try again later", 500)
        return next(error)
    }
    res.status(201).json({userId:user.id, username: user.username, email: user.emailId, token: token})
}
async function deleteUser(req, res, next){
    const id=req.params.uid;
    if(!id || id === null ){
        const error=new HttpError("User ID not found in URL... Please provide right URL", 403)
        return next(error)
    }if(id !== req.userData.userId){
        const error=new HttpError("You are not allowed to delete this user profile", 403)
        return next(error)
    }
    // const index=users.findIndex((u)=>{return(u.id === id)})
    // if(index === undefined || index === -1){
    //     const error=new HttpError("No User found for this ID", 404)
    //     return next(error)
    // }
    // const deletedUser=users[index]
    // users.splice(index, 1)
    // DUMMY_PLACES=DUMMY_PLACES.filter((p)=>{return (p.id === id)})
    // const deletedUser=await User.findById(id).catch((err)=>{
    //     const error=new HttpError("Something went wrong, unable to delete user", 500)
    //     return next(error)
    // })
    let deletedUser=await User.findById(id).populate("places").catch((err)=>{
        const error=new HttpError("Something went wrong, unable to delete user"+err, 500)
        return next(error)
    })
    if(!deletedUser || deletedUser === undefined || deletedUser === null){
        const error=new HttpError("No user found for this ID", 404)
        return next(error)
    }
    try{
        const sess=await mongoose.startSession();
        sess.startTransaction();
        if(deletedUser.places){
            deletedUser.places.map(async (place)=>{
                await place.remove({session:sess}).catch((err)=>{
                    const error=new HttpError("Something went wrong, unable to delete places for this user", 500)
                    return next(error)
                })
            })
            // await deletedUser.places.deleteMany({session:sess})
        }
        await deletedUser.remove({session:sess})
        await sess.commitTransaction();
    }catch(err){
        const error=new HttpError("Something went wrong, unable to delete"+err, 500)
        return next(error)
    }
    // const user=deletedUser.toObject({getters:true});
    // console.log(users)
    // await deletedUser.remove().catch((err)=>{
    //     const error=new HttpError("Something went wrong, unable to delete user", 500)
    //     return next(error)
    // })
    res.status(201).json({deletedUser:deletedUser.toObject()})
}
function deleteMyProfile(req, res, next){

}
function updateMyProfile(req, res, next){
    
}
async function fetchImage(req, res, next){
    const {image}=req.query
    // console.log(image)
    // const options={root : path.join(__dirname, "..")}
    let response;
    // const stat=fs.statSync(`upload/images/${image}`)
    /*res.writeHead(201, {
        "Content-Type": "image/png"
    })*/
    /*res.status(201).sendFile(image, options, (err)=>{
        if(err){
            console.log(err)
            return next(new HttpError(err, 404))
        }else{
            console.log(image)
        }
    })*/
    console.log(image)
    // const bucket=(await connectDB()).bucket
    let imagebuf
    const fileResult=await getImage(image, res)    
    // res.status(201).json({fileResult})
    // await bucket.find({filename: image}).toArray((err, files)=>{
    //     if(!files[0] || files.length === 0){
    //         return res.status(404).json({
    //             success: false,
    //             message: "No File Available"
    //         })
    //     }
    //     /*res.status(201).json({
    //         success: true,
    //         file: files[0],
    //     })*/
    //     bucket.openDownloadStreamByName(image).pipe(res)
    // })
    // const readStream=fs.createReadStream(`upload/images/${image}`)
    // readStream.pipe(res)
    /*fs.readFile(`upload/images/${image}`, (err, data)=>{
        if(err){
            const error=new HttpError("Unable to fetch photo", 404)
            return next(error)
        }else{
            response=data
            res.status(201).json({response})
        }
    })*/
}
async function uploadUserImage(req, res, next){
    if(req.file){
        try{
            if(req.body.userId !== req.userData.userId){
                throw new HttpError("Unauthorized", 403)
            }
            await User.findById(req.body.userId).then(async(data)=>{
                await addImage(req.file, async(filename)=>{
                    data.image=filename
                    await data.save().catch((err)=>{
                        throw new HttpError("Something went wrong, Unable to update user data", 500)
                    })
                }).then(()=>{
                    res.status(201).json(data.toObject({getters: true}))    
                }).catch((err)=>{
                    throw new HttpError("Something went wrong, unable to upload picture", 500)
                })
            })
        }catch(err){
            return next(err)
        }
    }else{
        const error=new HttpError("Please insert image to upload", 408)
        return next(error)
    }
}
async function updateUserImage(req, res, next){
    const filename=req.body.filename
    let updatedUser
    if(req.file){
        try{
            if(req.body.userId !== req.userData.userId){
                throw new HttpError("Unauthorized", 403)
            }
            let user=await User.findById(req.body.userId).then(async(data)=>{
                await updateFile(data.image, req.file, async(file)=>{
                    data.image=file
                    await data.save().catch((err)=>{
                        throw new HttpError("Something went wrong, Unable to update user data", 500)
                    })
                }).then(()=>{
                    res.status(201).json(data.toObject({getters: true}))    
                }).catch((err)=>{
                    throw new HttpError("Something went wrong, unable to upload picture", 500)
                })
            })
        }catch(err){
            return next(err)
        }
    }else{
        const error=new HttpError("Please insert image to upload", 408)
        return next(error)
    }
}
async function deleteUserImage(req, res, next){
    const filename=req.body.filename
    if(filename){
        try{
            if(req.body.userId !== req.userData.userId){
                throw new HttpError("Unauthorized", 403)
            }
            let user=await User.findById(req.body.userId).then(async(data)=>{
                await deleteImage(data.image, async(file)=>{
                    data.image=undefined
                    await data.save().catch((err)=>{
                        throw new HttpError("Something went wrong, Unable to update user data", 500)
                    })
                }).then(()=>{
                    res.status(201).json(data.toObject({getters: true}))    
                }).catch((err)=>{
                    throw new HttpError("Something went wrong, unable to upload picture", 500)
                })
            })
        }catch(err){
            return next(err)
        }
    }else{
        const error=new HttpError("Unable to find the requested picture", 404)
        return next(error)
    }
}
async function uploadImage(req, res, next){
    if(req.file){
        await addImage(req.file, (filename)=>{
            res.status(201).json({filename: filename})
        }).catch((err)=>{
            return next(new HttpError("Internal Server Error - Unable to upload the image", 500))
        })        
    }else{
        return next(new HttpError("Please provide the image to upload", 205))
    }
}

module.exports = {
    users, getAllUsers, getUser, createUser, loginUser, updateUser, deleteUser, fetchImage, 
    uploadUserImage, updateUserImage, deleteUserImage, uploadImage
}