const express = require("express")
const bodyParser = require("body-parser")
const uuid = require("uuid")
const app=express();
const dummy_product=[
    {id:1, title:"Bag", price:400},
    {id:2, title:"T-Shirt", price:200}
];
app.use(bodyParser.json())
app.use((req, res, next)=>{
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Access-Control-Allow-Headers",
        "Origin, X-Registered-With, Content-Type, Accept, Authorization"
    );
    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, PATCH, DELETE, OPTIONS"
    );
    next();
});
app.get("/products", (req, res, next)=>{
    res.status(200).json({
        products:dummy_product
    })
})
app.post("/product", (req, res, next)=>{
    const {title, price}=req.body;
    if(title === null || title.trim().length === 0 || price === null || price <= 0){
        return res.status(422).json({
            message: "Invalid input, please enter a valid title and price"
        })
    }
    const newProd={
        id:uuid(), title, price
    }
    dummy_product.push(newProd)
    res.status(201).json({
        message: "Created new Product",
        product: newProd
    })
})
app.listen(5000)