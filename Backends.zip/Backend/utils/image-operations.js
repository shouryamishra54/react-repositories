const { Readable } = require("stream");
const { connectDB } = require("../DB/Connection");
const HttpError = require("../models/http-error");
const mime = require("mime")
const fs = require("fs");
const path = require("path");

async function getImage(filename, res){
    let fileResult
    const bucket=(await connectDB()).bucket
    await bucket.find({filename: filename}).toArray(async(err, files)=>{
        if(!files[0] || files.length === 0){
            throw new HttpError({
                success: false,
                message: "No File Available"
            }, 404)
        }
        else{
            res.setHeader('Content-Disposition', 'attachment; filename=' + files[0].filename);
            res.setHeader('Content-Type', 'image/png')
            /*const options={root : path.join(__dirname, "..")}            
            res.status(201).sendFile("\\upload\\images\\71420140-8a19-11ed-9283-d94fa0fe4f22.png", options, (err)=>{
                if(err){
                    console.log(err)
                }else{
                    console.log(files[0])
                }
            })*/
            // res.status(201).send(files[0])
            await bucket.openDownloadStreamByName(filename).pipe(res.status(201))
            // res.status(201).json({
            // success: true,
            // file: files[0],
            // })
            // fileResult={file:files[0],fileData:bucket.openDownloadStreamByName(filename)}
        }
    })
    // return fileResult
}
async function getImages(filenames){
    let fileResult=[]
    let fileErrors=[]
    const bucket=(await connectDB()).bucket
    for(let i=0; i<filenames.length; i++){
        await bucket.find({filename: filenames[i]}).toArray((err, files)=>{
            if(!files[0] || files.length === 0){
                fileErrors.push("No File Available")
            }
            /*res.status(201).json({
                success: true,
                file: files[0],
            })*/
            fileResult.push({file:files[0],fileData:bucket.openDownloadStreamByName(image)})
        })    
    }
    return {fileResult, fileErrors}
}
async function addImage(file, callBack){
    let fileError;
    let filename;
    const bucket=(await connectDB()).bucket
    Readable.from(file.buffer)
    .pipe(bucket.openUploadStream(file.originalname))
    .on("error", (err)=>{
        fileError=err
        fileError={
            error: new HttpError(err.toString(), 500),
            filename: file.originalname,
        }
        assert.equal(null, err)
    }).on("finish", async(data)=>{
        console.log("uploaded file - "+data.filename)
        await callBack(data.filename)
    })
    return fileError
}
async function addImages(files, callBack1, callBack2){
    let fileErrors=[]
    let filenames=[]
    let count=0;
    const bucket=(await connectDB()).bucket
    for(let i=0; i<files.length; i++){
        Readable.from(files[i].buffer)
        .pipe(bucket.openUploadStream(files[i].originalname))
        .on("error", async(err)=>{
            count++
            fileErrors[i]={error:new HttpError(err.toString(), 500), filename: files[i].originalname}
            assert.equal(null, err)
            if(count === files.length){
                await callBack2()
                return {filenames, fileErrors}
            }
        }).on("finish", async(data)=>{
            count++;
            callBack1(data.filename)
            console.log("Here images")
            console.log("uploaded file - "+data.filename)
            filenames[i]=data.filename
            console.log(count)
            if(count === files.length){
                await callBack2().then(()=>{
                    return {filenames, fileErrors}
                })
            }
        })        
    }
}
async function updateFile(filename, file, callBack){
    let deletedFilename
    let newFilename
    let deleteFileError
    const bucket=(await connectDB()).bucket
    await bucket.find({filename: filename}).toArray(async (err, files)=>{
        if(err){
            deleteFileError={
                error: new HttpError("Internal Server Error - Unable to search file", 500),
                filename: filename
            }
        }
        if(!files[0] || files.length === 0){
            deleteFileError={
                error: new HttpError("No File found for the name", 404),
                filename: filename
            }
        }
        const imageId=files[0] ? files[0]._id : null;
        await bucket.delete(imageId).then(()=>{
            deletedFilename=files[0].filename
            console.log("deleted file - "+deletedFilename)
            Readable.from(file.buffer)
            .pipe(bucket.openUploadStream(file.originalname))
            .on("error", (err)=>{
                deleteFileError={
                    error: new HttpError("Unable to upload file - "+file.originalname, 500),
                    filename: file.originalname
                }
                assert.equal(null, err)
            }).on("finish", async(data)=>{
                console.log("uploaded file - "+data.filename)
                await callBack(deletedFilename, data.filename)
            })
            console.log("Here 1") 
        }).catch(()=>{
            deleteFileError={
                error: new HttpError("No File found for the name", 404),
                filename: filename
            }
        }) 
    })
    return deleteFileError
}
async function updateFiles(filenames, files, callBack1, callBack2){
    let deletedFilenames=[]
    let newFilenames=[]
    let deleteFileErrors=[]
    let count=0;
    const bucket=(await connectDB()).bucket
    for(let i=0; i<filenames.length; i++){
        await bucket.find({filename: filenames[i]}).toArray(async (err, searchfiles)=>{
            if(err){
                deleteFileErrors[i]={
                    error: new HttpError("Internal Server Error - Unable to search file", 500),
                    filename: filenames[i]
                }            
            }
            if(!searchfiles[0] || searchfiles.length === 0){
                count++;
                callBack1()
                deleteFileErrors[i]={
                    error: new HttpError("Internal Server Error - Unable to search file", 500),
                    filename: filenames[i]
                }
                if(count === filenames.length){
                    await callBack2()
                    return {deletedFilenames, newFilenames, deleteFileErrors}
                }
            }
            const imageId=searchfiles[0] ? searchfiles[i]._id : null;
            await bucket.delete(imageId).then((data)=>{
                count++;
                deletedFilenames[i]=searchfiles[0].filename
                console.log("deleted file - "+deletedFilenames[i])
                Readable.from(files[i].buffer)
                .pipe(bucket.openUploadStream(files[i].originalname))
                .on("error", (err)=>{
                    deleteFileErrors[i]={
                        error: new HttpError("Unable to upload file - "+files[i].originalname),
                        filename: files[i].originalname
                    }
                    assert.equal(null, err)
                }).on("finish", async(data1)=>{
                    console.log("uploaded file - "+data1.filename)
                    callBack1(data1.filename)
                    newFilenames[i]=data1.filename
                    if(count === filenames.length){
                        await callBack2().then(()=>{
                            return {deletedFilenames, newFilenames, deleteFileErrors}
                        })
                    }
                })
            }).catch((err)=>{
                deleteFileErrors[i]={
                    error: new HttpError("Unable to update this file", 500),
                    filename: filenames[i]
                }
            })
        })
    }
    return ({deletedFilenames, newFilenames, deleteFileErrors})
}
async function deleteImage(filename, callBack){
    let deletedFileError
    const bucket=(await connectDB()).bucket
    await bucket.find({filename: filename}).toArray(async (err, files)=>{
        if(err){
            deletedFileError={
                error: new HttpError("Internal Server Error - Unable to search file", 500),
                filename: filename
            }
        }
        if(!files[0] || files.length === 0){
            deletedFileError={
                error: new HttpError("No File found", 404),
                filename: filename
            }
        }
        const imageId=files[0] ? files[0]._id : null;
        await bucket.delete(imageId).then(async(data)=>{
            console.log("Deleted file - "+files[0].filename)
            await callBack(files[0].filename)
        }).catch((err)=>{
            deletedFileError={
                error: new HttpError("Unable to delete the file", 500),
                filename: filename
            }
        })
    })
    return deletedFileError
}
async function deleteImages(filenames, callBack1, callBack2){
    let deletedFileErrors=[]
    let deletedFilenames=[]
    let count=0;
    const bucket=(await connectDB()).bucket
    for(let i=0; i<filenames.length; i++){
        await bucket.find({filename: filenames[i]}).toArray(async (err, files)=>{
            if(err){
                count++;
                console.log(err)
                deletedFileErrors[i]={
                    error: new HttpError("Internal Server Error - Unable to search file", 500),
                    filename: filenames[i]
                }
                if(count === filenames.length){
                    return {deletedFilenames, deletedFileErrors}
                }
            }
            if(!files[0] || files.length === 0){
                count++;
                console.log(count)
                console.log(filenames[i])
                callBack1(filenames[i])
                deletedFileErrors[i]={
                    error: new HttpError("No File found", 404),
                    filename: filenames[i]
                }
                if(count === filenames.length){
                    await callBack2()
                    return {deletedFilenames, deletedFileErrors}
                }
            }
            const imageId=files[0] ? files[0]._id : null;
            await bucket.delete(imageId).then(async(data)=>{
                count++;
                callBack1(files[0].filename)
                console.log("Here images")
                console.log("Deleted File - "+files[0].filename)
                deletedFilenames[i]=files[0].filename
                console.log(count)
                if(count === filenames.length){
                    return (await callBack2())
                }
            }).catch((err)=>{
                deletedFileErrors[i]={
                    error: new HttpError("Unable to delete the file", 500),
                    filename: filenames[i]
                }
            })
        })
    }
}
module.exports = {
    getImage, getImages, addImage, addImages, updateFile, updateFiles, deleteImage, deleteImages
}