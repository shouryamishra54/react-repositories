
const express = require("express")
const uuid = require("uuid");
const { 
    getAllPlaces, getPlaceByPlaceId, getPlacesByUserId, addNewPlace, updatePlaceById, 
    deletePlaceById, 
    addPlaceImages,
    updatePlaceImage,
    deletePlaceImages,
    fetchPlaceImage
} = require("../controllers/places-controllers");
const { AuthUser } = require('../middleware/auth_user');
const { uploadFile } = require("../middleware/upload_image");
const router = express.Router();

router.get('/places', getAllPlaces)
router.get('/place/:pid', getPlaceByPlaceId);
router.get('/users/:uid', getPlacesByUserId);
router.post('/update/:pid', AuthUser, updatePlaceById);
router.post('/delete/:pid', AuthUser, deletePlaceById);
router.post('/new', AuthUser, uploadFile.array("images", 10), addNewPlace);
router.get("/fetch-place-images/:pid", fetchPlaceImage)
router.post("/upload-place-images", AuthUser, uploadFile.array("images", 10), addPlaceImages)
router.patch("/update-place-images", AuthUser, uploadFile.single("image"), updatePlaceImage)
router.delete("/delete-place-images", AuthUser, deletePlaceImages)

module.exports=router