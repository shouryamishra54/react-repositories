const mongodb=require("mongodb")
const mongoose=require("mongoose");
const fs=require("fs");
const assert = require("assert");
const url=`mongodb+srv://mycluster.nkqkk.mongodb.net/${process.env.DB_NAME}?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority`;
// const cred="./X509-cert-2389018379024932381.pem";
const cred=process.env.DB_CRED

const client=new mongodb.MongoClient(url, {
    sslCert: cred,
    sslKey: cred
})
let bucket;
let db;
async function connectDB(callBack){
    /*const conn=await mongoose.connect(url, {sslCert: cred, sslKey: cred}).then(()=>{
        console.log("Connection Successful")
        callBack()
    }).catch((err)=>{
        console.log("Error: "+err)
    })
    client.connect((error)=>{
        assert.equal(null, error)
        console.log("Connection to server")
    })*/
    const conn=await mongoose.connect(url, {sslCert: cred, sslKey: cred}).then(()=>{
        console.log("Connection Successful")
        db=mongoose.connections[0].db
        bucket=new mongoose.mongo.GridFSBucket(db, {
            bucketName: "uploads",
            chunkSizeBytes: 1048576
        })
        callBack()
    }).catch((err)=>{
        console.log("Error: "+err)
    })
    return {db: db, bucket: bucket}
    /*mongoose.connection.openUri(url, {
        sslCert: cred,
        sslKey: cred
    }).then(()=>{
        console.log("Connection Successful")
        callBack()
    }).catch((err)=>{
        console.log("Error: "+err)
    })
    mongoose.connection.on("open", ()=>{
        db=mongoose.connections[0].db;
        bucket=new mongoose.mongo.GridFSBucket(db, {
            bucketName: "uploads",
            chunkSizeBytes: 104856
        })
    })*/
}
/*const db=client.db(process.env.DB_NAME)
const bucket=new mongodb.GridFSBucket(db, {
    bucketName: "uploads",
    chunkSizeBytes: 1048576,
})*/
/*fs.createReadStream("./upload/images/shopify_recovery_codes.txt")
.pipe(bucket.openUploadStream("shopify_recovery_codes.txt"))
.on("error", (err)=>{
    assert.equal(null, err)
}).on("finish", ()=>{
    console.log("uploaded")
}).on("close", ()=>{
    console.log("Closed")
})*/
module.exports={connectDB, url, db, bucket}
// module.exports={connectDB, url, bucket}
