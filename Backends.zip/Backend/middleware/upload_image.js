const multer=require("multer")
const uuid=require("uuid")
const HttpError = require("../models/http-error")
const gridfs = require("multer-gridfs-storage")
const mongoose=require("mongoose");
// const { connectDB, url, db, bucket } = require("../DB/Connection")
// const url = "mongodb+srv://mycluster.nkqkk.mongodb.net/DB02"
const url=`mongodb+srv://mycluster.nkqkk.mongodb.net/${process.env.DB_NAME}?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority`;
// const cred="./X509-cert-2389018379024932381.pem";
const cred=process.env.DB_CRED
let bucket;
let db;
const conn=mongoose.createConnection(url, {
    sslCert: cred,
    sslKey: cred
}).openUri(url, (err)=>{
    if(err){
        console.log("Faled to connect to database")
    }else{
        console.log("Connected to database successfully")
    }
}).once("open", ()=>{
    db=conn.db
    bucket=new mongoose.mongo.GridFSBucket(db, {
        bucketName: "uploads"
    })
})
/*conn.once("open", ()=>{
    db=conn.db
    bucket=new mongoose.mongo.GridFSBucket(db, {
        bucketName: "uploads"
    })
})*/

const MIME_TYPE_MAP={
    "image/jpg":"jpg",
    "image/png":"png",
    "image/jpeg":"jpeg"
}

console.log(process.env.DB_NAME)
const gridStorage=gridfs.GridFsStorage({
    url: url,
    db: db,
    file: (req, file)=>{
        console.log(db)
        const ext=MIME_TYPE_MAP[file.mimetype]
        const filename=uuid.v1()+'.'+ext
        console.log(filename)
        return {
            bucketName: "uploads",
            filename: filename
        }
    }
})

/*const uploadFile=multer({
    limits: 500000,
    storage: multer.diskStorage({
        destination: (req, file, callback)=>{
            // console.log("1")
            callback(null, "upload/images")
        },
        filename: (req, file, callback)=>{
            // console.log("2")
            const ext=MIME_TYPE_MAP[file.mimetype]
            callback(null, uuid.v1()+'.'+ext)
        }
    }),
    fileFilter: (req, file, callback)=>{
        const isValid=!!MIME_TYPE_MAP[file.mimetype]
        // console.log("3")
        const error=isValid? null : new HttpError("Invalid Extension type!", 500)
        callback(error, isValid)
    }
})*/
const uploadFile=multer({
    limits: 1048576,
    fileFilter: (req, file, callback)=>{
        const isValid=!file || !!MIME_TYPE_MAP[file.mimetype]
        const error=isValid? null : new HttpError("Invalid Extension type!", 500)
        file.originalname=uuid.v1()+`.${MIME_TYPE_MAP[file.mimetype]}`
        callback(error, isValid)
    },
})
module.exports= { uploadFile }