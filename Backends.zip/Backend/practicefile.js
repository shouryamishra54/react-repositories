const fs=require("fs")
const text = "Shourya Mishra"
fs.appendFile("My_first.txt", "Text: "+text+"\n", (error)=>{
    if(error){
        console.log("There has been Error: "+error)
        return
    }
    console.log("Written")
})
